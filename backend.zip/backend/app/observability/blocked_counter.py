"""
Blocked Transition Counter - Passive Observability Only
Tracks failed transition attempts for metrics.
This is PURELY OBSERVATIONAL - counters never affect control flow.
"""
from collections import defaultdict
from threading import Lock
import logging

logger = logging.getLogger(__name__)


class BlockedTransitionCounter:
    """
    Thread-safe counter for blocked transitions.
    Incremented only at rejection points - never affects logic.
    """
    
    def __init__(self):
        self._counters = defaultdict(int)
        self._total_blocked = 0
        self._lock = Lock()
    
    def record_blocked(self, from_state: str, to_state: str, reason: str = None):
        """
        Record a blocked transition attempt.
        This is called ONLY when a transition is already rejected.
        Does NOT affect the rejection decision.
        """
        with self._lock:
            self._total_blocked += 1
            key = f"{from_state} → {to_state}"
            self._counters[key] += 1
            logger.debug(f"Blocked transition recorded: {key} (reason: {reason})")
    
    def get_metrics(self) -> dict:
        """
        Get current blocked transition metrics.
        Returns read-only snapshot of counters.
        """
        with self._lock:
            return {
                "total_blocked": self._total_blocked,
                "violations": dict(self._counters)
            }
    
    def reset(self):
        """Reset counters (for testing only)"""
        with self._lock:
            self._counters.clear()
            self._total_blocked = 0


# Global instance - shared across requests
_blocked_counter = BlockedTransitionCounter()


def get_blocked_counter() -> BlockedTransitionCounter:
    """Get the global blocked transition counter"""
    return _blocked_counter

