# Observability module - read-only metrics and counters

