"""
Shipment Repository - Handles all database operations for shipments.
Implements repository pattern for clean separation of concerns.
"""
from typing import Optional, List
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, asc, String, cast
from app.models import Shipment, ShipmentState


class ShipmentRepository:
    """Repository for shipment data access operations"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_by_id(self, shipment_id: int) -> Optional[Shipment]:
        """Get shipment by internal ID"""
        return self.db.query(Shipment).filter(Shipment.id == shipment_id).first()
    
    def get_by_public_id(self, public_id: str, include_deleted: bool = False) -> Optional[Shipment]:
        """Get shipment by public ID"""
        query = self.db.query(Shipment).filter(Shipment.public_id == public_id)
        if not include_deleted:
            query = query.filter(Shipment.deleted_at.is_(None))
        return query.first()
    
    def get_by_tracking_number(self, tracking_number: str, include_deleted: bool = False) -> Optional[Shipment]:
        """Get shipment by tracking number"""
        query = self.db.query(Shipment).filter(Shipment.tracking_number == tracking_number)
        if not include_deleted:
            query = query.filter(Shipment.deleted_at.is_(None))
        return query.first()
    
    def get_by_serial_number(self, serial_number: int, include_deleted: bool = False) -> Optional[Shipment]:
        """Get shipment by serial number"""
        query = self.db.query(Shipment).filter(Shipment.serial_number == serial_number)
        if not include_deleted:
            query = query.filter(Shipment.deleted_at.is_(None))
        return query.first()
    
    def get_next_serial_number(self) -> int:
        """Get the next serial number from sequence"""
        from sqlalchemy import text
        result = self.db.execute(text("SELECT nextval('shipments_serial_number_seq')"))
        return result.scalar()
    
    def create(self, shipment: Shipment) -> Shipment:
        """Create a new shipment"""
        self.db.add(shipment)
        self.db.flush()
        return shipment
    
    def update(self, shipment: Shipment) -> Shipment:
        """Update an existing shipment"""
        self.db.flush()
        return shipment
    
    def delete_soft(self, shipment: Shipment) -> Shipment:
        """Soft delete a shipment"""
        from datetime import datetime
        shipment.deleted_at = datetime.utcnow()
        self.db.flush()
        return shipment
    
    def delete_permanent(self, shipment: Shipment) -> None:
        """Permanently delete a shipment"""
        self.db.delete(shipment)
        self.db.flush()
    
    def list(
        self,
        page: int = 1,
        limit: int = 10,
        status: Optional[ShipmentState] = None,
        carrier: Optional[str] = None,
        search: Optional[str] = None,
        sort_by: str = "updated_at",
        sort_order: str = "desc",
        include_deleted: bool = False
    ) -> tuple[List[Shipment], int]:
        """List shipments with pagination and filters"""
        query = self.db.query(Shipment)
        
        if not include_deleted:
            query = query.filter(Shipment.deleted_at.is_(None))
        
        if status:
            query = query.filter(Shipment.current_state == status)
        
        if carrier:
            query = query.filter(Shipment.carrier == carrier.upper())
        
        if search:
            search_pattern = f"%{search}%"
            query = query.filter(
                or_(
                    Shipment.tracking_number.ilike(search_pattern),
                    Shipment.public_id.ilike(search_pattern),
                    cast(Shipment.serial_number, String).ilike(search_pattern)  # Search serial as string
                )
            )
        
        # Sorting
        sort_column = getattr(Shipment, sort_by, Shipment.updated_at)
        if sort_order.lower() == "asc":
            query = query.order_by(asc(sort_column))
        else:
            query = query.order_by(desc(sort_column))
        
        total = query.count()
        shipments = query.offset((page - 1) * limit).limit(limit).all()
        
        return shipments, total
    
    def find_in_exception_state(self) -> List[Shipment]:
        """Find all shipments in EXCEPTION state"""
        return self.db.query(Shipment).filter(
            and_(
                Shipment.current_state == ShipmentState.EXCEPTION,
                Shipment.deleted_at.is_(None)
            )
        ).all()
    
    def find_by_version(self, state_version: str) -> List[Shipment]:
        """Find shipments using a specific state machine version"""
        return self.db.query(Shipment).filter(
            and_(
                Shipment.state_version == state_version,
                Shipment.deleted_at.is_(None)
            )
        ).all()

