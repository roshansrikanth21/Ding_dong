"""Repository for waypoint visit tracking"""
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List, Optional
from app.models import WaypointVisit, Shipment


class WaypointRepository:
    """Repository for managing waypoint visits"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def create(self, waypoint_visit: WaypointVisit) -> WaypointVisit:
        """Create a new waypoint visit"""
        self.db.add(waypoint_visit)
        self.db.flush()
        return waypoint_visit
    
    def get_by_shipment_id(self, shipment_id: int, include_departed: bool = True) -> List[WaypointVisit]:
        """Get all waypoint visits for a shipment, ordered by arrival time"""
        query = self.db.query(WaypointVisit).filter(
            WaypointVisit.shipment_id == shipment_id
        )
        if not include_departed:
            query = query.filter(WaypointVisit.departed_at.is_(None))
        return query.order_by(desc(WaypointVisit.arrived_at)).all()
    
    def get_by_shipment_public_id(self, shipment_public_id: str) -> List[WaypointVisit]:
        """Get waypoint visits by shipment public_id"""
        shipment = self.db.query(Shipment).filter(
            Shipment.public_id == shipment_public_id
        ).first()
        if not shipment:
            return []
        return self.get_by_shipment_id(shipment.id)
    
    def get_current_location(self, shipment_id: int) -> Optional[WaypointVisit]:
        """Get the current waypoint (where shipment is now)"""
        return self.db.query(WaypointVisit).filter(
            WaypointVisit.shipment_id == shipment_id,
            WaypointVisit.departed_at.is_(None)
        ).order_by(desc(WaypointVisit.arrived_at)).first()
    
    def mark_departed(self, waypoint_visit_id: int, actor: Optional[str] = None) -> Optional[WaypointVisit]:
        """Mark a waypoint visit as departed"""
        visit = self.db.query(WaypointVisit).filter(
            WaypointVisit.id == waypoint_visit_id
        ).first()
        if visit and not visit.departed_at:
            from datetime import datetime
            visit.departed_at = datetime.utcnow()
            if actor:
                visit.actor = actor
            self.db.flush()
        return visit
