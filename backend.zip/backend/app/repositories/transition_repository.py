"""
Transition Repository - Handles all database operations for state transitions.
"""
from typing import Optional, List
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, desc
from app.models import StateTransition, ShipmentState, Shipment


class TransitionRepository:
    """Repository for state transition data access operations"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def get_by_id(self, transition_id: int) -> Optional[StateTransition]:
        """Get transition by ID"""
        return self.db.query(StateTransition).filter(StateTransition.id == transition_id).first()
    
    def get_by_shipment_id(self, shipment_id: int) -> List[StateTransition]:
        """Get all transitions for a shipment, ordered by timestamp"""
        return self.db.query(StateTransition).filter(
            StateTransition.shipment_id == shipment_id
        ).order_by(StateTransition.timestamp.asc()).all()
    
    def find_by_idempotency_key(self, idempotency_key: str) -> Optional[StateTransition]:
        """Find transition by idempotency key (for duplicate detection)"""
        return self.db.query(StateTransition).filter(
            StateTransition.transition_idempotency_key == idempotency_key
        ).first()
    
    def create(self, transition: StateTransition) -> StateTransition:
        """Create a new transition"""
        self.db.add(transition)
        self.db.flush()
        return transition
    
    def get_recent_activity(
        self,
        days: int = 7,
        limit: int = 50,
        shipment_id: Optional[int] = None,
        state: Optional[ShipmentState] = None
    ) -> List[tuple[StateTransition, Shipment]]:
        """Get recent transitions with shipment details"""
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        query = (
            self.db.query(StateTransition, Shipment)
            .join(Shipment, Shipment.id == StateTransition.shipment_id)
            .filter(
                and_(
                    Shipment.deleted_at.is_(None),
                    StateTransition.timestamp >= cutoff_date
                )
            )
        )
        
        if shipment_id:
            query = query.filter(Shipment.id == shipment_id)
        
        if state:
            query = query.filter(StateTransition.to_state == state)
        
        return query.order_by(desc(StateTransition.timestamp)).limit(limit).all()
    
    def check_duplicate_transition(
        self,
        shipment_id: int,
        to_state: ShipmentState
    ) -> Optional[StateTransition]:
        """Check if a transition to the same state already exists (prevent duplicates)"""
        return self.db.query(StateTransition).filter(
            and_(
                StateTransition.shipment_id == shipment_id,
                StateTransition.to_state == to_state
            )
        ).first()
    
    def find_by_command_id(self, shipment_id: int, command_id: str) -> Optional[StateTransition]:
        """
        TASK 2: Find transition by command_id for idempotency check.
        Command_id must be unique per shipment (aggregate).
        """
        return self.db.query(StateTransition).filter(
            and_(
                StateTransition.shipment_id == shipment_id,
                StateTransition.command_id == command_id
            )
        ).first()
    
    def get_transition_summary(self, shipment_id: int) -> dict:
        """Get a human-readable summary of shipment transitions"""
        transitions = self.get_by_shipment_id(shipment_id)
        
        summary = {
            "total_transitions": len(transitions),
            "first_transition": transitions[0].timestamp if transitions else None,
            "last_transition": transitions[-1].timestamp if transitions else None,
            "states_visited": [t.to_state.value for t in transitions],
            "transitions": [
                {
                    "from": t.from_state.value if t.from_state else None,
                    "to": t.to_state.value,
                    "timestamp": t.timestamp.isoformat(),
                    "actor": t.actor,
                    "reason": t.reason
                }
                for t in transitions
            ]
        }
        
        return summary

