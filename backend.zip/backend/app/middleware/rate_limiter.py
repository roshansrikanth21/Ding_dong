"""
Rate Limiting Middleware - Load safety at the edge
Enforces per-endpoint and per-client rate limits conservatively.
Rejects excessive requests deterministically BEFORE business logic executes.
Rejected requests NEVER mutate state.
"""
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from collections import defaultdict
from datetime import datetime, timedelta
import logging
from typing import Tuple, Optional
import time

logger = logging.getLogger(__name__)


class RateLimiter:
    """Simple in-memory rate limiter (for single-instance deployments)"""
    
    def __init__(self):
        # Per-client tracking: {client_id: [(timestamp, endpoint), ...]}
        self.requests = defaultdict(list)
        # PART 2.1: Rate limit config: (requests_per_window, window_seconds)
        # Stricter limits for write and debug endpoints
        self.limits = {
            "/shipments": (60, 60),  # 60 requests per minute (GET)
            "/shipments/{id}/transition": (20, 60),  # 20 transitions per minute (write endpoint)
            "/shipments/bulk": (5, 60),  # 5 bulk operations per minute (write endpoint)
            "/shipments/{id}/recover": (10, 60),  # 10 recoveries per minute (write endpoint)
            "/shipments/{id}/replay": (5, 60),  # 5 replays per minute (debug endpoint - very strict)
            "default": (100, 60),  # 100 requests per minute for other endpoints
        }
        self.cleanup_interval = timedelta(minutes=5)
        self.last_cleanup = datetime.utcnow()
    
    def get_client_id(self, request: Request) -> str:
        """Extract client identifier from request"""
        # Use IP address as client identifier
        client_host = request.client.host if request.client else "unknown"
        # Could also use X-Forwarded-For header if behind proxy
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            client_host = forwarded_for.split(",")[0].strip()
        return client_host
    
    def get_endpoint_key(self, request: Request) -> str:
        """Determine endpoint key for rate limiting"""
        path = request.url.path
        method = request.method
        
        # PART 2.1: Map specific endpoints with method awareness
        if "/replay" in path:
            return "/shipments/{id}/replay"  # Debug endpoint - strictest limits
        elif "/recover" in path:
            return "/shipments/{id}/recover"  # Write endpoint
        elif "/transition" in path:
            return "/shipments/{id}/transition"  # Write endpoint
        elif path.startswith("/shipments/bulk"):
            return "/shipments/bulk"  # Write endpoint
        elif path.startswith("/shipments") and method == "POST":
            return "/shipments"  # Write endpoint (creation)
        elif path.startswith("/shipments"):
            return "/shipments"  # Read endpoint
        return "default"
    
    def is_allowed(self, client_id: str, endpoint_key: str) -> Tuple[bool, Optional[str]]:
        """
        Check if request is within rate limit.
        
        Returns:
            Tuple of (is_allowed: bool, reason_if_rejected: Optional[str])
        """
        now = datetime.utcnow()
        
        # Cleanup old entries periodically
        if (now - self.last_cleanup) > self.cleanup_interval:
            self._cleanup_old_entries(now)
            self.last_cleanup = now
        
        # Get rate limit for endpoint
        requests_per_window, window_seconds = self.limits.get(endpoint_key, self.limits["default"])
        
        # Get client's request history for this endpoint
        key = f"{client_id}:{endpoint_key}"
        client_requests = self.requests[key]
        
        # Filter requests within time window
        window_start = now - timedelta(seconds=window_seconds)
        recent_requests = [ts for ts in client_requests if ts > window_start]
        
        # Check if limit exceeded
        if len(recent_requests) >= requests_per_window:
            return False, f"Rate limit exceeded: {requests_per_window} requests per {window_seconds} seconds"
        
        # Record this request
        recent_requests.append(now)
        self.requests[key] = recent_requests
        
        return True, None
    
    def _cleanup_old_entries(self, now: datetime):
        """Remove old request entries to prevent memory leak"""
        cutoff = now - timedelta(hours=1)
        keys_to_remove = []
        
        for key, requests in self.requests.items():
            # Keep only recent requests
            recent = [ts for ts in requests if ts > cutoff]
            if recent:
                self.requests[key] = recent
            else:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self.requests[key]


# Global rate limiter instance
_rate_limiter = RateLimiter()


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware - rejects requests before business logic"""
    
    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for health checks and ready checks
        if request.url.path in ["/health", "/ready", "/docs", "/openapi.json", "/redoc"]:
            return await call_next(request)
        
        client_id = _rate_limiter.get_client_id(request)
        endpoint_key = _rate_limiter.get_endpoint_key(request)
        
        is_allowed, reason = _rate_limiter.is_allowed(client_id, endpoint_key)
        
        if not is_allowed:
            # PART 1: Get request_id if available
            request_id = getattr(request.state, "request_id", "unknown")
            
            logger.warning(
                f"[{request_id}] Rate limit exceeded: client={client_id}, endpoint={endpoint_key}, "
                f"path={request.url.path}, reason={reason}"
            )
            
            # PART 1: Structured error semantics
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "error_code": "RATE_LIMIT_EXCEEDED",
                    "message": reason,
                    "classification": "retryable",
                    "request_id": request_id
                },
                headers={"Retry-After": "60"}
            )
        
        # Add rate limit headers to response
        response = await call_next(request)
        requests_per_window, window_seconds = _rate_limiter.limits.get(
            endpoint_key, _rate_limiter.limits["default"]
        )
        response.headers["X-RateLimit-Limit"] = str(requests_per_window)
        response.headers["X-RateLimit-Window"] = str(window_seconds)
        
        return response

