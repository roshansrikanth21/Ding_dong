"""
PART 2.3: Timeout & Fail-Fast Semantics
Adds request processing timeouts and DB query timeouts.
If exceeded: abort request, no partial writes, no retries.
The system must prefer refusal over overload.
"""
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
import logging
import asyncio
import signal
from contextlib import contextmanager
from typing import Callable, Any
import functools
from app.middleware.request_id import get_request_id

logger = logging.getLogger(__name__)

# PART 2.3: Timeout configuration
REQUEST_PROCESSING_TIMEOUT = 30  # seconds - maximum time to process a request
DB_QUERY_TIMEOUT = 5  # seconds - maximum time for a DB query


class TimeoutMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce request processing timeouts"""
    
    async def dispatch(self, request: Request, call_next):
        # PART 2.3: Skip timeout for health checks (must be fast)
        if request.url.path in ["/health", "/ready"]:
            return await call_next(request)
        
        # PART 2.3: Apply timeout to request processing
        try:
            # Use asyncio.wait_for to enforce timeout
            response = await asyncio.wait_for(
                call_next(request),
                timeout=REQUEST_PROCESSING_TIMEOUT
            )
            return response
        except asyncio.TimeoutError:
            request_id = getattr(request.state, "request_id", "unknown")
            logger.error(
                f"[{request_id}] Request processing timeout after {REQUEST_PROCESSING_TIMEOUT}s "
                f"for {request.method} {request.url.path}"
            )
            # PART 1: Structured error semantics
            return JSONResponse(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                content={
                    "error_code": "ABUSE_REJECTED",
                    "message": f"Request processing exceeded maximum allowed time ({REQUEST_PROCESSING_TIMEOUT} seconds). "
                             f"The system prefers refusal over overload to maintain correctness.",
                    "classification": "non-retryable",
                    "request_id": request_id
                }
            )
        except Exception as e:
            # Re-raise other exceptions
            logger.error(f"Unexpected error in timeout middleware: {str(e)}", exc_info=True)
            raise


@contextmanager
def db_query_timeout(timeout_seconds: float = DB_QUERY_TIMEOUT):
    """
    Context manager to enforce DB query timeouts.
    
    Note: This is a best-effort timeout mechanism. Actual enforcement
    depends on the database driver and connection pool settings.
    For PostgreSQL with SQLAlchemy, set statement_timeout in the connection string.
    """
    import time
    start_time = time.time()
    
    try:
        yield
    finally:
        elapsed = time.time() - start_time
        if elapsed > timeout_seconds:
            logger.warning(
                f"DB query exceeded timeout threshold: {elapsed:.2f}s > {timeout_seconds}s"
            )

