"""
Minimal Observability - Request ID generation
Generates request_id per request and includes in logs and error responses.
"""
import uuid
import logging
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Middleware to generate and attach request_id to each request"""
    
    async def dispatch(self, request: Request, call_next):
        # Generate unique request_id for this request
        request_id = str(uuid.uuid4())[:8]  # Short ID for readability
        
        # Store in request state for access in handlers
        request.state.request_id = request_id
        
        # Add to response headers
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        
        return response


def get_request_id(request: Request) -> str:
    """Helper to get request_id from request state"""
    return getattr(request.state, "request_id", "unknown")


