"""
PART 2.2: Hard Limits on Resource-Intensive Operations
Enforces strict caps on request body size, JSON depth, and replayable events.
Rejects requests early with clear error messages.
"""
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
import logging
import sys
from typing import Any
import json
from app.middleware.request_id import get_request_id

logger = logging.getLogger(__name__)

# PART 2.2: Hard limits configuration
MAX_REQUEST_BODY_SIZE = 1 * 1024 * 1024  # 1MB (enforced by FastAPI, but we check for clarity)
MAX_JSON_DEPTH = 10  # Maximum JSON nesting depth
MAX_REPLAY_EVENTS = 1000  # Maximum events per replay request (matches replay service)


class RequestLimitsMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce hard limits on resource-intensive operations"""
    
    async def dispatch(self, request: Request, call_next):
        # PART 2.2: Check request body size
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                if size > MAX_REQUEST_BODY_SIZE:
                    request_id = get_request_id(request)
                    logger.warning(
                        f"[{request_id}] Request body size exceeded: {size} bytes (max: {MAX_REQUEST_BODY_SIZE}) "
                        f"for {request.url.path}"
                    )
                    # PART 1: Structured error semantics
                    return JSONResponse(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        content={
                            "error_code": "ABUSE_REJECTED",
                            "message": f"Request body size ({size} bytes) exceeds maximum allowed size ({MAX_REQUEST_BODY_SIZE} bytes)",
                            "classification": "non-retryable",
                            "request_id": request_id
                        }
                    )
            except ValueError:
                pass  # Invalid content-length header, let FastAPI handle it
        
        # PART 2.2: For replay endpoint, check max_events parameter
        if "/replay" in request.url.path:
            try:
                max_events = request.query_params.get("max_events")
                if max_events:
                    events = int(max_events)
                    if events > MAX_REPLAY_EVENTS:
                        request_id = get_request_id(request)
                        logger.warning(
                            f"[{request_id}] Replay request exceeds max events: {events} (max: {MAX_REPLAY_EVENTS}) "
                            f"for {request.url.path}"
                        )
                        # PART 1: Structured error semantics
                        return JSONResponse(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            content={
                                "error_code": "REPLAY_ABORTED",
                                "message": f"Replay request exceeds maximum allowed events ({MAX_REPLAY_EVENTS}). "
                                         f"Replay is debug-only and cannot process more than {MAX_REPLAY_EVENTS} events.",
                                "classification": "non-retryable",
                                "request_id": request_id
                            }
                        )
            except ValueError:
                pass  # Invalid max_events parameter, let endpoint handle it
        
        # PART 2.2: For JSON body requests, check depth during parsing
        # Note: FastAPI handles JSON parsing, but we add validation after parsing
        # This is a defense-in-depth measure - actual depth check happens in endpoint if needed
        
        response = await call_next(request)
        return response


def validate_json_depth(data: Any, max_depth: int = MAX_JSON_DEPTH, current_depth: int = 0) -> tuple[bool, str]:
    """
    Validate JSON depth recursively.
    
    Returns:
        Tuple of (is_valid: bool, error_message: str)
    """
    if current_depth > max_depth:
        return False, f"JSON depth ({current_depth}) exceeds maximum allowed depth ({max_depth})"
    
    if isinstance(data, dict):
        for value in data.values():
            is_valid, error = validate_json_depth(value, max_depth, current_depth + 1)
            if not is_valid:
                return False, error
    elif isinstance(data, list):
        for item in data:
            is_valid, error = validate_json_depth(item, max_depth, current_depth + 1)
            if not is_valid:
                return False, error
    
    return True, ""

