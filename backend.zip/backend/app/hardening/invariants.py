"""
Formal Invariant Assertions
Centralized system-wide invariants that must always hold.
These invariants are checked before and after state transitions.

Invariants are NEVER bypassed - they are guard-based safety checks only.
All invariants must be comprehensive and unambiguous.
"""
from typing import List, Tuple
from app.models import Shipment, ShipmentState
import logging

logger = logging.getLogger(__name__)


class InvariantViolation(Exception):
    """Raised when a system invariant is violated"""
    def __init__(self, invariant_name: str, message: str):
        self.invariant_name = invariant_name
        self.message = message
        super().__init__(f"Invariant violation [{invariant_name}]: {message}")


def check_pre_transition_invariants(shipment: Shipment, target_state: ShipmentState) -> List[str]:
    """
    Check all invariants that must hold BEFORE a state transition.
    
    Returns:
        List of invariant names that were checked (for audit)
    
    Raises:
        InvariantViolation: If any invariant is violated
    """
    violations = []
    checked = []
    
    # INVARIANT 1: Terminal states cannot transition
    checked.append("terminal_state_immutable")
    terminal_states = {ShipmentState.DELIVERED, ShipmentState.CANCELLED}
    if shipment.current_state in terminal_states and target_state != shipment.current_state:
        violations.append(
            InvariantViolation(
                "terminal_state_immutable",
                f"Cannot transition from terminal state {shipment.current_state.value} to {target_state.value}"
            )
        )
    
    # INVARIANT 2: Soft-deleted shipments cannot transition
    checked.append("deleted_shipment_immutable")
    if shipment.deleted_at is not None:
        violations.append(
            InvariantViolation(
                "deleted_shipment_immutable",
                "Cannot transition soft-deleted shipment"
            )
        )
    
    # INVARIANT 3: Version must be consistent (checked by optimistic locking)
    checked.append("version_consistency")
    # Version check is handled by optimistic locking mechanism
    
    # INVARIANT 4: State version must match shipment's state version
    checked.append("state_version_match")
    if shipment.state_version is None or shipment.state_version == '':
        violations.append(
            InvariantViolation(
                "state_version_match",
                "Shipment must have a valid state_version"
            )
        )
    
    # INVARIANT 5: Cannot transition from EXCEPTION without explicit recovery
    checked.append("exception_recovery_explicit")
    # This is enforced by recovery endpoint, but we log it here for audit
    
    if violations:
        # PART 1: Log invariant violations explicitly (single line)
        for violation in violations:
            logger.error(f"INVARIANT_VIOLATION: {violation.invariant_name} - {violation.message}")
        raise violations[0]  # Raise first violation
    
    return checked


def check_post_transition_invariants(shipment: Shipment, transitioned_to: ShipmentState) -> List[str]:
    """
    Check all invariants that must hold AFTER a state transition.
    
    Returns:
        List of invariant names that were checked (for audit)
    
    Raises:
        InvariantViolation: If any invariant is violated
    """
    violations = []
    checked = []
    
    # INVARIANT 1: Current state must match transitioned state
    checked.append("state_consistency")
    if shipment.current_state != transitioned_to:
        violations.append(
            InvariantViolation(
                "state_consistency",
                f"Shipment state {shipment.current_state.value} does not match transition target {transitioned_to.value}"
            )
        )
    
    # INVARIANT 2: Terminal states cannot be modified further (except notes)
    checked.append("terminal_state_post_consistency")
    terminal_states = {ShipmentState.DELIVERED, ShipmentState.CANCELLED}
    if shipment.current_state in terminal_states:
        # Terminal state reached - this is expected, just log
        logger.debug(f"Shipment {shipment.id} reached terminal state {shipment.current_state.value}")
    
    # INVARIANT 3: EXCEPTION state must have exception_reason
    checked.append("exception_reason_required")
    if shipment.current_state == ShipmentState.EXCEPTION:
        if not shipment.exception_reason or shipment.exception_reason.strip() == '':
            violations.append(
                InvariantViolation(
                    "exception_reason_required",
                    "Shipment in EXCEPTION state must have exception_reason"
                )
            )
    
    # INVARIANT 4: Version must have incremented
    checked.append("version_incremented")
    # This is checked implicitly by the transition logic
    
    # INVARIANT 5: Non-EXCEPTION states must not have exception_reason (after recovery)
    checked.append("exception_cleanup")
    if shipment.current_state != ShipmentState.EXCEPTION:
        if shipment.exception_reason is not None:
            # This is acceptable if recovering from EXCEPTION - just ensure it's cleared
            logger.debug(f"Shipment {shipment.id} recovered from EXCEPTION, exception_reason should be cleared")
    
    if violations:
        # PART 1: Log invariant violations explicitly (single line)
        for violation in violations:
            logger.error(f"INVARIANT_VIOLATION: {violation.invariant_name} - {violation.message}")
        raise violations[0]  # Raise first violation
    
    return checked


def check_state_duration_invariants(shipment: Shipment, state_duration_hours: float) -> List[str]:
    """
    Check invariants related to time spent in states (SLA awareness).
    
    Args:
        shipment: The shipment to check
        state_duration_hours: Hours spent in current state
    
    Returns:
        List of warnings (not violations - these are observational)
    """
    warnings = []
    
    # Define expected maximum durations per state (in hours)
    MAX_DURATIONS = {
        ShipmentState.CREATED: 24,  # Should move to READY_FOR_PICKUP within 24 hours
        ShipmentState.READY_FOR_PICKUP: 48,  # Should move to IN_TRANSIT within 48 hours
        ShipmentState.IN_TRANSIT: 168,  # Should deliver within 7 days
        ShipmentState.EXCEPTION: 72,  # Should recover within 3 days
        # Terminal states have no limit
    }
    
    max_duration = MAX_DURATIONS.get(shipment.current_state)
    if max_duration and state_duration_hours > max_duration:
        warning = f"Shipment {shipment.public_id} has been in {shipment.current_state.value} for {state_duration_hours:.1f} hours (threshold: {max_duration}h)"
        warnings.append(warning)
        logger.warning(f"SLA threshold exceeded: {warning}")
    
    return warnings

