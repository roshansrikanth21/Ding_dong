"""
Predictive Observability - Detects abnormal patterns for early warning
Read-only pattern detection that emits warnings and health indicators.
Does NOT automate corrective actions - only observes and alerts.
"""
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from datetime import datetime, timedelta
from app.models import Shipment, StateTransition, ShipmentState
import logging

logger = logging.getLogger(__name__)


class PatternWarning:
    """Represents a detected abnormal pattern"""
    def __init__(self, pattern_type: str, severity: str, message: str, shipment_id: str = None):
        self.pattern_type = pattern_type
        self.severity = severity  # 'LOW', 'MEDIUM', 'HIGH'
        self.message = message
        self.shipment_id = shipment_id
        self.detected_at = datetime.utcnow()


def detect_abnormal_patterns(db: Session, shipment_id: int = None) -> List[PatternWarning]:
    """
    Detect abnormal patterns in shipment state transitions.
    
    Pattern types:
    - repeated_retries: Same transition attempted multiple times
    - frequent_exceptions: Multiple exception transitions
    - oscillating_states: Shipment bouncing between states
    - stale_shipments: Shipments stuck in non-terminal states
    - rapid_transitions: Too many transitions in short time
    
    Args:
        db: Database session
        shipment_id: Optional shipment ID to check (None = check all)
    
    Returns:
        List of PatternWarning objects
    """
    warnings = []
    now = datetime.utcnow()
    
    # Pattern 1: Repeated retry attempts (same transition multiple times)
    if shipment_id:
        transitions = db.query(StateTransition).filter(
            StateTransition.shipment_id == shipment_id
        ).order_by(StateTransition.timestamp.desc()).limit(10).all()
        
        if len(transitions) >= 3:
            # Check for repeated transitions to same state
            state_counts = {}
            for t in transitions:
                state_key = (t.from_state, t.to_state)
                state_counts[state_key] = state_counts.get(state_key, 0) + 1
            
            for (from_state, to_state), count in state_counts.items():
                if count >= 3:
                    warnings.append(PatternWarning(
                        pattern_type="repeated_retries",
                        severity="MEDIUM",
                        message=f"Transition from {from_state.value if from_state else 'None'} to {to_state.value} attempted {count} times",
                        shipment_id=str(shipment_id)
                    ))
    
    # Pattern 2: Frequent exception transitions (system-wide check)
    exception_count_query = db.query(
        StateTransition.shipment_id,
        func.count(StateTransition.id).label('exception_count')
    ).filter(
        and_(
            StateTransition.to_state == ShipmentState.EXCEPTION,
            StateTransition.timestamp >= now - timedelta(hours=24)
        )
    ).group_by(StateTransition.shipment_id).having(
        func.count(StateTransition.id) >= 3
    )
    
    for row in exception_count_query.all():
        warnings.append(PatternWarning(
            pattern_type="frequent_exceptions",
            severity="HIGH",
            message=f"Shipment {row.shipment_id} entered EXCEPTION state {row.exception_count} times in 24h",
            shipment_id=str(row.shipment_id)
        ))
    
    # Pattern 3: Oscillating states (bouncing between states)
    if shipment_id:
        state_history = [t.to_state for t in transitions[:5]]
        if len(state_history) >= 4:
            # Check for A->B->A pattern (oscillation)
            for i in range(len(state_history) - 2):
                if state_history[i] == state_history[i + 2] and state_history[i] != state_history[i + 1]:
                    warnings.append(PatternWarning(
                        pattern_type="oscillating_states",
                        severity="MEDIUM",
                        message=f"Shipment oscillating between states (pattern detected)",
                        shipment_id=str(shipment_id)
                    ))
                    break
    
    # Pattern 4: Stale shipments (stuck in non-terminal states for too long)
    stale_threshold = now - timedelta(days=7)
    stale_shipments = db.query(Shipment).filter(
        and_(
            Shipment.current_state.in_([ShipmentState.CREATED, ShipmentState.READY_FOR_PICKUP, ShipmentState.IN_TRANSIT]),
            Shipment.updated_at < stale_threshold,
            Shipment.deleted_at.is_(None)
        )
    ).limit(10).all()
    
    for shipment in stale_shipments:
        age_days = (now - shipment.updated_at).total_seconds() / 86400
        warnings.append(PatternWarning(
            pattern_type="stale_shipment",
            severity="LOW",
            message=f"Shipment stuck in {shipment.current_state.value} for {age_days:.1f} days",
            shipment_id=shipment.public_id
        ))
    
    # Pattern 5: Rapid transitions (too many in short time)
    if shipment_id:
        recent_transitions = [t for t in transitions if (now - t.timestamp).total_seconds() < 3600]
        if len(recent_transitions) >= 5:
            warnings.append(PatternWarning(
                pattern_type="rapid_transitions",
                severity="LOW",
                message=f"{len(recent_transitions)} transitions in last hour (may indicate system issue)",
                shipment_id=str(shipment_id)
            ))
    
    return warnings


def log_pattern_warnings(warnings: List[PatternWarning]):
    """Log detected pattern warnings"""
    for warning in warnings:
        log_func = {
            'LOW': logger.info,
            'MEDIUM': logger.warning,
            'HIGH': logger.error
        }.get(warning.severity, logger.warning)
        
        log_func(
            f"Pattern detected [{warning.pattern_type}] [{warning.severity}]: {warning.message} "
            f"(shipment_id={warning.shipment_id}, detected_at={warning.detected_at.isoformat()})"
        )


def get_health_indicators(db: Session) -> Dict[str, Any]:
    """
    Get health indicators based on detected patterns.
    
    Returns:
        Dictionary of health metrics
    """
    now = datetime.utcnow()
    
    # Count shipments in EXCEPTION state
    exception_count = db.query(Shipment).filter(
        and_(
            Shipment.current_state == ShipmentState.EXCEPTION,
            Shipment.deleted_at.is_(None)
        )
    ).count()
    
    # Count stale shipments
    stale_threshold = now - timedelta(days=7)
    stale_count = db.query(Shipment).filter(
        and_(
            Shipment.current_state.in_([ShipmentState.CREATED, ShipmentState.READY_FOR_PICKUP, ShipmentState.IN_TRANSIT]),
            Shipment.updated_at < stale_threshold,
            Shipment.deleted_at.is_(None)
        )
    ).count()
    
    # Count recent exceptions (last 24h)
    recent_exceptions = db.query(StateTransition).filter(
        and_(
            StateTransition.to_state == ShipmentState.EXCEPTION,
            StateTransition.timestamp >= now - timedelta(hours=24)
        )
    ).count()
    
    return {
        "exception_shipments": exception_count,
        "stale_shipments": stale_count,
        "recent_exceptions_24h": recent_exceptions,
        "health_status": "healthy" if exception_count < 10 and stale_count < 50 else "degraded",
        "timestamp": now.isoformat()
    }

