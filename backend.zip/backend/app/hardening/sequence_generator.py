"""
Global Event Ordering - Monotonic Sequence Generator
Provides globally monotonic sequence numbers for event ordering and audit.
Used ONLY for observability, debugging, and replay - NOT for correctness decisions.

Ordering Guarantees:
- Sequence numbers are monotonically increasing
- No gaps (except in rare database rollback scenarios)
- Database-level sequence ensures global ordering even under concurrency
- Timestamps should NOT be used for ordering - use sequence_number only

Limitations:
- Sequence numbers reflect database insertion order, not logical event order
- Clock skew or database replica lag can cause minor ordering ambiguities
- Sequence is per-database-instance (not distributed)
"""
from sqlalchemy import Sequence, func
from sqlalchemy.orm import Session
from app.database import SessionLocal
import logging

logger = logging.getLogger(__name__)

# Global sequence for event ordering
_event_sequence = Sequence('event_sequence', start=1, increment=1)


def get_next_sequence_number(db: Session) -> int:
    """
    Get next monotonic sequence number for event ordering.
    
    This function ensures globally monotonic ordering for audit purposes.
    Sequence numbers are assigned at database level for correctness under concurrency.
    
    Returns:
        int: Next sequence number (monotonically increasing)
    """
    from app.database import DATABASE_URL
    
    # SQLite doesn't support sequences - use timestamp-based fallback
    if DATABASE_URL.startswith("sqlite"):
        import time
        return int(time.time() * 1000000)  # Microsecond precision
    
    try:
        # Use database sequence for atomic, monotonic ordering (PostgreSQL)
        result = db.execute(func.nextval('event_sequence'))
        return result.scalar()
    except Exception as e:
        # Fallback: if sequence doesn't exist, try to create it
        logger.warning(f"Sequence 'event_sequence' not found, attempting to create: {e}")
        try:
            from sqlalchemy import text
            # Check if sequence exists (PostgreSQL only)
            check_result = db.execute(text(
                "SELECT EXISTS(SELECT 1 FROM pg_sequences WHERE sequencename = 'event_sequence')"
            ))
            if not check_result.scalar():
                db.execute(text("CREATE SEQUENCE event_sequence START 1 INCREMENT 1"))
                db.commit()
                logger.info("Created event_sequence for global event ordering")
            # Try again
            result = db.execute(func.nextval('event_sequence'))
            return result.scalar()
        except Exception as e2:
            logger.error(f"Failed to create/use event sequence: {e2}")
            # Ultimate fallback: use timestamp-based pseudo-sequence (not ideal but safe)
            import time
            return int(time.time() * 1000000)  # Microsecond precision

