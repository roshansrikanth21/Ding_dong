"""
Exception Classification - Classifies exceptions for safe recovery
Classifies exceptions into types: TEMPORARY, EXTERNAL, DATA, MANUAL
Used for recovery decision-making and audit purposes only.
"""
from enum import Enum
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class ExceptionType(str, Enum):
    """Exception classification types"""
    TEMPORARY = "TEMPORARY"  # Transient issue, likely to resolve automatically
    EXTERNAL = "EXTERNAL"    # External system failure (carrier API, etc.)
    DATA = "DATA"            # Data integrity or validation issue
    MANUAL = "MANUAL"        # Requires manual intervention


def classify_exception(reason: Optional[str], context: Optional[dict] = None) -> ExceptionType:
    """
    Classify an exception based on reason and context.
    
    Classification rules (rule-based, deterministic):
    - TEMPORARY: Network timeouts, temporary unavailability
    - EXTERNAL: Carrier API failures, third-party service issues
    - DATA: Validation errors, missing required data, format issues
    - MANUAL: Explicit manual triggers, ambiguous situations
    
    Args:
        reason: Exception reason string
        context: Optional context dictionary
    
    Returns:
        ExceptionType: Classified exception type
    """
    if not reason:
        return ExceptionType.MANUAL  # Default to manual if no reason
    
    reason_lower = reason.lower()
    context_lower = str(context or {}).lower()
    
    # TEMPORARY indicators
    temporary_keywords = ['timeout', 'temporary', 'retry', 'unavailable', 'busy', 'rate limit']
    if any(keyword in reason_lower or keyword in context_lower for keyword in temporary_keywords):
        return ExceptionType.TEMPORARY
    
    # EXTERNAL indicators
    external_keywords = ['carrier', 'api', 'external', 'third-party', 'service', 'network', 'connection']
    if any(keyword in reason_lower or keyword in context_lower for keyword in external_keywords):
        return ExceptionType.EXTERNAL
    
    # DATA indicators
    data_keywords = ['validation', 'invalid', 'missing', 'format', 'malformed', 'duplicate', 'constraint']
    if any(keyword in reason_lower or keyword in context_lower for keyword in data_keywords):
        return ExceptionType.DATA
    
    # Default to MANUAL for ambiguous cases
    return ExceptionType.MANUAL


def is_safe_to_recover(exception_type: ExceptionType, recovery_target_state) -> Tuple[bool, str]:
    """
    Determine if it's safe to recover from an exception type.
    
    Safety rules:
    - TEMPORARY: Safe to recover to any valid state
    - EXTERNAL: Safe if external issue resolved (requires context)
    - DATA: Unsafe - data issues must be fixed first
    - MANUAL: Safe only with explicit confirmation
    
    Args:
        exception_type: Classified exception type
        recovery_target_state: Target state for recovery
    
    Returns:
        Tuple of (is_safe: bool, explanation: str)
    """
    if exception_type == ExceptionType.TEMPORARY:
        return True, "TEMPORARY exceptions can be safely recovered"
    
    if exception_type == ExceptionType.EXTERNAL:
        return True, "EXTERNAL exceptions can be recovered if external service is restored"
    
    if exception_type == ExceptionType.DATA:
        return False, "DATA exceptions require data correction before recovery"
    
    if exception_type == ExceptionType.MANUAL:
        return True, "MANUAL exceptions can be recovered with explicit confirmation"
    
    return False, f"Unknown exception type: {exception_type}"

