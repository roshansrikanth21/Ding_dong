"""
Shipment Service - Handles shipment business logic with transactional safety.
"""
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from datetime import datetime
import uuid
import logging

from app.models import Shipment, ShipmentState
from app.repositories.shipment_repository import ShipmentRepository
from app.repositories.transition_repository import TransitionRepository
from app.validators.shipment_validator import ShipmentValidator, ValidationError
from app.tracking_validator import validate_tracking_number
from app.services.state_service import StateService, StateTransitionError

logger = logging.getLogger(__name__)


class ShipmentService:
    """Service for handling shipment operations with production-grade reliability"""
    
    def __init__(self, db: Session):
        self.db = db
        self.shipment_repo = ShipmentRepository(db)
        self.transition_repo = TransitionRepository(db)
        self.state_service = StateService(db)
        self.validator = ShipmentValidator()
    
    def create_shipment(
        self,
        tracking_number: str,
        carrier: Optional[str] = None,
        notes: Optional[str] = None,
        actor: str = "system",
        origin: Optional[str] = None,
        destination: Optional[str] = None,
        product_type: Optional[str] = None,
        is_fragile: Optional[str] = None,
        storage_locations: Optional[str] = None,
        scheduled_date: Optional[datetime] = None,
        estimated_delivery: Optional[datetime] = None
    ) -> Shipment:
        """
        Create a new shipment with full validation and transactional safety.
        
        Args:
            tracking_number: Tracking number
            carrier: Optional carrier name
            notes: Optional notes
            actor: Who created the shipment
            origin: Optional origin location
            destination: Optional destination location
            product_type: Optional product type
            is_fragile: Optional fragility (FRAGILE or NON_FRAGILE)
            storage_locations: Optional JSON string of storage waypoints
            scheduled_date: Optional scheduled date
            estimated_delivery: Optional estimated delivery date
            
        Returns:
            Created Shipment
            
        Raises:
            ValidationError: If validation fails
        """
        # Early validation before any database operations
        is_valid, error = self.validator.validate_shipment_creation(tracking_number, carrier)
        if not is_valid:
            raise ValidationError(error, field="tracking_number")
        
        if notes:
            is_valid, error = self.validator.validate_notes(notes)
            if not is_valid:
                raise ValidationError(error, field="notes")
        
        # Check if tracking number already exists (including soft-deleted)
        existing = self.shipment_repo.get_by_tracking_number(tracking_number, include_deleted=True)
        
        if existing:
            if existing.deleted_at is None:
                raise ValidationError("Tracking number already exists", field="tracking_number", code="DUPLICATE")
            
            # If soft-deleted, restore it
            return self._restore_shipment(existing, tracking_number, carrier, notes, actor)
        
        # Detect carrier if not provided
        if not carrier:
            _, _, detected_carrier = validate_tracking_number(tracking_number, strict=False)
            carrier = detected_carrier
        
        # Create new shipment
        try:
            now = datetime.utcnow()
            # Get next serial number from sequence
            serial_number = self.shipment_repo.get_next_serial_number()
            shipment = Shipment(
                tracking_number=tracking_number.upper().strip(),
                serial_number=serial_number,
                carrier=carrier,
                current_state=ShipmentState.CREATED,
                notes=notes,
                state_version="1.0",  # Use default state machine version
                version=1,
                state_entered_at=now,  # HARDENING: Track state entry time for SLA
                # Inventory fields
                origin=origin,
                destination=destination,
                product_type=product_type,
                is_fragile=is_fragile or 'NON_FRAGILE',
                storage_locations=storage_locations,
                scheduled_date=scheduled_date,
                estimated_delivery=estimated_delivery
            )
            
            # Generate public_id before use
            if not shipment.public_id:
                shipment.public_id = str(uuid.uuid4())
            
            self.shipment_repo.create(shipment)
            self.db.flush()  # Flush to get the shipment ID, but don't commit yet
            
            # Create initial state transition directly (no transition validation needed for initial state)
            # Use from_state=None to indicate this is the initial state entry
            from app.models import StateTransition
            from app.hardening.sequence_generator import get_next_sequence_number
            
            initial_transition = StateTransition(
                shipment_id=shipment.id,
                from_state=None,  # None indicates initial state (no previous state)
                to_state=ShipmentState.CREATED,
                actor=actor,
                reason="Shipment created",
                transition_version=shipment.state_version,
                sequence_number=get_next_sequence_number(self.db),
                timestamp=now
            )
            
            self.db.add(initial_transition)
            self.db.flush()
            
            # Single commit for both shipment creation and initial transition
            self.db.commit()
            self.db.refresh(shipment)
            
            logger.info(f"Shipment created: public_id={shipment.public_id}, tracking_number={tracking_number}")
            
            return shipment
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error creating shipment: {str(e)}", exc_info=True)
            raise
    
    def _restore_shipment(
        self,
        existing: Shipment,
        tracking_number: str,
        carrier: Optional[str],
        notes: Optional[str],
        actor: str
    ) -> Shipment:
        """Restore a soft-deleted shipment"""
        # Ensure public_id exists
        if not existing.public_id:
            existing.public_id = str(uuid.uuid4())
        
        # Re-detect carrier if not provided
        if not carrier:
            _, _, detected_carrier = validate_tracking_number(tracking_number, strict=False)
            carrier = detected_carrier
        
        # Ensure public_id exists before use
        if not existing.public_id:
            existing.public_id = str(uuid.uuid4())
        
        # Restore shipment
        now = datetime.utcnow()
        existing.deleted_at = None
        existing.current_state = ShipmentState.CREATED
        existing.carrier = carrier
        existing.notes = notes
        existing.updated_at = now
        existing.version += 1
        existing.state_entered_at = now  # HARDENING: Track state entry time for SLA
        
        self.shipment_repo.update(existing)
        self.db.flush()  # Flush before transition to ensure consistency
        
        # Create restoration transition (within same transaction)
        # Since we're restoring to CREATED, create transition directly with from_state=None
        from app.models import StateTransition
        from app.hardening.sequence_generator import get_next_sequence_number
        
        now = datetime.utcnow()
        restoration_transition = StateTransition(
            shipment_id=existing.id,
            from_state=None,  # None indicates restoration/initial state
            to_state=ShipmentState.CREATED,
            actor=actor,
            reason="Shipment restored from soft-delete",
            transition_version=existing.state_version,
            sequence_number=get_next_sequence_number(self.db),
            timestamp=now
        )
        
        self.db.add(restoration_transition)
        self.db.flush()
        
        # Single commit for both restore and transition
        self.db.commit()
        self.db.refresh(existing)
        
        logger.info(f"Shipment restored: public_id={existing.public_id}, tracking_number={tracking_number}")
        
        return existing
    
    def update_notes(
        self,
        shipment_id: str,
        notes: Optional[str],
        actor: str = "system"
    ) -> Shipment:
        """
        Update shipment notes with validation.
        Notes can be updated even in terminal states.
        """
        # Early validation
        is_valid, error = self.validator.validate_notes(notes)
        if not is_valid:
            raise ValidationError(error, field="notes")
        
        shipment = self.shipment_repo.get_by_public_id(shipment_id)
        if not shipment:
            raise ValidationError("Shipment not found", code="NOT_FOUND")
        
        shipment.notes = notes
        shipment.version += 1
        shipment.updated_at = datetime.utcnow()
        
        self.shipment_repo.update(shipment)
        self.db.commit()
        self.db.refresh(shipment)
        
        return shipment
    
    def delete_shipment(
        self,
        shipment_id: str,
        permanent: bool = False,
        actor: str = "system"
    ) -> None:
        """
        Delete a shipment (soft or permanent) with validation.
        """
        shipment = self.shipment_repo.get_by_public_id(shipment_id, include_deleted=True)
        if not shipment:
            raise ValidationError("Shipment not found", code="NOT_FOUND")
        
        # Early validation
        is_valid, error = self.validator.validate_delete_operation(shipment.current_state, permanent)
        if not is_valid:
            raise ValidationError(error, code="INVALID_DELETE_STATE")
        
        if permanent:
            self.shipment_repo.delete_permanent(shipment)
            logger.info(f"Shipment permanently deleted: public_id={shipment_id}, actor={actor}")
        else:
            self.shipment_repo.delete_soft(shipment)
            logger.info(f"Shipment soft deleted: public_id={shipment_id}, actor={actor}")
        
        self.db.commit()

