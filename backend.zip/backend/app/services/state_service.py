"""
State Service - Handles state transitions with transactional safety and retry logic.
This service implements the core business logic for state management.
"""
from typing import Optional, Tuple, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy.exc import OperationalError, IntegrityError
from datetime import datetime
import time
import logging

from app.models import Shipment, StateTransition, ShipmentState
from app.state_machine import get_state_machine
from app.repositories.shipment_repository import ShipmentRepository
from app.repositories.transition_repository import TransitionRepository
from app.hardening.invariants import check_pre_transition_invariants, check_post_transition_invariants, check_state_duration_invariants
from app.hardening.sequence_generator import get_next_sequence_number
from app.hardening.exception_classifier import classify_exception
from app.hardening.observability import detect_abnormal_patterns, log_pattern_warnings

logger = logging.getLogger(__name__)


class StateTransitionError(Exception):
    """Custom exception for state transition failures"""
    def __init__(self, message: str, retryable: bool = False, code: str = None):
        self.message = message
        self.retryable = retryable
        self.code = code
        super().__init__(self.message)


class StateService:
    """Service for handling state transitions with production-grade reliability"""
    
    def __init__(self, db: Session, state_machine=None):
        self.db = db
        self.state_machine = state_machine or get_state_machine()
        self.shipment_repo = ShipmentRepository(db)
        self.transition_repo = TransitionRepository(db)
    
    @staticmethod
    def _format_user_friendly_error(
        from_state: ShipmentState,
        target_state: ShipmentState,
        original_error: str
    ) -> str:
        """
        Format error message for user clarity.
        This is read-only formatting - does not change validation logic.
        """
        # Map common error patterns to user-friendly messages
        if "Cannot transition from" in original_error and "to itself" in original_error:
            return f"Transition denied: shipment is already in {from_state.value} state."
        
        if "Invalid transition from" in original_error:
            # Extract allowed states from error message if available
            if "Allowed transitions:" in original_error:
                allowed_part = original_error.split("Allowed transitions:")[-1].strip()
                return f"Transition denied: shipment must be in one of these states before transitioning to {target_state.value}: {allowed_part}"
            else:
                return f"Transition denied: shipment must be {StateService._get_required_state(target_state)} before it can be {target_state.value}."
        
        # Fallback to original error if no pattern matches
        return original_error
    
    @staticmethod
    def _get_required_state(target_state: ShipmentState) -> str:
        """
        Get the required previous state for a target state.
        This is informational only - actual validation happens in state machine.
        """
        requirements = {
            ShipmentState.READY_FOR_PICKUP: "CREATED",
            ShipmentState.IN_TRANSIT: "READY_FOR_PICKUP",
            ShipmentState.DELIVERED: "IN_TRANSIT",
            ShipmentState.CANCELLED: "CREATED or READY_FOR_PICKUP",
        }
        return requirements.get(target_state, "in a valid previous state")
    
    def transition_state(
        self,
        shipment: Shipment,
        target_state: ShipmentState,
        actor: Optional[str] = None,
        reason: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        command_id: Optional[str] = None,  # TASK 2: Command ID for idempotency
        expected_version: Optional[int] = None
    ) -> Tuple[StateTransition, Shipment]:
        """
        Transition shipment to a new state with full transactional safety.
        
        Args:
            shipment: The shipment to transition
            target_state: Target state
            actor: Who/what initiated the transition
            reason: Business reason for transition
            metadata: Additional context
            idempotency_key: Unique key to prevent duplicate transitions
            expected_version: Expected version for optimistic locking
            
        Returns:
            Tuple of (StateTransition, updated Shipment)
            
        Raises:
            StateTransitionError: If transition fails
        """
        # Early validation before any database operations
        if shipment.deleted_at is not None:
            raise StateTransitionError("Cannot transition soft-deleted shipment", retryable=False)
        
        # HARDENING: Pre-transition invariant checks (guard-based, additive only)
        try:
            checked_invariants = check_pre_transition_invariants(shipment, target_state)
            logger.debug(f"Pre-transition invariants checked: {checked_invariants}")
        except Exception as e:
            # Invariant violations are fatal - fail fast
            logger.error(f"Pre-transition invariant violation: {str(e)}")
            raise StateTransitionError(f"Invariant violation: {str(e)}", retryable=False, code="INVARIANT_VIOLATION")
        
        # Validate transition using state machine
        is_valid, error_msg = self.state_machine.is_valid_transition(
            shipment.current_state,
            target_state,
            shipment.state_version
        )
        if not is_valid:
            # OBSERVABILITY: Record blocked transition (passive, does not affect rejection)
            from app.observability.blocked_counter import get_blocked_counter
            blocked_counter = get_blocked_counter()
            blocked_counter.record_blocked(
                from_state=shipment.current_state.value,
                to_state=target_state.value,
                reason=error_msg
            )
            
            # Enhance error message for user clarity (read-only, no logic change)
            user_friendly_msg = self._format_user_friendly_error(
                shipment.current_state,
                target_state,
                error_msg
            )
            
            raise StateTransitionError(user_friendly_msg, retryable=False, code="INVALID_TRANSITION")
        
        # TASK 2: Check for duplicate command_id first (idempotency per shipment)
        if command_id:
            existing = self.transition_repo.find_by_command_id(shipment.id, command_id)
            if existing:
                logger.info(f"Duplicate command detected for command_id: {command_id} on shipment {shipment.id}")
                # Return existing transition (idempotent behavior) - no state mutation
                shipment_refreshed = self.shipment_repo.get_by_id(shipment.id)
                return existing, shipment_refreshed
        
        # Check for duplicate transition using idempotency key (before any DB writes)
        if idempotency_key:
            existing = self.transition_repo.find_by_idempotency_key(idempotency_key)
            if existing:
                logger.info(f"Duplicate transition detected for idempotency_key: {idempotency_key}")
                # Return existing transition (idempotent behavior)
                shipment_refreshed = self.shipment_repo.get_by_id(shipment.id)
                return existing, shipment_refreshed
        
        # Optimistic locking check
        if expected_version is not None and shipment.version != expected_version:
            raise StateTransitionError(
                f"Version mismatch: expected {expected_version}, got {shipment.version}. "
                "Another operation may have modified this shipment.",
                retryable=True,
                code="VERSION_CONFLICT"
            )
        
        # Check for duplicate transition to same state (prevent duplicates)
        # This should happen after idempotency check but before transaction
        existing_dup = self.transition_repo.check_duplicate_transition(shipment.id, target_state)
        if existing_dup and not idempotency_key:  # Allow if idempotency key provided (different use case)
            logger.info(f"Duplicate transition to {target_state.value} detected for shipment {shipment.id}")
            shipment_refreshed = self.shipment_repo.get_by_id(shipment.id)
            return existing_dup, shipment_refreshed
        
        # Atomic transaction: update state and create audit log
        try:
            from_state = shipment.current_state
            
            # Lock the shipment row to prevent concurrent modifications
            # Refresh with FOR UPDATE to get exclusive lock
            from sqlalchemy import select
            locked_shipment = self.db.query(Shipment).with_for_update().filter(Shipment.id == shipment.id).first()
            if not locked_shipment:
                raise StateTransitionError("Shipment not found after lock", retryable=False)
            
            # Re-validate version after acquiring lock (double-check)
            if expected_version is not None and locked_shipment.version != expected_version:
                raise StateTransitionError(
                    f"Version mismatch after lock: expected {expected_version}, got {locked_shipment.version}.",
                    retryable=True,
                    code="VERSION_CONFLICT"
                )
            
            # Use locked shipment for update
            shipment = locked_shipment
            
            # HARDENING: Track state entry time for SLA awareness
            now = datetime.utcnow()
            if shipment.current_state != target_state:
                # State is changing - record entry time
                shipment.state_entered_at = now
            
            # Update shipment state
            shipment.current_state = target_state
            shipment.version += 1  # Increment for optimistic locking
            shipment.updated_at = now
            
            # Clear exception fields if recovering
            if from_state == ShipmentState.EXCEPTION:
                shipment.exception_reason = None
                shipment.exception_type = None
                shipment.exception_at = None
            
            # Set exception fields if entering EXCEPTION state
            if target_state == ShipmentState.EXCEPTION:
                exception_reason_value = reason or "System exception"
                shipment.exception_reason = exception_reason_value
                shipment.exception_at = now
                # HARDENING: Classify exception type
                shipment.exception_type = classify_exception(exception_reason_value, metadata).value
            
            # HARDENING: Get global sequence number for event ordering
            sequence_num = get_next_sequence_number(self.db)
            
            # Create audit log entry
            transition = StateTransition(
                shipment_id=shipment.id,
                from_state=from_state,
                to_state=target_state,
                actor=actor or "system",
                reason=reason,
                transition_metadata=str(metadata) if metadata else None,
                transition_version=shipment.state_version,
                transition_idempotency_key=idempotency_key,
                command_id=command_id,  # TASK 2: Store command_id for idempotency
                sequence_number=sequence_num,  # Global event ordering
                timestamp=now
            )
            
            self.db.add(transition)
            self.db.flush()  # Flush to get IDs and check constraints, but don't commit yet
            # Note: Caller is responsible for committing the transaction
            
            # HARDENING: Post-transition invariant checks
            try:
                checked_invariants = check_post_transition_invariants(shipment, target_state)
                logger.debug(f"Post-transition invariants checked: {checked_invariants}")
            except Exception as e:
                # Invariant violations are fatal - rollback
                self.db.rollback()
                logger.error(f"Post-transition invariant violation: {str(e)}")
                raise StateTransitionError(f"Post-transition invariant violation: {str(e)}", retryable=False, code="INVARIANT_VIOLATION")
            
            # HARDENING: Check SLA thresholds (observational, non-blocking)
            if shipment.state_entered_at:
                state_duration = (now - shipment.state_entered_at).total_seconds() / 3600
                sla_warnings = check_state_duration_invariants(shipment, state_duration)
                for warning in sla_warnings:
                    logger.warning(f"SLA warning for shipment {shipment.id}: {warning}")
            
            # HARDENING: Detect abnormal patterns (observational, non-blocking)
            try:
                pattern_warnings = detect_abnormal_patterns(self.db, shipment.id)
                log_pattern_warnings(pattern_warnings)
            except Exception as e:
                # Pattern detection failures should not block transitions
                logger.warning(f"Pattern detection failed (non-blocking): {str(e)}")
            
            logger.info(
                f"State transition prepared: shipment_id={shipment.id}, "
                f"from={from_state.value}, to={target_state.value}, "
                f"actor={actor}, version={shipment.version}, sequence={sequence_num}"
            )
            
            return transition, shipment
            
        except IntegrityError as e:
            self.db.rollback()
            # Check if it's a duplicate idempotency key
            if "transition_idempotency_key" in str(e):
                existing = self.transition_repo.find_by_idempotency_key(idempotency_key)
                if existing:
                    return existing, self.shipment_repo.get_by_id(shipment.id)
            raise StateTransitionError(
                f"Database integrity error: {str(e)}",
                retryable=False,
                code="INTEGRITY_ERROR"
            )
        except OperationalError as e:
            self.db.rollback()
            raise StateTransitionError(
                f"Database operation error: {str(e)}",
                retryable=True,
                code="DATABASE_ERROR"
            )
        except Exception as e:
            self.db.rollback()
            logger.error(f"Unexpected error during state transition: {str(e)}", exc_info=True)
            raise StateTransitionError(
                f"Unexpected error: {str(e)}",
                retryable=False,
                code="UNKNOWN_ERROR"
            )
    
    def transition_with_retry(
        self,
        shipment_id: str,
        target_state: ShipmentState,
        actor: Optional[str] = None,
        reason: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        command_id: Optional[str] = None,  # TASK 2: Command ID for idempotency
        max_retries: int = 3,
        initial_backoff: float = 0.1
    ) -> Tuple[StateTransition, Shipment]:
        """
        Transition with exponential backoff retry for transient failures.
        
        Args:
            shipment_id: Public ID of shipment
            target_state: Target state
            actor: Who initiated transition
            reason: Business reason
            metadata: Additional context
            idempotency_key: Idempotency key
            max_retries: Maximum retry attempts
            initial_backoff: Initial backoff in seconds
            
        Returns:
            Tuple of (StateTransition, updated Shipment)
        """
        retry_count = 0
        backoff = initial_backoff
        
        last_error = None
        
        while retry_count <= max_retries:
            try:
                # Reload shipment on each retry to get fresh version
                shipment = self.shipment_repo.get_by_public_id(shipment_id)
                if not shipment:
                    raise StateTransitionError("Shipment not found", retryable=False)
                
                # Use current version for optimistic locking (will be None on first attempt)
                expected_ver = shipment.version if retry_count == 0 else None
                
                return self.transition_state(
                    shipment=shipment,
                    target_state=target_state,
                    actor=actor,
                    reason=reason,
                    metadata=metadata,
                    idempotency_key=idempotency_key,
                    command_id=command_id,  # TASK 2: Pass command_id
                    expected_version=expected_ver
                )
                
            except StateTransitionError as e:
                last_error = e
                if not e.retryable or retry_count >= max_retries:
                    raise
                
                retry_count += 1
                logger.warning(
                    f"Retryable error during transition (attempt {retry_count}/{max_retries}): {e.message}"
                )
                time.sleep(backoff)
                backoff *= 2  # Exponential backoff
                
            except Exception as e:
                logger.error(f"Non-retryable error during transition: {str(e)}", exc_info=True)
                raise StateTransitionError(
                    f"Non-retryable error: {str(e)}",
                    retryable=False
                )
        
        # If we get here, max retries exceeded
        if last_error:
            raise last_error
        raise StateTransitionError(
            f"Max retries ({max_retries}) exceeded",
            retryable=False,
            code="MAX_RETRIES_EXCEEDED"
        )
    
    def recover_from_exception(
        self,
        shipment_id: str,
        target_state: ShipmentState,
        actor: str,
        reason: str,
        command_id: Optional[str] = None  # TASK 2: Command ID for idempotency
    ) -> Tuple[StateTransition, Shipment]:
        """
        Recover a shipment from EXCEPTION state to a valid state.
        This is a specialized transition that allows recovery from errors.
        """
        shipment = self.shipment_repo.get_by_public_id(shipment_id)
        if not shipment:
            raise StateTransitionError("Shipment not found", retryable=False)
        
        if shipment.current_state != ShipmentState.EXCEPTION:
            raise StateTransitionError(
                f"Cannot recover from {shipment.current_state.value}. Shipment must be in EXCEPTION state.",
                retryable=False,
                code="NOT_IN_EXCEPTION"
            )
        
        # Validate target state is recoverable (not EXCEPTION)
        if target_state == ShipmentState.EXCEPTION:
            raise StateTransitionError(
                "Cannot recover to EXCEPTION state",
                retryable=False,
                code="INVALID_RECOVERY_TARGET"
            )
        
        return self.transition_with_retry(
            shipment_id=shipment_id,
            target_state=target_state,
            actor=actor,
            reason=f"Recovery: {reason}",
            metadata={"recovery": True, "previous_exception": shipment.exception_reason},
            command_id=command_id  # TASK 2: Pass command_id
        )

