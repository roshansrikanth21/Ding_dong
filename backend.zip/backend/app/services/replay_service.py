"""
Replay Service - TASK 1: Replay Integrity Enforcement
Replays events with invariant checks. Aborts on any violation.
"""
from typing import List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
import logging

from app.models import Shipment, StateTransition, ShipmentState
from app.state_machine import get_state_machine
from app.hardening.invariants import check_pre_transition_invariants, check_post_transition_invariants, InvariantViolation
from app.repositories.shipment_repository import ShipmentRepository
from app.repositories.transition_repository import TransitionRepository
from app.services.state_service import StateTransitionError

logger = logging.getLogger(__name__)


class ReplayIntegrityError(Exception):
    """Raised when replay violates invariants"""
    def __init__(self, message: str, violation_details: str = None):
        self.message = message
        self.violation_details = violation_details
        super().__init__(self.message)


class ReplayService:
    """
    Replay service with integrity enforcement.
    Applies same invariants as live command processing.
    Aborts on any violation - no silent recovery, no best-effort reconstruction.
    """
    
    # TASK 4: Replay abuse guardrails
    MAX_REPLAY_EVENTS = 1000  # Cap replay length
    
    def __init__(self, db: Session):
        self.db = db
        self.shipment_repo = ShipmentRepository(db)
        self.transition_repo = TransitionRepository(db)
        self.state_machine = get_state_machine()
    
    def replay_events(
        self,
        shipment_id: str,
        max_events: int = None
    ) -> Tuple[List[StateTransition], dict]:
        """
        Replay events for a shipment with full invariant enforcement.
        
        TASK 1: Replay Integrity Enforcement
        - Applies same invariants as live command processing
        - Aborts on any violation
        - Returns explicit failure details
        
        TASK 4: Replay Abuse Guardrails
        - Caps replay length (max N events)
        - Rejects overly large replay requests
        
        Args:
            shipment_id: Public ID of shipment
            max_events: Maximum events to replay (default: MAX_REPLAY_EVENTS)
            
        Returns:
            Tuple of (replayed_transitions, summary)
            
        Raises:
            ReplayIntegrityError: If any invariant is violated during replay
        """
        # TASK 4: Cap replay length
        if max_events is None:
            max_events = self.MAX_REPLAY_EVENTS
        elif max_events > self.MAX_REPLAY_EVENTS:
            raise ReplayIntegrityError(
                f"Replay request exceeds maximum allowed events ({self.MAX_REPLAY_EVENTS}). "
                f"Replay is debug-only and cannot process more than {self.MAX_REPLAY_EVENTS} events.",
                violation_details=f"Requested {max_events} events, maximum is {self.MAX_REPLAY_EVENTS}"
            )
        
        # Get shipment
        shipment = self.shipment_repo.get_by_public_id(shipment_id)
        if not shipment:
            raise ReplayIntegrityError(f"Shipment not found: {shipment_id}")
        
        # Get all transitions for this shipment
        transitions = self.transition_repo.get_by_shipment_id(shipment.id)
        
        if len(transitions) > max_events:
            raise ReplayIntegrityError(
                f"Shipment has {len(transitions)} events, exceeding maximum replay length ({max_events}). "
                "Replay is debug-only.",
                violation_details=f"Found {len(transitions)} events, maximum is {max_events}"
            )
        
        if not transitions:
            return [], {"message": "No events to replay", "events_processed": 0}
        
        # TASK 1: Replay with invariant checks
        replayed = []
        violations = []
        
        # Save original state (for restoration)
        original_state = shipment.current_state
        original_version = shipment.version
        
        # Start replay from initial state (CREATED)
        shipment.current_state = ShipmentState.CREATED
        shipment.version = 1
        
        try:
            # Replay each transition with invariant checks
            for idx, transition in enumerate(transitions):
                try:
                    # TASK 1: Apply pre-transition invariants
                    try:
                        check_pre_transition_invariants(shipment, transition.to_state)
                    except InvariantViolation as iv:
                        violation = f"Event {idx + 1}: Pre-transition invariant violation: {str(iv)}"
                        violations.append(violation)
                        raise ReplayIntegrityError(
                            f"Replay aborted at event {idx + 1}: Invariant violation",
                            violation_details=violation
                        )
                    
                    # Validate transition using state machine
                    is_valid, error_msg = self.state_machine.is_valid_transition(
                        shipment.current_state,
                        transition.to_state,
                        shipment.state_version
                    )
                    
                    if not is_valid:
                        violation = f"Event {idx + 1}: Invalid transition from {shipment.current_state.value} to {transition.to_state.value}. {error_msg}"
                        violations.append(violation)
                        raise ReplayIntegrityError(
                            f"Replay aborted at event {idx + 1}: Invalid transition",
                            violation_details=violation
                        )
                    
                    # Apply transition (simulate, don't persist)
                    from_state = shipment.current_state
                    shipment.current_state = transition.to_state
                    shipment.version += 1
                    
                    # TASK 1: Apply post-transition invariants
                    try:
                        check_post_transition_invariants(shipment, transition.to_state)
                    except InvariantViolation as iv:
                        violation = f"Event {idx + 1}: Post-transition invariant violation: {str(iv)}"
                        violations.append(violation)
                        raise ReplayIntegrityError(
                            f"Replay aborted at event {idx + 1}: Invariant violation",
                            violation_details=violation
                        )
                    
                    replayed.append(transition)
                    logger.debug(f"Replayed event {idx + 1}/{len(transitions)}: {from_state.value} -> {transition.to_state.value}")
                    
                except ReplayIntegrityError:
                    raise
                except Exception as e:
                    violation = f"Event {idx + 1}: {str(e)}"
                    violations.append(violation)
                    raise ReplayIntegrityError(
                        f"Replay aborted at event {idx + 1} due to unexpected error",
                        violation_details=violation
                    )
            
            # TASK 1: Final state validation
            if shipment.current_state != original_state:
                violation = f"Replay resulted in different final state: expected {original_state.value}, got {shipment.current_state.value}"
                violations.append(violation)
                raise ReplayIntegrityError(
                    "Replay integrity violation: Final state mismatch",
                    violation_details=violation
                )
            
            summary = {
                "message": "Replay completed successfully",
                "events_processed": len(replayed),
                "violations": []
            }
            
            return replayed, summary
            
        except ReplayIntegrityError as e:
            # Restore original state (don't commit - replay is read-only validation)
            shipment.current_state = original_state
            shipment.version = original_version
            self.db.rollback()  # Ensure no changes are persisted
            
            summary = {
                "message": "Replay aborted due to integrity violations",
                "events_processed": len(replayed),
                "violations": violations,
                "replay_valid": False
            }
            
            raise
        except Exception as e:
            # Restore original state (don't commit - replay is read-only validation)
            shipment.current_state = original_state
            shipment.version = original_version
            self.db.rollback()  # Ensure no changes are persisted
            
            violation = f"Unexpected error during replay: {str(e)}"
            raise ReplayIntegrityError(
                "Replay aborted due to unexpected error",
                violation_details=violation
            )
        finally:
            # Always restore original state (replay should never mutate)
            shipment.current_state = original_state
            shipment.version = original_version
            # Don't commit - replay is validation-only

