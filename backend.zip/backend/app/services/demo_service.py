"""
Demo Service - Handles demo data seeding and reset capabilities.
Safe for evaluation and demonstration purposes.
"""
from typing import List, Optional
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import random
import logging

from app.models import Shipment, StateTransition, ShipmentState
from app.repositories.shipment_repository import ShipmentRepository
from app.repositories.transition_repository import TransitionRepository
from app.services.shipment_service import ShipmentService
from app.services.state_service import StateService
from app.tracking_validator import get_tracking_info

logger = logging.getLogger(__name__)


class DemoService:
    """Service for demo data and reset operations"""
    
    def __init__(self, db: Session):
        self.db = db
        self.shipment_service = ShipmentService(db)
        self.state_service = StateService(db)
        self.shipment_repo = ShipmentRepository(db)
        self.transition_repo = TransitionRepository(db)
    
    def seed_demo_data(self, count: int = 20, actor: str = "demo") -> dict:
        """
        Seed demo data for evaluation and demonstration.
        Creates shipments in various states with realistic transitions.
        """
        try:
            created = []
            carriers = ["INDIA_POST", "BLUE_DART", "DHL_EXPRESS", "DELHIVERY", "UPS", "FEDEX"]
            states = [
                ShipmentState.CREATED,
                ShipmentState.READY_FOR_PICKUP,
                ShipmentState.IN_TRANSIT,
                ShipmentState.DELIVERED,
                ShipmentState.CANCELLED,
                ShipmentState.EXCEPTION,  # Include some exception states for demo
            ]
            
            # Generate realistic tracking numbers
            tracking_formats = [
                "EE{}{}{}{}{}{}{}{}{}IN",  # India Post
                "{}{}{}{}{}{}{}{}{}{}{}{}",  # Generic numeric
                "1Z{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}",  # UPS format
            ]
            
            for i in range(count):
                try:
                    # Generate tracking number
                    format_template = random.choice(tracking_formats)
                    digits = ''.join([str(random.randint(0, 9)) for _ in range(20)])
                    tracking_number = format_template.format(*digits)[:50]  # Ensure max length
                    
                    # Check if already exists
                    existing = self.shipment_repo.get_by_tracking_number(tracking_number, include_deleted=True)
                    if existing:
                        continue  # Skip if exists
                    
                    # Create shipment
                    shipment = self.shipment_service.create_shipment(
                        tracking_number=tracking_number,
                        carrier=random.choice(carriers),
                        notes=f"Demo shipment #{i+1}",
                        actor=actor
                    )
                    
                    # Create some transitions to make it realistic
                    target_state = random.choice(states)
                    if target_state != ShipmentState.CREATED:
                        try:
                            # Add transitions based on state machine rules
                            transition_path = self._get_transition_path(ShipmentState.CREATED, target_state)
                            for next_state in transition_path:
                                if next_state != ShipmentState.CREATED:
                                    self.state_service.transition_with_retry(
                                        shipment_id=shipment.public_id,
                                        target_state=next_state,
                                        actor=actor,
                                        reason=f"Demo transition to {next_state.value}",
                                        max_retries=1
                                    )
                        except Exception as e:
                            logger.warning(f"Could not transition demo shipment {shipment.public_id}: {e}")
                            # Leave it in CREATED state if transitions fail
                    
                    created.append(shipment.public_id)
                    
                except Exception as e:
                    logger.warning(f"Failed to create demo shipment {i+1}: {e}")
                    continue
            
            self.db.commit()
            
            return {
                "seeded": len(created),
                "shipment_ids": created,
                "message": f"Successfully seeded {len(created)} demo shipments"
            }
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error seeding demo data: {str(e)}", exc_info=True)
            raise
    
    def _get_transition_path(self, from_state: ShipmentState, to_state: ShipmentState) -> List[ShipmentState]:
        """Get a valid transition path from one state to another"""
        # Simple path finding for demo purposes
        if from_state == to_state:
            return [to_state]
        
        # Direct transition
        from app.state_machine import get_state_machine
        state_machine = get_state_machine()
        is_valid, _ = state_machine.is_valid_transition(from_state, to_state)
        if is_valid:
            return [from_state, to_state]
        
        # Try intermediate paths (simplified)
        intermediate_states = [ShipmentState.READY_FOR_PICKUP, ShipmentState.IN_TRANSIT]
        
        for intermediate in intermediate_states:
            is_valid1, _ = state_machine.is_valid_transition(from_state, intermediate)
            is_valid2, _ = state_machine.is_valid_transition(intermediate, to_state)
            if is_valid1 and is_valid2:
                return [from_state, intermediate, to_state]
        
        # Fallback: just return target state
        return [from_state]
    
    def reset_demo_data(self, keep_count: int = 0, actor: str = "demo") -> dict:
        """
        Reset demo data while optionally keeping some shipments.
        Safe operation that doesn't affect production data.
        """
        try:
            # Get all shipments
            all_shipments, total = self.shipment_repo.list(
                page=1,
                limit=10000,
                include_deleted=True
            )
            
            if keep_count > 0:
                # Keep oldest shipments
                shipments_to_delete = all_shipments[keep_count:]
            else:
                shipments_to_delete = all_shipments
            
            deleted_count = 0
            for shipment in shipments_to_delete:
                try:
                    # Delete transitions first (CASCADE should handle this, but be explicit)
                    transitions = self.transition_repo.get_by_shipment_id(shipment.id)
                    for transition in transitions:
                        self.db.delete(transition)
                    
                    # Delete shipment
                    self.db.delete(shipment)
                    deleted_count += 1
                except Exception as e:
                    logger.warning(f"Failed to delete shipment {shipment.public_id}: {e}")
            
            self.db.commit()
            
            return {
                "deleted": deleted_count,
                "remaining": total - deleted_count,
                "message": f"Reset completed: deleted {deleted_count} shipments, kept {total - deleted_count}"
            }
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error resetting demo data: {str(e)}", exc_info=True)
            raise
    
    def create_demo_scenarios(self, actor: str = "demo") -> dict:
        """
        Create predefined success and failure scenarios for evaluation.
        """
        scenarios = {
            "success_path": [],
            "exception_recovery": [],
            "cancelled": [],
        }
        
        try:
            # Success path: CREATED -> READY_FOR_PICKUP -> IN_TRANSIT -> DELIVERED
            success = self.shipment_service.create_shipment(
                tracking_number=f"DEMO-SUCCESS-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                carrier="DHL_EXPRESS",
                notes="Demo: Successful delivery path",
                actor=actor
            )
            
            for state in [ShipmentState.READY_FOR_PICKUP, ShipmentState.IN_TRANSIT, ShipmentState.DELIVERED]:
                try:
                    self.state_service.transition_with_retry(
                        shipment_id=success.public_id,
                        target_state=state,
                        actor=actor,
                        reason=f"Demo: Transition to {state.value}",
                        max_retries=1
                    )
                except:
                    pass
            
            scenarios["success_path"].append(success.public_id)
            
            # Exception recovery: CREATED -> EXCEPTION -> IN_TRANSIT -> DELIVERED
            exception_shipment = self.shipment_service.create_shipment(
                tracking_number=f"DEMO-EXCEPTION-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                carrier="BLUE_DART",
                notes="Demo: Exception recovery path",
                actor=actor
            )
            
            # Transition to exception
            try:
                self.state_service.transition_with_retry(
                    shipment_id=exception_shipment.public_id,
                    target_state=ShipmentState.EXCEPTION,
                    actor=actor,
                    reason="Demo: Simulated exception",
                    max_retries=1
                )
                
                # Recover from exception
                self.state_service.recover_from_exception(
                    shipment_id=exception_shipment.public_id,
                    target_state=ShipmentState.IN_TRANSIT,
                    actor=actor,
                    reason="Demo: Recovered from exception"
                )
            except:
                pass
            
            scenarios["exception_recovery"].append(exception_shipment.public_id)
            
            # Cancelled: CREATED -> CANCELLED
            cancelled = self.shipment_service.create_shipment(
                tracking_number=f"DEMO-CANCELLED-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                carrier="INDIA_POST",
                notes="Demo: Cancelled shipment",
                actor=actor
            )
            
            try:
                self.state_service.transition_with_retry(
                    shipment_id=cancelled.public_id,
                    target_state=ShipmentState.CANCELLED,
                    actor=actor,
                    reason="Demo: Cancelled by customer",
                    max_retries=1
                )
            except:
                pass
            
            scenarios["cancelled"].append(cancelled.public_id)
            
            self.db.commit()
            
            return {
                "scenarios": scenarios,
                "message": "Demo scenarios created successfully"
            }
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error creating demo scenarios: {str(e)}", exc_info=True)
            raise

