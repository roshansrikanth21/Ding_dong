"""
AI Agent Service for EventGuard
Handles voice and text conversations with full shipment context
"""
import os
import sys
import json
import tempfile
import subprocess
import re
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime
from sqlalchemy.orm import Session

# Add parent directory to path to import from app
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from app.models import Shipment, ShipmentState
from app.repositories.shipment_repository import ShipmentRepository


class AIAgentService:
    """
    Production-ready AI agent with EventGuard context
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.repo = ShipmentRepository(db)
        self.whisper_path: Optional[str] = self._get_whisper_path()
        
    def _get_whisper_path(self) -> Optional[str]:
        """Get path to Whisper transcription script"""
        # Try multiple possible locations
        possible_paths = [
            "C:\\Users\\rosha\\logistics-ai-agent (4)\\logistics-ai-agent\\whisper\\transcribe.py",
            os.path.join(os.path.dirname(__file__), "..", "..", "whisper", "transcribe.py"),
            os.path.join(os.path.dirname(__file__), "..", "..", "..", "whisper", "transcribe.py"),
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
        
        # Return None instead of raising - we'll handle gracefully
        return None
    
    def transcribe_audio(self, audio_path: str) -> str:
        """
        Transcribe audio file using Whisper
        """
        if not self.whisper_path:
            raise Exception("Whisper transcription service is not available. Please install Whisper or use text input instead.")
        
        try:
            # Try different Python commands
            python_commands = ["py", "-3.10", "python3.10", "python3", "python"]
            result = None
            
            for cmd in python_commands:
                try:
                    if cmd.startswith("py"):
                        # Windows py launcher
                        result = subprocess.run(
                            [cmd, "-3.10", self.whisper_path, audio_path],
                            capture_output=True,
                            text=True,
                            timeout=60
                        )
                    else:
                        result = subprocess.run(
                            [cmd, self.whisper_path, audio_path],
                            capture_output=True,
                            text=True,
                            timeout=60
                        )
                    
                    if result.returncode == 0:
                        break
                except FileNotFoundError:
                    continue
            
            if not result or result.returncode != 0:
                error_msg = result.stderr if result else "Python/Whisper not found"
                raise Exception(f"Whisper transcription failed: {error_msg}")
            
            data = json.loads(result.stdout)
            text = data.get("text", "").strip()
            
            if not text:
                raise Exception("No speech detected in audio. Please try again.")
            
            return text
        
        except json.JSONDecodeError:
            raise Exception("Invalid response from Whisper service")
        except subprocess.TimeoutExpired:
            raise Exception("Transcription timed out. Please try a shorter recording.")
        except Exception as e:
            if "Whisper transcription service is not available" in str(e):
                raise
            raise Exception(f"Transcription failed: {str(e)}. Please use text input instead.")
    
    def process_message(
        self,
        message: str,
        conversation_context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Process user message with EventGuard context
        Returns: {reply: str, data: Optional[Dict], action: Optional[str]}
        """
        # Normalize message for better voice recognition handling
        original_message = message
        message = self._normalize_text(message)
        message_lower = message.lower()
        
        # Initialize context (stateless - reset per request for stability)
        # Use provided context if available, but don't rely on it for intent parsing
        if not conversation_context:
            conversation_context = {
                "last_shipment_id": None,
                "last_tracking": None,
                "last_action": None
            }
        
        # Intent detection with EventGuard domain (always extract intent first)
        intent = self._detect_intent(message_lower)
        
        if intent == "track_shipment":
            return self._handle_track_shipment(message, conversation_context)
        
        elif intent == "list_shipments":
            return self._handle_list_shipments(message, conversation_context)
        
        elif intent == "statistics":
            return self._handle_statistics(message, conversation_context)
        
        elif intent == "shipment_status":
            return self._handle_shipment_status(message, conversation_context)
        
        elif intent == "create_shipment":
            return self._handle_create_shipment(message, conversation_context)
        
        elif intent == "help":
            return self._handle_help()
        
        else:
            # Unknown intent - provide helpful options without looping
            return {
                "reply": "I can help you with:\n• Track shipments: 'Track serial 1' or 'Track 1'\n• List shipments: 'Show all shipments'\n• Statistics: 'Get shipment statistics'\n• Status: 'What's the system status?'\n\nWhat would you like to do?",
                "data": None,
                "action": "unknown_intent"
            }
    
    def _detect_intent(self, message: str) -> str:
        """Detect user intent from message"""
        
        # Normalize common STT errors
        message = message.replace("dragon", "track")
        message = message.replace("transit", "track")
        message = message.replace("pratt", "track")
        
        # Track patterns
        if any(word in message for word in ["track", "find", "where", "locate", "search"]):
            return "track_shipment"
        
        # List patterns
        if any(phrase in message for phrase in ["list", "show all", "all shipments", "show me"]):
            return "list_shipments"
        
        # Statistics patterns (before status to avoid conflicts)
        if any(phrase in message for phrase in ["statistics", "stats", "get statistics", "shipment statistics", "show statistics"]):
            return "statistics"
        
        # Status patterns
        if any(word in message for word in ["status", "state", "what's happening", "system status"]):
            return "shipment_status"
        
        # List patterns
        if any(phrase in message for phrase in ["list all", "show all", "all shipments", "list shipments", "show shipments"]):
            return "list_shipments"
        
        # Create patterns
        if any(word in message for word in ["create", "add", "new shipment"]):
            return "create_shipment"
        
        # Help patterns
        if any(word in message for word in ["help", "what can you", "how do", "what can"]):
            return "help"
        
        return "unknown"
    
    def _normalize_text(self, text: str) -> str:
        """Normalize text for better voice recognition handling - SECURE: bounded regex"""
        if not text:
            return text
        
        # Security: Limit input length to prevent DoS
        if len(text) > 1000:
            text = text[:1000]
        
        # Security: Sanitize input - remove dangerous characters
        text = re.sub(r'[<>"\';(){}[\]\\]', '', text)
        
        # Normalize: lowercase, trim, collapse spaces
        text = text.lower().strip()
        
        # Removed ORD normalization - serial number based only
        
        # Collapse multiple spaces (bounded)
        text = re.sub(r'\s{2,}', ' ', text)  # Max 2+ spaces -> 1 space
        return text
    
    def _words_to_numbers(self, text: str) -> str:
        """Convert spoken numbers to digits: 'one two three' -> '123'"""
        word_to_digit = {
            'zero': '0', 'one': '1', 'two': '2', 'to': '2', 'too': '2',
            'three': '3', 'for': '4', 'four': '4', 'five': '5',
            'six': '6', 'seven': '7', 'eight': '8', 'nine': '9',
            'ten': '10', 'eleven': '11', 'twelve': '12', 'thirteen': '13',
            'fourteen': '14', 'fifteen': '15', 'sixteen': '16',
            'seventeen': '17', 'eighteen': '18', 'nineteen': '19',
            'twenty': '20', 'thirty': '30', 'forty': '40', 'fifty': '50',
            'sixty': '60', 'seventy': '70', 'eighty': '80', 'ninety': '90'
        }
        
        # Pattern to match sequences of number words
        pattern = r'\b(' + '|'.join(word_to_digit.keys()) + r')(?:\s+(' + '|'.join(word_to_digit.keys()) + r'))+\b'
        
        def replace_numbers(match):
            words = match.group(0).split()
            result = ''
            for word in words:
                if word in word_to_digit:
                    result += word_to_digit[word]
            return result if result else match.group(0)
        
        return re.sub(pattern, replace_numbers, text)
    
    def _fuzzy_match_tracking_number(self, candidate: str) -> Optional[str]:
        """
        Try to find a matching tracking number in database using fuzzy matching.
        Returns the actual tracking number if found, None otherwise.
        Security: Bounded matching with max edit distance limits, no unbounded queries.
        """
        if not candidate:
            return None
        
        # Security: Validate and sanitize candidate
        candidate = candidate.strip()
        if len(candidate) < 3 or len(candidate) > 50:  # Bounded length
            return None
        
        # Security: Only allow alphanumeric and common separators
        if not re.match(r'^[A-Z0-9\s\-_\.]+$', candidate.upper()):
            return None
        
        candidate_upper = candidate.upper().replace(' ', '')
        
        # First try exact match via repository (most efficient, secure)
        exact_match = self.repo.get_by_tracking_number(candidate_upper, include_deleted=False)
        if exact_match:
            return exact_match.tracking_number
        
        # Fuzzy match: only query if candidate looks valid (bounded search)
        # Limit to recent shipments to avoid full table scan (SECURITY: bounded query)
        shipments, total = self.repo.list(page=1, limit=50, include_deleted=False, sort_by="updated_at")
        
        if total == 0:
            return None
        
        # Exact match (case-insensitive, space-insensitive)
        for shipment in shipments:
            existing = shipment.tracking_number.replace(' ', '').upper()
            if existing == candidate_upper:
                return shipment.tracking_number
        
        # Fuzzy match: only for similar length (max 3 char difference - SECURITY: bounded)
        for shipment in shipments:
            existing = shipment.tracking_number.replace(' ', '').upper()
            length_diff = abs(len(existing) - len(candidate_upper))
            
            # Security: Strict bounds on fuzzy matching
            if length_diff <= 3 and len(existing) <= 50 and len(candidate_upper) <= 50:
                # Character-by-character similarity (max 2 differences)
                if len(existing) == len(candidate_upper):
                    differences = sum(1 for a, b in zip(existing, candidate_upper) if a != b)
                    if differences <= 2:  # Max 2 character differences
                        return shipment.tracking_number
                
                # Prefix/suffix matching (bounded substring)
                prefix_len = min(6, len(candidate_upper), len(existing))
                if prefix_len > 0:
                    if (existing.startswith(candidate_upper[:prefix_len]) or
                        candidate_upper.startswith(existing[:prefix_len])):
                        if length_diff <= 2:
                            return shipment.tracking_number
        
        return None
    
    def _extract_identifier(self, message: str) -> tuple[Optional[int]]:
        """
        Extract serial number from message - SERIAL NUMBER BASED ONLY.
        Returns (serial_number,)
        """
        # Normalize message first
        normalized = self._normalize_text(message)
        
        # Convert spoken numbers to digits
        normalized = self._words_to_numbers(normalized)
        
        # Extract serial number patterns
        # Patterns: "serial 1", "serial number 1", "track serial 1", "order serial 1", "track 1", "order 1"
        serial_patterns = [
            r'\bserial\s+(?:number\s+)?(\d+)\b',
            r'\border\s+serial\s+(\d+)\b',
            r'\btrack\s+serial\s+(\d+)\b',
            r'\b(?:track|order)\s+(\d+)\b',  # "track 1" or "order 1"
        ]
        
        for pattern in serial_patterns:
            match = re.search(pattern, normalized)
            if match:
                try:
                    serial_num = int(match.group(1))
                    return serial_num
                except ValueError:
                    continue
        
        return None
    
    def _handle_track_shipment(
        self,
        message: str,
        conversation_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Handle shipment tracking request - SERIAL NUMBER BASED ONLY"""
        
        serial_number = self._extract_identifier(message)
        shipment = None
        
        if not serial_number:
            # Show dropdown with active shipments if no serial number provided
            try:
                from app.models import ShipmentState
                active_shipments, _ = self.repo.list(
                    page=1,
                    limit=10,
                    status=ShipmentState.IN_TRANSIT,
                    sort_by="updated_at",
                    sort_order="desc",
                    include_deleted=False
                )
                
                if not active_shipments:
                    # Fallback to all shipments if no in-transit
                    active_shipments, _ = self.repo.list(
                        page=1,
                        limit=10,
                        sort_by="updated_at",
                        sort_order="desc",
                        include_deleted=False
                    )
                
                if active_shipments:
                    shipment_list = []
                    for s in active_shipments:
                        shipment_list.append({
                            "tracking_number": s.tracking_number,
                            "serial_number": s.serial_number,
                            "state": s.current_state.value
                        })
                    
                    return {
                        "reply": "Please select a shipment to track:",
                        "data": {"shipments": shipment_list},
                        "action": "show_dropdown"
                    }
                else:
                    return {
                        "reply": "No shipments found. Please provide a serial number. For example: 'Track serial 1' or 'Track 1'",
                        "data": None,
                        "action": "request_tracking"
                    }
            except Exception as e:
                logger = logging.getLogger(__name__)
                logger.error(f"Error showing dropdown: {str(e)}", exc_info=True)
                return {
                    "reply": "Please provide a serial number. For example: 'Track serial 1' or 'Track 1'",
                    "data": None,
                    "action": "request_tracking"
                }
        
        try:
            # Find by serial number
            shipment = self.repo.get_by_serial_number(serial_number, include_deleted=False)
            
            if not shipment:
                return {
                    "reply": f"❌ Shipment with serial number {serial_number} not found. Please check the serial number.",
                    "data": {"serial_number": serial_number},
                    "action": "not_found"
                }
            
            # Save to context
            conversation_context["last_shipment_id"] = shipment.public_id
            conversation_context["last_tracking"] = shipment.tracking_number
            conversation_context["last_action"] = "track"
            
            # Build response
            reply = f"📦 **Shipment Serial #{shipment.serial_number}**"
            reply += f"\nTracking: {shipment.tracking_number}"
            reply += f"\nStatus: **{shipment.current_state.value}**\n"
            reply += f"Carrier: {shipment.carrier or 'Unknown'}\n"
            
            if shipment.notes:
                reply += f"Notes: {shipment.notes}\n"
            
            reply += f"\nLast updated: {shipment.updated_at.strftime('%Y-%m-%d %H:%M')}"
            
            return {
                "reply": reply,
                "data": {
                    "shipment_id": shipment.public_id,
                    "tracking_number": shipment.tracking_number,
                    "serial_number": shipment.serial_number,
                    "state": shipment.current_state.value,
                    "carrier": shipment.carrier
                },
                "action": "show_shipment"
            }
        
        except Exception as e:
            logger = logging.getLogger(__name__)
            logger.error(f"Error tracking shipment: {str(e)}", exc_info=True)
            # Security: Don't expose internal errors to user
            return {
                "reply": "Error retrieving shipment information. Please try again.",
                "data": None,
                "action": "error"
            }
    
    def _handle_list_shipments(
        self,
        message: str,
        conversation_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Handle list shipments request - stateless, reliable"""
        
        try:
            # Get recent shipments
            shipments, total = self.repo.list(
                page=1,
                limit=20,
                sort_by="updated_at",
                sort_order="desc",
                include_deleted=False
            )
            
            if not shipments:
                return {
                    "reply": "No shipments found in the system.",
                    "data": {"shipments": [], "total": 0},
                    "action": "empty_list"
                }
            
            # Build response
            reply = f"📋 **Recent Shipments** (showing {len(shipments)} of {total}):\n\n"
            
            shipment_list = []
            for s in shipments:
                # Show serial number prominently
                if s.serial_number:
                    reply += f"• **Serial #{s.serial_number}** - {s.tracking_number} - {s.current_state.value}\n"
                else:
                    reply += f"• **{s.tracking_number}** - {s.current_state.value}\n"
                reply += f"  Carrier: {s.carrier or 'Unknown'}, Updated: {s.updated_at.strftime('%Y-%m-%d %H:%M')}\n\n"
                
                shipment_list.append({
                    "id": s.public_id,
                    "tracking_number": s.tracking_number,
                    "serial_number": s.serial_number,
                    "state": s.current_state.value,
                    "carrier": s.carrier or "Unknown",
                    "updated_at": s.updated_at.isoformat()
                })
            
            reply += "Say 'Track serial 1' or 'Track 1' to see details of a specific shipment."
            
            return {
                "reply": reply,
                "data": {"shipments": shipment_list, "total": total},
                "action": "show_list"
            }
        
        except Exception as e:
            logger = logging.getLogger(__name__)
            logger.error(f"Error listing shipments: {str(e)}", exc_info=True)
            return {
                "reply": "Error retrieving shipments. Please try again.",
                "data": None,
                "action": "error"
            }
    
    def _handle_statistics(
        self,
        message: str,
        conversation_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Handle statistics request - stateless, reliable"""
        
        try:
            from sqlalchemy import func
            from app.models import ShipmentState
            
            # Get statistics safely
            total = self.db.query(Shipment).filter(
                Shipment.deleted_at.is_(None)
            ).count()
            
            state_counts = self.db.query(
                Shipment.current_state,
                func.count(Shipment.id).label('count')
            ).filter(
                Shipment.deleted_at.is_(None)
            ).group_by(Shipment.current_state).all()
            
            reply = f"📊 **Shipment Statistics**\n\n"
            reply += f"Total Active Shipments: **{total}**\n\n"
            reply += "Breakdown by State:\n"
            
            for state, count in state_counts:
                reply += f"• {state.value}: {count}\n"
            
            return {
                "reply": reply,
                "data": {
                    "total": total,
                    "states": {state.value: count for state, count in state_counts}
                },
                "action": "show_stats"
            }
        
        except Exception as e:
            logger = logging.getLogger(__name__)
            logger.error(f"Error getting statistics: {str(e)}", exc_info=True)
            return {
                "reply": "Error retrieving statistics. Please try again.",
                "data": None,
                "action": "error"
            }
    
    def _handle_shipment_status(
        self,
        message: str,
        conversation_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Handle shipment status query - stateless, reliable"""
        
        try:
            from sqlalchemy import func
            from app.models import ShipmentState
            
            # Get status safely
            total = self.db.query(Shipment).filter(
                Shipment.deleted_at.is_(None)
            ).count()
            
            state_counts = self.db.query(
                Shipment.current_state,
                func.count(Shipment.id).label('count')
            ).filter(
                Shipment.deleted_at.is_(None)
            ).group_by(Shipment.current_state).all()
            
            reply = f"📊 **System Status**\n\n"
            reply += f"Total Active Shipments: **{total}**\n\n"
            reply += "Breakdown by State:\n"
            
            for state, count in state_counts:
                reply += f"• {state.value}: {count}\n"
            
            return {
                "reply": reply,
                "data": {
                    "total": total,
                    "states": {state.value: count for state, count in state_counts}
                },
                "action": "show_stats"
            }
        
        except Exception as e:
            logger = logging.getLogger(__name__)
            logger.error(f"Error getting status: {str(e)}", exc_info=True)
            return {
                "reply": "Error retrieving status. Please try again.",
                "data": None,
                "action": "error"
            }
    
    def _handle_create_shipment(
        self,
        message: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Handle create shipment request"""
        
        return {
            "reply": "To create a shipment, I need a tracking number. Use the 'Create Shipment' button on the Shipments page, or tell me: 'Create shipment with tracking number [YOUR_NUMBER]'",
            "data": None,
            "action": "request_create"
        }
    
    def _handle_help(self) -> Dict[str, Any]:
        """Handle help request"""
        
        reply = """🤖 **EventGuard AI Assistant**

I can help you with:

**Tracking:**
• "Track [tracking number]"
• "Find shipment 1Z999..."
• "Where is my package?"

**Listing:**
• "Show all shipments"
• "List recent shipments"

**Status:**
• "What's the system status?"
• "How many shipments are active?"

**Voice Commands:**
Click the microphone button to speak your commands naturally!

What would you like to do?"""
        
        return {
            "reply": reply,
            "data": None,
            "action": "help"
        }
