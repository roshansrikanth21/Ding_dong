from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from app.models import Base
import os

# Use PostgreSQL if DATABASE_URL is set, otherwise SQLite for development
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./stateguard.db")

if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    # Production PostgreSQL with connection pooling
    # PART 2.3: Add DB query timeout via connect_args (5 seconds = 5000ms)
    DB_QUERY_TIMEOUT_MS = 5000  # 5 seconds in milliseconds
    engine = create_engine(
        DATABASE_URL,
        pool_size=20,
        max_overflow=10,
        pool_pre_ping=True,  # Verify connections before using
        pool_recycle=3600,   # Recycle connections after 1 hour
        connect_args={
            "options": f"-c statement_timeout={DB_QUERY_TIMEOUT_MS}"  # PostgreSQL timeout in milliseconds
        }
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Initialize database tables and run migrations"""
    from sqlalchemy import text
    
    # Create all tables
    Base.metadata.create_all(bind=engine)
    
    # Run migrations for existing PostgreSQL databases
    if not DATABASE_URL.startswith("sqlite"):
        db = SessionLocal()
        try:
            # Try to add columns - PostgreSQL will error if they exist, which we catch
            columns_to_add = [
                ("carrier", "VARCHAR"),
                ("notes", "VARCHAR"),
                ("deleted_at", "TIMESTAMP"),
                ("public_id", "VARCHAR"),
                ("version", "INTEGER"),
                ("state_version", "VARCHAR"),
                ("exception_reason", "VARCHAR"),
                ("exception_type", "VARCHAR"),  # Exception classification
                ("exception_at", "TIMESTAMP"),
                ("state_entered_at", "TIMESTAMP"),  # SLA tracking
                ("origin", "VARCHAR"),  # Inventory: origin location
                ("destination", "VARCHAR"),  # Inventory: destination location
                ("product_type", "VARCHAR"),  # Inventory: product type
                ("is_fragile", "VARCHAR"),  # Inventory: FRAGILE or NON_FRAGILE
                ("storage_locations", "TEXT"),  # Inventory: JSON array of waypoints
                ("scheduled_date", "TIMESTAMP"),  # Inventory: scheduled date
                ("estimated_delivery", "TIMESTAMP"),  # Inventory: estimated delivery
            ]
            
            for column_name, column_type in columns_to_add:
                try:
                    db.execute(text(f"ALTER TABLE shipments ADD COLUMN {column_name} {column_type}"))
                    db.commit()
                    print(f"✓ Migrated: Added {column_name} column")
                except Exception as e:
                    db.rollback()
                    # If column already exists, that's fine - ignore the error
                    error_str = str(e).lower()
                    if "already exists" in error_str or "duplicate" in error_str:
                        pass  # Column exists, that's fine
                    else:
                        print(f"⚠ Migration warning for {column_name}: {e}")
            
            # Populate public_id for existing records if it was just added
            try:
                result = db.execute(text("SELECT COUNT(*) FROM shipments WHERE public_id IS NULL"))
                null_count = result.scalar()
                if null_count > 0:
                    # Use PostgreSQL's gen_random_uuid() function to generate UUIDs
                    db.execute(text("UPDATE shipments SET public_id = gen_random_uuid()::text WHERE public_id IS NULL"))
                    db.commit()
                    print(f"✓ Migrated: Generated public_id for {null_count} existing shipments")
            except Exception as e:
                db.rollback()
                # If gen_random_uuid() doesn't exist (older PostgreSQL), use uuid_generate_v4() from extension
                try:
                    db.execute(text("CREATE EXTENSION IF NOT EXISTS pgcrypto"))
                    db.execute(text("UPDATE shipments SET public_id = gen_random_uuid()::text WHERE public_id IS NULL"))
                    db.commit()
                    print(f"✓ Migrated: Generated public_id for existing shipments (using pgcrypto)")
                except Exception as e2:
                    # Fallback: use Python's uuid
                    import uuid
                    result = db.execute(text("SELECT id FROM shipments WHERE public_id IS NULL"))
                    ids = [row[0] for row in result]
                    for shipment_id in ids:
                        db.execute(text("UPDATE shipments SET public_id = :uuid WHERE id = :id"), 
                                 {"uuid": str(uuid.uuid4()), "id": shipment_id})
                    db.commit()
                    print(f"✓ Migrated: Generated public_id for {len(ids)} existing shipments (using Python uuid)")
            
            # Drop old unique constraint on tracking_number if it exists
            try:
                db.execute(text("ALTER TABLE shipments DROP CONSTRAINT IF EXISTS shipments_tracking_number_key"))
                db.commit()
            except Exception:
                pass
            
            # Create partial unique index for tracking_number (only when not deleted)
            try:
                db.execute(text("""
                    CREATE UNIQUE INDEX IF NOT EXISTS ix_shipments_tracking_number_unique 
                    ON shipments(tracking_number) 
                    WHERE deleted_at IS NULL
                """))
                db.commit()
                print("✓ Migrated: Created partial unique index on tracking_number")
            except Exception as e:
                db.rollback()
                # If index already exists, that's fine
                if "already exists" not in str(e).lower():
                    print(f"⚠ Migration warning for tracking_number index: {e}")
            
            # Add EXCEPTION to enum if it doesn't exist (PostgreSQL enum migration)
            try:
                # Check if EXCEPTION value exists in the enum
                result = db.execute(text("""
                    SELECT EXISTS (
                        SELECT 1 FROM pg_enum 
                        WHERE enumlabel = 'EXCEPTION' 
                        AND enumtypid = (
                            SELECT oid FROM pg_type WHERE typname = 'shipmentstate'
                        )
                    )
                """))
                enum_exists = result.scalar()
                
                if not enum_exists:
                    # Add EXCEPTION to the enum type
                    db.execute(text("ALTER TYPE shipmentstate ADD VALUE IF NOT EXISTS 'EXCEPTION'"))
                    db.commit()
                    print("✓ Migrated: Added EXCEPTION to shipmentstate enum")
            except Exception as e:
                db.rollback()
                # If enum doesn't exist yet, it will be created by SQLAlchemy
                error_str = str(e).lower()
                if "does not exist" not in error_str:
                    print(f"⚠ Migration warning for enum: {e}")
            
            # Add serial_number column if it doesn't exist
            try:
                db.execute(text("""
                    ALTER TABLE shipments 
                    ADD COLUMN IF NOT EXISTS serial_number INTEGER
                """))
                db.commit()
                print("✓ Migrated: Added serial_number column")
            except Exception as e:
                db.rollback()
                if "already exists" not in str(e).lower():
                    print(f"⚠ Migration warning for serial_number column: {e}")
            
            # Create sequence for serial numbers if it doesn't exist
            try:
                db.execute(text("""
                    CREATE SEQUENCE IF NOT EXISTS shipments_serial_number_seq
                    START WITH 1
                    INCREMENT BY 1
                """))
                db.commit()
                print("✓ Migrated: Created serial_number sequence")
            except Exception as e:
                db.rollback()
                if "already exists" not in str(e).lower():
                    print(f"⚠ Migration warning for serial_number sequence: {e}")
            
            # Assign serial numbers to existing shipments that don't have one
            try:
                db.execute(text("""
                    UPDATE shipments 
                    SET serial_number = nextval('shipments_serial_number_seq')
                    WHERE serial_number IS NULL
                """))
                db.commit()
                print("✓ Migrated: Assigned serial numbers to existing shipments")
            except Exception as e:
                db.rollback()
                print(f"⚠ Migration warning for serial number assignment: {e}")
            
            # Create unique index on serial_number
            try:
                db.execute(text("""
                    CREATE UNIQUE INDEX IF NOT EXISTS ix_shipments_serial_number_unique 
                    ON shipments(serial_number) 
                    WHERE deleted_at IS NULL AND serial_number IS NOT NULL
                """))
                db.commit()
                print("✓ Migrated: Created unique index on serial_number")
            except Exception as e:
                db.rollback()
                if "already exists" not in str(e).lower():
                    print(f"⚠ Migration warning for serial_number index: {e}")
            
            # Set defaults for new columns on existing records
            try:
                db.execute(text("UPDATE shipments SET version = 1 WHERE version IS NULL"))
                db.execute(text("UPDATE shipments SET state_version = '1.0' WHERE state_version IS NULL"))
                db.commit()
            except Exception:
                pass
            
            # Add new columns to state_transitions table
            transition_columns_to_add = [
                ("actor", "VARCHAR"),
                ("reason", "VARCHAR"),
                ("transition_metadata", "VARCHAR"),  # Renamed from 'metadata' - reserved in SQLAlchemy
                ("transition_version", "VARCHAR"),
                ("transition_idempotency_key", "VARCHAR"),
                ("command_id", "VARCHAR"),  # TASK 2: Command ID for idempotency (unique per shipment)
                ("sequence_number", "INTEGER"),  # Global event ordering
            ]
            
            for column_name, column_type in transition_columns_to_add:
                try:
                    db.execute(text(f"ALTER TABLE state_transitions ADD COLUMN {column_name} {column_type}"))
                    db.commit()
                    print(f"✓ Migrated: Added {column_name} column to state_transitions")
                except Exception as e:
                    db.rollback()
                    error_str = str(e).lower()
                    if "already exists" in error_str or "duplicate" in error_str:
                        pass
                    else:
                        print(f"⚠ Migration warning for state_transitions.{column_name}: {e}")
            
            # Set defaults for transition columns
            try:
                db.execute(text("UPDATE state_transitions SET actor = 'system' WHERE actor IS NULL"))
                db.execute(text("UPDATE state_transitions SET transition_version = '1.0' WHERE transition_version IS NULL"))
                db.commit()
            except Exception:
                pass
            
            # Create event sequence for global ordering (if not exists)
            try:
                result = db.execute(text(
                    "SELECT EXISTS(SELECT 1 FROM pg_sequences WHERE sequencename = 'event_sequence')"
                ))
                if not result.scalar():
                    db.execute(text("CREATE SEQUENCE event_sequence START 1 INCREMENT 1"))
                    db.commit()
                    print("✓ Migrated: Created event_sequence for global event ordering")
            except Exception as e:
                db.rollback()
                if "already exists" not in str(e).lower():
                    print(f"⚠ Migration warning for event_sequence: {e}")
            
            # TASK 2: Create composite unique index for command_id (unique per shipment)
            try:
                # Drop index if it exists (to recreate with correct constraint)
                db.execute(text("DROP INDEX IF EXISTS ix_state_transitions_shipment_command_id"))
                db.execute(text("""
                    CREATE UNIQUE INDEX IF NOT EXISTS ix_state_transitions_shipment_command_id
                    ON state_transitions(shipment_id, command_id)
                    WHERE command_id IS NOT NULL
                """))
                db.commit()
                print("✓ Migrated: Created composite unique index for command_id (unique per shipment)")
            except Exception as e:
                db.rollback()
                if "already exists" not in str(e).lower():
                    print(f"⚠ Migration warning for command_id unique index: {e}")
            
            # Create waypoint_visits table for tracking warehouse visits
            try:
                db.execute(text("""
                    CREATE TABLE IF NOT EXISTS waypoint_visits (
                        id SERIAL PRIMARY KEY,
                        shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
                        waypoint_name VARCHAR NOT NULL,
                        arrived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        departed_at TIMESTAMP,
                        notes TEXT,
                        actor VARCHAR,
                        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )
                """))
                db.commit()
                print("✓ Migrated: Created waypoint_visits table")
            except Exception as e:
                db.rollback()
                if "already exists" not in str(e).lower():
                    print(f"⚠ Migration warning for waypoint_visits table: {e}")
            
            # Create indexes for waypoint_visits
            try:
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_waypoint_visits_shipment_id ON waypoint_visits(shipment_id)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_waypoint_visits_waypoint_name ON waypoint_visits(waypoint_name)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_waypoint_visits_arrived_at ON waypoint_visits(arrived_at)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_waypoint_visits_departed_at ON waypoint_visits(departed_at)"))
                db.commit()
            except Exception:
                pass
            
            # Update String columns to Text for security (prevent DoS)
            try:
                db.execute(text("ALTER TABLE shipments ALTER COLUMN notes TYPE TEXT"))
                db.execute(text("ALTER TABLE shipments ALTER COLUMN storage_locations TYPE TEXT"))
                db.execute(text("ALTER TABLE state_transitions ALTER COLUMN transition_metadata TYPE TEXT"))
                db.commit()
                print("✓ Migrated: Updated String columns to Text for security")
            except Exception as e:
                db.rollback()
                if "does not exist" not in str(e).lower() and "already" not in str(e).lower():
                    print(f"⚠ Migration warning for Text conversion: {e}")
            
            # Create indexes if they don't exist
            try:
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_carrier ON shipments(carrier)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_deleted_at ON shipments(deleted_at)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_public_id ON shipments(public_id)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_version ON shipments(version)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_state_version ON shipments(state_version)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_state_entered_at ON shipments(state_entered_at)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_state_transitions_shipment_id ON state_transitions(shipment_id)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_state_transitions_from_state ON state_transitions(from_state)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_state_transitions_to_state ON state_transitions(to_state)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_state_transitions_timestamp ON state_transitions(timestamp)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_state_transitions_idempotency_key ON state_transitions(transition_idempotency_key)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_state_transitions_command_id ON state_transitions(command_id)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_state_transitions_sequence_number ON state_transitions(sequence_number)"))
                db.commit()
            except Exception:
                pass  # Indexes might already exist
        except Exception as e:
            db.rollback()
            print(f"⚠ Migration error: {e}")
        finally:
            db.close()


def get_db():
    """Dependency for getting database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

