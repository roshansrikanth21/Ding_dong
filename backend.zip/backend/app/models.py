from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum as SQLEnum, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
import uuid

Base = declarative_base()


class ShipmentState(str, enum.Enum):
    """Enum for shipment states - prevents typos and ambiguity"""
    CREATED = "CREATED"
    READY_FOR_PICKUP = "READY_FOR_PICKUP"
    IN_TRANSIT = "IN_TRANSIT"
    DELIVERED = "DELIVERED"
    CANCELLED = "CANCELLED"
    EXCEPTION = "EXCEPTION"  # Recoverable error state for production robustness


class Shipment(Base):
    __tablename__ = "shipments"
    
    # Note: Partial unique index for tracking_number is created via migration in database.py
    # We cannot define it here directly because SQLAlchemy's Index with postgresql_where 
    # requires special handling in migrations

    id = Column(Integer, primary_key=True, index=True)
    public_id = Column(String, unique=True, index=True, nullable=False, default=lambda: str(uuid.uuid4()))
    tracking_number = Column(String, index=True, nullable=False)  # unique constraint enforced via partial index
    serial_number = Column(Integer, unique=True, index=True, nullable=True)  # Auto-incremented serial number
    carrier = Column(String, nullable=True, index=True)  # Detected carrier
    current_state = Column(SQLEnum(ShipmentState), nullable=False, default=ShipmentState.CREATED, index=True)
    notes = Column(Text, nullable=True)  # Additional notes/comments (changed to Text for security)
    deleted_at = Column(DateTime, nullable=True, index=True)  # Soft delete timestamp
    
    # Inventory-based fields
    origin = Column(String, nullable=True, index=True)  # Where shipment comes from
    destination = Column(String, nullable=True, index=True)  # Where shipment is going
    product_type = Column(String, nullable=True, index=True)  # Product category/type
    is_fragile = Column(String, nullable=True, default='NON_FRAGILE')  # FRAGILE or NON_FRAGILE
    storage_locations = Column(Text, nullable=True)  # JSON array of storage locations/waypoints (changed to Text)
    scheduled_date = Column(DateTime, nullable=True, index=True)  # Scheduled delivery/pickup date
    estimated_delivery = Column(DateTime, nullable=True)  # Estimated delivery date
    
    # Production-grade features for reliability
    version = Column(Integer, nullable=False, default=1, index=True)  # Optimistic locking version
    state_version = Column(String, nullable=False, default='1.0')  # State machine version this shipment uses
    exception_reason = Column(String, nullable=True)  # Reason if in EXCEPTION state
    exception_type = Column(String, nullable=True)  # Exception classification: TEMPORARY, EXTERNAL, DATA, MANUAL
    exception_at = Column(DateTime, nullable=True)  # When exception occurred
    state_entered_at = Column(DateTime, nullable=True)  # When current state was entered (for SLA tracking)
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False, index=True)
    
    # Relationships
    transitions = relationship("StateTransition", back_populates="shipment", order_by="StateTransition.timestamp")
    waypoint_visits = relationship("WaypointVisit", back_populates="shipment", order_by="WaypointVisit.arrived_at", cascade="all, delete-orphan")
    
    @property
    def is_deleted(self):
        """Check if shipment is soft deleted"""
        return self.deleted_at is not None


class WaypointVisit(Base):
    """Track when shipments arrive at each warehouse/waypoint"""
    __tablename__ = "waypoint_visits"
    
    id = Column(Integer, primary_key=True, index=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id", ondelete="CASCADE"), nullable=False, index=True)
    waypoint_name = Column(String, nullable=False, index=True)  # Warehouse/waypoint name
    arrived_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)  # When shipment arrived
    departed_at = Column(DateTime, nullable=True, index=True)  # When shipment left (null if still there)
    notes = Column(Text, nullable=True)  # Optional notes about this visit
    actor = Column(String, nullable=True)  # Who recorded this visit
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Relationship back to shipment
    shipment = relationship("Shipment", back_populates="waypoint_visits")


class StateTransition(Base):
    __tablename__ = "state_transitions"

    id = Column(Integer, primary_key=True, index=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"), nullable=False, index=True)
    from_state = Column(SQLEnum(ShipmentState), nullable=True, index=True)  # None for initial state
    to_state = Column(SQLEnum(ShipmentState), nullable=False, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    
    # Production-grade audit fields
    actor = Column(String, nullable=True)  # Who/what initiated the transition (user_id, system, etc.)
    reason = Column(String, nullable=True)  # Business reason for transition
    transition_metadata = Column(Text, nullable=True)  # JSON metadata for additional context (changed to Text)
    transition_version = Column(String, nullable=False, default='1.0')  # State machine version used
    
    # Idempotency and conflict detection
    transition_idempotency_key = Column(String, nullable=True, unique=True, index=True)  # Prevent duplicate transitions
    command_id = Column(String, nullable=True, index=True)  # TASK 2: Command ID for idempotency (unique per shipment)
    
    # Global event ordering (observability only - NOT for correctness decisions)
    sequence_number = Column(Integer, nullable=True, index=True)  # Monotonically increasing event sequence for audit/replay
    
    # Note: Composite unique index (shipment_id, command_id) is created via migration in database.py
    
    # Relationship back to shipment
    shipment = relationship("Shipment", back_populates="transitions")
