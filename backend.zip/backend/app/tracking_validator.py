"""
Professional tracking number validation for major logistics carriers.
Supports industry-standard formats for production use.
"""
import re
from typing import Optional, Tuple


# Carrier-specific tracking number patterns
TRACKING_PATTERNS = {
    'INDIA_POST': {
        'pattern': r'^[A-Z]{2}\d{9}IN$',
        'description': 'India Post (13 chars: 2 letters + 9 digits + IN)',
        'example': 'EE123456789IN'
    },
    'BLUE_DART': {
        'pattern': r'^\d{8,11}$',
        'description': 'Blue Dart (8-11 digits)',
        'example': '12345678901'
    },
    'DHL_EXPRESS': {
        'pattern': r'^\d{10}$',
        'description': 'DHL Express (10 digits)',
        'example': '1234567890'
    },
    'DHL_ECOMMERCE': {
        'pattern': r'^[A-Z0-9]{16,39}$',
        'description': 'DHL eCommerce (16-39 alphanumeric)',
        'example': 'GM123456789012345'
    },
    'DELHIVERY': {
        'pattern': r'^\d{12}$',
        'description': 'Delhivery (12 digits)',
        'example': '123456789012'
    },
    'UPS': {
        'pattern': r'^1Z[A-Z0-9]{16}$',
        'description': 'UPS (18 chars: 1Z + 16 alphanumeric)',
        'example': '1Z999AA10123456784'
    },
    'FEDEX': {
        'pattern': r'^\d{12,14}$',
        'description': 'FedEx (12-14 digits)',
        'example': '12345678901234'
    },
    'USPS': {
        'pattern': r'^\d{20,22}$',
        'description': 'USPS (20-22 digits)',
        'example': '12345678901234567890'
    },
    'CONTAINER': {
        'pattern': r'^[A-Z]{4}\d{7}$',
        'description': 'Shipping Container (4 letters + 7 digits)',
        'example': 'ABCD1234567'
    },
    'GENERIC': {
        'pattern': r'^[A-Z0-9]{6,50}$',
        'description': 'Generic alphanumeric (6-50 chars)',
        'example': 'TRACK123456'
    }
}


def detect_carrier(tracking_number: str) -> Optional[str]:
    """
    Detect the carrier based on tracking number format.
    Returns carrier name or None if format doesn't match any known pattern.
    """
    tracking_number = tracking_number.strip().upper()
    
    # Check each carrier pattern
    for carrier, config in TRACKING_PATTERNS.items():
        if re.match(config['pattern'], tracking_number):
            return carrier
    
    return None


def validate_tracking_number(tracking_number: str, strict: bool = False) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Validate tracking number format.
    
    Args:
        tracking_number: The tracking number to validate
        strict: If True, only accept known carrier formats. If False, accept generic format too.
    
    Returns:
        Tuple of (is_valid, error_message, detected_carrier)
    """
    if not tracking_number:
        return False, 'Tracking number cannot be empty', None
    
    tracking_number = tracking_number.strip().upper()
    
    # Basic length check
    if len(tracking_number) < 6:
        return False, 'Tracking number must be at least 6 characters', None
    
    if len(tracking_number) > 50:
        return False, 'Tracking number cannot exceed 50 characters', None
    
    # Check for dangerous characters (XSS prevention)
    if re.search(r'[<>"\';(){}[\]\\]', tracking_number):
        return False, 'Tracking number contains invalid characters', None
    
    # Detect carrier
    carrier = detect_carrier(tracking_number)
    
    if strict and not carrier:
        return False, 'Tracking number does not match any known carrier format', None
    
    if not carrier:
        # Fallback to generic validation
        if not re.match(TRACKING_PATTERNS['GENERIC']['pattern'], tracking_number):
            return False, 'Tracking number format is invalid', None
        carrier = 'GENERIC'
    
    return True, None, carrier


def get_tracking_info(tracking_number: str) -> dict:
    """
    Get information about a tracking number format.
    """
    is_valid, error, carrier = validate_tracking_number(tracking_number, strict=False)
    
    if not is_valid:
        return {
            'valid': False,
            'error': error,
            'carrier': None,
            'format': None
        }
    
    carrier_info = TRACKING_PATTERNS.get(carrier, {})
    
    return {
        'valid': True,
        'error': None,
        'carrier': carrier,
        'format': carrier_info.get('description', 'Unknown format'),
        'example': carrier_info.get('example', '')
    }

