"""
Shipment Validator - Early validation layer before database operations.
Validates inputs, transitions, and business rules before any side effects.
"""
from typing import Tuple, Optional
from app.models import ShipmentState
from app.state_machine import get_state_machine
from app.tracking_validator import validate_tracking_number


class ValidationError(Exception):
    """Custom exception for validation errors"""
    def __init__(self, message: str, field: str = None, code: str = None):
        self.message = message
        self.field = field
        self.code = code
        super().__init__(self.message)


class ShipmentValidator:
    """Validates shipment-related operations before database interaction"""
    
    @staticmethod
    def validate_tracking_number(tracking_number: str, strict: bool = False) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Validate tracking number format.
        Returns: (is_valid, error_message, detected_carrier)
        """
        if not tracking_number or not tracking_number.strip():
            return False, "Tracking number cannot be empty", None
        
        if len(tracking_number) < 6 or len(tracking_number) > 50:
            return False, "Tracking number must be between 6 and 50 characters", None
        
        # Use tracking validator
        is_valid, error, carrier = validate_tracking_number(tracking_number, strict=strict)
        return is_valid, error, carrier
    
    @staticmethod
    def validate_state_transition(
        from_state: ShipmentState,
        to_state: ShipmentState,
        version: Optional[str] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate state transition before database operations.
        Returns: (is_valid, error_message)
        """
        state_machine = get_state_machine()
        return state_machine.is_valid_transition(from_state, to_state, version)
    
    @staticmethod
    def validate_notes(notes: Optional[str]) -> Tuple[bool, Optional[str]]:
        """
        Validate notes field.
        Returns: (is_valid, error_message)
        """
        if notes is None:
            return True, None
        
        if len(notes) > 500:
            return False, "Notes must be 500 characters or less"
        
        # Check for potential XSS attempts
        dangerous_patterns = ['<script', 'javascript:', 'onerror=', 'onload=']
        notes_lower = notes.lower()
        for pattern in dangerous_patterns:
            if pattern in notes_lower:
                return False, f"Notes contain potentially unsafe content: {pattern}"
        
        return True, None
    
    @staticmethod
    def validate_shipment_creation(tracking_number: str, carrier: Optional[str] = None) -> Tuple[bool, Optional[str]]:
        """
        Validate shipment creation data.
        Returns: (is_valid, error_message)
        """
        is_valid, error, _ = ShipmentValidator.validate_tracking_number(tracking_number)
        if not is_valid:
            return False, error
        
        return True, None
    
    @staticmethod
    def validate_shipment_update(notes: Optional[str]) -> Tuple[bool, Optional[str]]:
        """
        Validate shipment update data.
        Returns: (is_valid, error_message)
        """
        return ShipmentValidator.validate_notes(notes)
    
    @staticmethod
    def validate_delete_operation(
        current_state: ShipmentState,
        permanent: bool = False
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate if shipment can be deleted.
        Returns: (is_valid, error_message)
        """
        # Only allow deletion of CREATED or CANCELLED shipments
        allowed_states = {ShipmentState.CREATED, ShipmentState.CANCELLED}
        
        if current_state not in allowed_states:
            return False, (
                f"Cannot delete shipment in {current_state.value} state. "
                f"Only CREATED or CANCELLED shipments can be deleted."
            )
        
        return True, None

