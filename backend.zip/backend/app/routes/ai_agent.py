"""
AI Agent API Endpoints for EventGuard
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Request
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field, field_validator
from typing import Optional, Dict, Any
import tempfile
import os
import logging
import re

from app.database import get_db
from app.services.ai_agent_service import AIAgentService
from app.middleware.request_id import get_request_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ai", tags=["AI Agent"])


class ChatMessage(BaseModel):
    message: str = Field(..., min_length=1, max_length=1000)  # Increased for voice input
    conversation_id: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    
    @field_validator('message')
    def validate_message(cls, v: str) -> str:
        """Security: Sanitize and validate message input"""
        # Remove dangerous characters
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        # Limit length
        if len(v) > 1000:
            v = v[:1000]
        return v.strip()


class ChatResponse(BaseModel):
    reply: str
    conversation_id: str
    data: Optional[Dict[str, Any]] = None
    action: Optional[str] = None


# In-memory conversation storage
conversations: Dict[str, Dict[str, Any]] = {}


@router.post("/chat", response_model=ChatResponse)
async def chat(
    message: ChatMessage,
    request: Request,
    db: Session = Depends(get_db)
):
    """Text-based chat with AI agent"""
    try:
        agent = AIAgentService(db)
        conv_id = message.conversation_id or get_request_id(request)
        context = conversations.get(conv_id, {})
        
        if message.context:
            context.update(message.context)
        
        result = agent.process_message(message.message, context)
        conversations[conv_id] = context
        
        return ChatResponse(
            reply=result["reply"],
            conversation_id=conv_id,
            data=result.get("data"),
            action=result.get("action")
        )
    
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Chat error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Chat failed: {str(e)}")


@router.post("/voice", response_model=ChatResponse)
async def voice(
    audio: UploadFile = File(...),
    conversation_id: Optional[str] = None,
    request: Request = None,
    db: Session = Depends(get_db)
):
    """Voice-based chat with AI agent"""
    try:
        agent = AIAgentService(db)
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as tmp:
            content = await audio.read()
            tmp.write(content)
            tmp_path = tmp.name
        
        try:
            text = agent.transcribe_audio(tmp_path)
            
            if not text:
                # Silent failure - return empty response, frontend will handle gracefully
                return ChatResponse(
                    reply="",
                    conversation_id=conversation_id or get_request_id(request),
                    data={"transcribed_text": ""},
                    action="no_speech"
                )
            
            conv_id = conversation_id or get_request_id(request)
            context = conversations.get(conv_id, {})
            result = agent.process_message(text, context)
            conversations[conv_id] = context
            
            # Include transcribed text in response so frontend can show it as user message
            response_data = result.get("data", {})
            response_data["transcribed_text"] = text
            response_data["original_text"] = text
            
            return ChatResponse(
                reply=result["reply"],
                conversation_id=conv_id,
                data=response_data,
                action=result.get("action")
            )
        
        finally:
            try:
                os.unlink(tmp_path)
            except:
                pass
    
    except Exception as e:
        request_id = get_request_id(request)
        error_msg = str(e)
        logger.error(f"[{request_id}] Voice error: {error_msg}", exc_info=True)
        
        # Provide user-friendly error messages that encourage text input
        if "Whisper transcription service is not available" in error_msg or "not found" in error_msg.lower():
            detail = "Voice transcription is not configured. Please use text input instead - it works perfectly!"
        elif "No speech detected" in error_msg:
            detail = "No speech detected. Please try again or use text input."
        elif "Transcription timed out" in error_msg or "timeout" in error_msg.lower():
            detail = "Transcription timed out. Please use text input instead."
        elif "FileNotFoundError" in error_msg or "Whisper" in error_msg:
            detail = "Voice transcription service is not available. Please use text input instead - it's faster and more reliable!"
        else:
            detail = "Voice processing failed. Please use text input instead - it works great!"
        
        raise HTTPException(status_code=500, detail=detail)


@router.delete("/conversations/{conversation_id}")
async def clear_conversation(conversation_id: str):
    """Clear conversation context"""
    if conversation_id in conversations:
        del conversations[conversation_id]
    return {"message": "Conversation cleared"}


@router.get("/health")
async def health():
    """Health check"""
    return {"status": "ok", "service": "ai_agent"}
