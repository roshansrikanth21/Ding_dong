"""
Database migration script to add new columns.
Run this once to update existing databases.
"""
from sqlalchemy import text
from app.database import engine, SessionLocal


def migrate_database():
    """Add new columns to existing database if they don't exist"""
    db = SessionLocal()
    try:
        # Check if carrier column exists
        result = db.execute(text("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name='shipments' AND column_name='carrier'
        """))
        
        if result.fetchone() is None:
            print("Adding carrier column...")
            db.execute(text("ALTER TABLE shipments ADD COLUMN carrier VARCHAR"))
            db.commit()
            print("✓ Added carrier column")
        else:
            print("✓ carrier column already exists")
        
        # Check if notes column exists
        result = db.execute(text("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name='shipments' AND column_name='notes'
        """))
        
        if result.fetchone() is None:
            print("Adding notes column...")
            db.execute(text("ALTER TABLE shipments ADD COLUMN notes VARCHAR"))
            db.commit()
            print("✓ Added notes column")
        else:
            print("✓ notes column already exists")
        
        # Check if deleted_at column exists
        result = db.execute(text("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name='shipments' AND column_name='deleted_at'
        """))
        
        if result.fetchone() is None:
            print("Adding deleted_at column...")
            db.execute(text("ALTER TABLE shipments ADD COLUMN deleted_at TIMESTAMP"))
            db.commit()
            print("✓ Added deleted_at column")
        else:
            print("✓ deleted_at column already exists")
        
        # Create indexes if they don't exist
        try:
            db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_carrier ON shipments(carrier)"))
            db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_deleted_at ON shipments(deleted_at)"))
            db.commit()
            print("✓ Indexes created/verified")
        except Exception as e:
            print(f"Note: Index creation: {e}")
        
        print("\n✅ Database migration completed successfully!")
        
    except Exception as e:
        print(f"❌ Migration error: {e}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    migrate_database()

