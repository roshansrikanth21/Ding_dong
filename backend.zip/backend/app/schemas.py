from pydantic import BaseModel, Field, field_validator
from datetime import datetime, timedelta
from typing import Optional, List
import re
import json
from app.models import ShipmentState
from app.tracking_validator import validate_tracking_number, get_tracking_info


def sanitize_tracking_number(value: str) -> str:
    """Sanitize tracking number to prevent XSS and injection attacks - SECURITY HARDENED"""
    if not value or not isinstance(value, str):
        return ""
    
    # Security: Limit length to prevent DoS
    if len(value) > 100:
        value = value[:100]
    
    # Remove any HTML/script tags and dangerous characters
    sanitized = re.sub(r'[<>"\';(){}[\]\\]', '', value)  # Remove dangerous characters
    sanitized = re.sub(r'[^\w\s\-\._]', '', sanitized)  # Keep only safe characters (\w includes _)
    return sanitized.strip().upper()  # Normalize to uppercase


class ShipmentCreate(BaseModel):
    tracking_number: str = Field(..., min_length=6, max_length=50)
    carrier: Optional[str] = None
    notes: Optional[str] = Field(None, max_length=500)
    command_id: Optional[str] = Field(None, max_length=255, description="Optional command ID for idempotency")
    
    # Inventory fields
    origin: Optional[str] = Field(None, max_length=200, description="Origin location/address")
    destination: Optional[str] = Field(None, max_length=200, description="Destination location/address")
    product_type: Optional[str] = Field(None, max_length=100, description="Product type/category")
    is_fragile: Optional[str] = Field(None, max_length=20, description="FRAGILE or NON_FRAGILE")
    storage_locations: Optional[str] = Field(None, max_length=2000, description="JSON array of storage waypoints")
    scheduled_date: Optional[datetime] = Field(None, description="Scheduled pickup/delivery date")
    estimated_delivery: Optional[datetime] = Field(None, description="Estimated delivery date")
    
    @field_validator('scheduled_date', 'estimated_delivery')
    @classmethod
    def validate_dates(cls, v: Optional[datetime], info) -> Optional[datetime]:
        """Validate dates are realistic (not too far in past/future)"""
        if v is None:
            return v
        
        now = datetime.utcnow()
        # Allow dates up to 10 years in the past (for historical data)
        min_date = now - timedelta(days=3650)
        # Allow dates up to 1 year in the future (reasonable scheduling window)
        max_date = now + timedelta(days=365)
        
        if v < min_date:
            raise ValueError(f"Date cannot be more than 10 years in the past. Provided: {v.isoformat()}")
        if v > max_date:
            raise ValueError(f"Date cannot be more than 1 year in the future. Provided: {v.isoformat()}")
        
        return v
    
    @field_validator('estimated_delivery')
    @classmethod
    def validate_estimated_delivery(cls, v: Optional[datetime], values) -> Optional[datetime]:
        """Ensure estimated_delivery is after scheduled_date if both provided"""
        if v is None:
            return v
        
        scheduled = values.data.get('scheduled_date') if hasattr(values, 'data') else None
        if scheduled and v < scheduled:
            raise ValueError(f"Estimated delivery ({v.isoformat()}) must be after scheduled date ({scheduled.isoformat()})")
        
        return v
    
    @field_validator('tracking_number')
    @classmethod
    def validate_tracking_number(cls, v: str) -> str:
        """Validate and sanitize tracking number using industry-standard formats."""
        if not v or not v.strip():
            raise ValueError('Tracking number cannot be empty')
        
        # Sanitize the input
        sanitized = sanitize_tracking_number(v)
        
        if not sanitized:
            raise ValueError('Tracking number cannot be empty after sanitization')
        
        # Validate format using professional tracking validator
        is_valid, error, carrier = validate_tracking_number(sanitized, strict=False)
        
        if not is_valid:
            raise ValueError(error or 'Invalid tracking number format')
        
        return sanitized
    
    @field_validator('origin', 'destination', 'product_type')
    @classmethod
    def sanitize_text_fields(cls, v: Optional[str]) -> Optional[str]:
        """Sanitize text fields to prevent XSS"""
        if not v:
            return v
        # Remove dangerous characters
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        # Limit length
        if len(v) > 200:
            v = v[:200]
        return v.strip()
    
    @field_validator('is_fragile')
    @classmethod
    def validate_fragility(cls, v: Optional[str]) -> Optional[str]:
        """Validate fragility value"""
        if not v:
            return 'NON_FRAGILE'
        v = v.upper().strip()
        if v not in ['FRAGILE', 'NON_FRAGILE']:
            raise ValueError("is_fragile must be 'FRAGILE' or 'NON_FRAGILE'")
        return v
    
    @field_validator('storage_locations')
    @classmethod
    def validate_storage_locations(cls, v: Optional[str]) -> Optional[str]:
        """Validate and sanitize storage locations JSON"""
        if not v:
            return v
        # Security: Limit length
        if len(v) > 2000:
            raise ValueError("storage_locations JSON too long (max 2000 chars)")
        # Basic JSON validation
        try:
            parsed = json.loads(v)
            if not isinstance(parsed, list):
                raise ValueError("storage_locations must be a JSON array")
            # Limit array size
            if len(parsed) > 50:
                raise ValueError("Maximum 50 waypoints allowed")
            # Sanitize each waypoint name
            sanitized = []
            for wp in parsed:
                if isinstance(wp, str):
                    wp_clean = re.sub(r'[<>"\';(){}[\]\\]', '', wp)[:200]
                    if wp_clean:
                        sanitized.append(wp_clean)
            return json.dumps(sanitized) if sanitized else None
        except json.JSONDecodeError:
            raise ValueError("storage_locations must be valid JSON array")
    
    @field_validator('notes')
    @classmethod
    def sanitize_notes(cls, v: Optional[str]) -> Optional[str]:
        """Sanitize notes to prevent XSS"""
        if not v:
            return v
        # Remove dangerous characters
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        # Limit length
        if len(v) > 500:
            v = v[:500]
        return v.strip()
    
    @field_validator('carrier')
    @classmethod
    def sanitize_carrier(cls, v: Optional[str]) -> Optional[str]:
        """Sanitize carrier name"""
        if not v:
            return v
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        if len(v) > 100:
            v = v[:100]
        return v.strip()


class WaypointVisitCreate(BaseModel):
    """Schema for recording waypoint visits"""
    waypoint_name: str = Field(..., min_length=1, max_length=200, description="Warehouse/waypoint name")
    notes: Optional[str] = Field(None, max_length=500, description="Optional notes about this visit")
    actor: Optional[str] = Field(None, max_length=100, description="Who recorded this visit")
    
    @field_validator('waypoint_name')
    @classmethod
    def sanitize_waypoint_name(cls, v: str) -> str:
        """Sanitize waypoint name"""
        if not v:
            raise ValueError("waypoint_name cannot be empty")
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        if len(v) > 200:
            v = v[:200]
        return v.strip()
    
    @field_validator('notes')
    @classmethod
    def sanitize_notes(cls, v: Optional[str]) -> Optional[str]:
        """Sanitize notes"""
        if not v:
            return v
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        if len(v) > 500:
            v = v[:500]
        return v.strip()


class WaypointVisitResponse(BaseModel):
    """Response schema for waypoint visits"""
    id: int
    waypoint_name: str
    arrived_at: datetime
    departed_at: Optional[datetime] = None
    notes: Optional[str] = None
    actor: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class BulkShipmentCreate(BaseModel):
    tracking_numbers: List[str] = Field(..., min_items=1, max_items=100)
    command_id: Optional[str] = Field(None, max_length=255, description="Optional command ID for idempotency")
    
    @field_validator('tracking_numbers')
    @classmethod
    def validate_tracking_numbers(cls, v: List[str]) -> List[str]:
        """Validate and sanitize all tracking numbers"""
        if not v or len(v) == 0:
            raise ValueError('At least one tracking number required')
        if len(v) > 100:
            raise ValueError('Maximum 100 tracking numbers per batch')
        
        sanitized = []
        for tn in v:
            if not tn or not isinstance(tn, str):
                continue
            clean = sanitize_tracking_number(tn)
            if clean:
                sanitized.append(clean)
        
        if not sanitized:
            raise ValueError('No valid tracking numbers after sanitization')
        
        return sanitized


class ShipmentUpdate(BaseModel):
    notes: Optional[str] = Field(None, max_length=500)
    
    @field_validator('notes')
    @classmethod
    def sanitize_notes(cls, v: Optional[str]) -> Optional[str]:
        """Sanitize notes to prevent XSS"""
        if not v:
            return v
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        if len(v) > 500:
            v = v[:500]
        return v.strip()


class ShipmentDeleteRequest(BaseModel):
    permanent: bool = False


class StateTransitionRequest(BaseModel):
    target_state: ShipmentState
    actor: Optional[str] = Field(None, max_length=100)
    reason: Optional[str] = Field(None, max_length=500)
    idempotency_key: Optional[str] = Field(None, max_length=255)
    command_id: Optional[str] = Field(None, max_length=255, description="Optional command ID for idempotency (unique per shipment)")
    
    @field_validator('actor', 'reason')
    @classmethod
    def sanitize_string_fields(cls, v: Optional[str], info) -> Optional[str]:
        """Sanitize string fields"""
        if not v:
            return v
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        max_len = 100 if info.field_name == 'actor' else 500
        if len(v) > max_len:
            v = v[:max_len]
        return v.strip()


class RecoverFromExceptionRequest(BaseModel):
    target_state: ShipmentState = Field(..., description="State to recover to (must not be EXCEPTION)")
    actor: Optional[str] = Field(None, max_length=100)
    reason: str = Field(..., min_length=1, max_length=500, description="Reason for recovery")
    command_id: Optional[str] = Field(None, max_length=255, description="Optional command ID for idempotency (unique per shipment)")
    
    @field_validator('actor', 'reason')
    @classmethod
    def sanitize_string_fields(cls, v: Optional[str], info) -> Optional[str]:
        """Sanitize string fields"""
        if not v:
            return v if info.field_name == 'actor' else None
        v = re.sub(r'[<>"\';(){}[\]\\]', '', v)
        max_len = 100 if info.field_name == 'actor' else 500
        if len(v) > max_len:
            v = v[:max_len]
        return v.strip()


class StateTransitionResponse(BaseModel):
    id: int
    from_state: Optional[str]
    to_state: str
    timestamp: datetime
    actor: Optional[str] = None
    reason: Optional[str] = None
    transition_metadata: Optional[str] = None
    transition_version: Optional[str] = None

    class Config:
        from_attributes = True


class ShipmentResponse(BaseModel):
    id: str  # public_id (UUID) instead of integer id
    tracking_number: str
    serial_number: Optional[int] = None
    carrier: Optional[str] = None
    current_state: str
    notes: Optional[str] = None
    version: Optional[int] = None  # Optimistic locking version
    state_version: Optional[str] = None  # State machine version
    exception_reason: Optional[str] = None  # Reason if in EXCEPTION state
    # Inventory fields
    origin: Optional[str] = None
    destination: Optional[str] = None
    product_type: Optional[str] = None
    is_fragile: Optional[str] = None
    storage_locations: Optional[str] = None
    scheduled_date: Optional[datetime] = None
    estimated_delivery: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
        populate_by_name = True

    @classmethod
    def model_validate(cls, obj):
        """Override to map public_id to id field in response"""
        if hasattr(obj, '__dict__'):
            # SQLAlchemy model object
            data = {
                'id': obj.public_id,
                'tracking_number': obj.tracking_number,
                'serial_number': getattr(obj, 'serial_number', None),
                'carrier': obj.carrier,
                'current_state': obj.current_state.value if hasattr(obj.current_state, 'value') else str(obj.current_state),
                'notes': obj.notes,
                'version': getattr(obj, 'version', None),
                'state_version': getattr(obj, 'state_version', None),
                'exception_reason': getattr(obj, 'exception_reason', None),
                # Inventory fields
                'origin': getattr(obj, 'origin', None),
                'destination': getattr(obj, 'destination', None),
                'product_type': getattr(obj, 'product_type', None),
                'is_fragile': getattr(obj, 'is_fragile', None),
                'storage_locations': getattr(obj, 'storage_locations', None),
                'scheduled_date': getattr(obj, 'scheduled_date', None),
                'estimated_delivery': getattr(obj, 'estimated_delivery', None),
                'created_at': obj.created_at,
                'updated_at': obj.updated_at,
            }
            return cls(**data)
        return super().model_validate(obj)


class ShipmentDetailResponse(ShipmentResponse):
    transitions: list[StateTransitionResponse] = []
    waypoint_visits: list[WaypointVisitResponse] = []  # Add waypoint visits


class ShipmentListResponse(BaseModel):
    shipments: list[ShipmentResponse]
    total: int
    page: int
    limit: int


class ActivityEventResponse(BaseModel):
    id: int
    shipment_id: str  # public_id instead of integer id
    tracking_number: str
    carrier: Optional[str] = None
    from_state: Optional[str] = None
    to_state: str
    timestamp: datetime
    actor: Optional[str] = None
    reason: Optional[str] = None


class AgingBucket(BaseModel):
    label: str
    min_days: float
    max_days: Optional[float] = None
    count: int


class StaleShipmentResponse(BaseModel):
    id: str  # public_id instead of integer id
    tracking_number: str
    carrier: Optional[str] = None
    current_state: str
    age_days: float
    updated_at: datetime


class AgingInsightsResponse(BaseModel):
    generated_at: datetime
    active_total: int
    stale_threshold_days: int
    buckets: List[AgingBucket]
    stale_shipments: List[StaleShipmentResponse]
