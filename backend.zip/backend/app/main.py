"""
Main FastAPI Application - Refactored with Clean Architecture.
Controllers handle only request/response, delegates business logic to services.
"""
from fastapi import FastAPI, Depends, HTTPException, Query, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import func, desc, and_
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import csv
import io
import logging

from app.database import get_db, init_db
from app.models import Shipment, StateTransition, ShipmentState
from app.schemas import (
    ShipmentCreate,
    ShipmentResponse,
    ShipmentDetailResponse,
    ShipmentListResponse,
    StateTransitionRequest,
    StateTransitionResponse,
    BulkShipmentCreate,
    ShipmentUpdate,
    ActivityEventResponse,
    AgingInsightsResponse,
    AgingBucket,
    StaleShipmentResponse,
    RecoverFromExceptionRequest,
    WaypointVisitCreate,
    WaypointVisitResponse,
)
from app.services.shipment_service import ShipmentService
from app.services.state_service import StateService, StateTransitionError
from app.validators.shipment_validator import ValidationError
from app.repositories.shipment_repository import ShipmentRepository
from app.repositories.transition_repository import TransitionRepository
from app.repositories.waypoint_repository import WaypointRepository
from app.middleware.rate_limiter import RateLimitMiddleware
from app.middleware.request_limits import RequestLimitsMiddleware
from app.middleware.timeout import TimeoutMiddleware
from app.middleware.request_id import RequestIDMiddleware, get_request_id
from app.hardening.observability import get_health_indicators
from app.routes.ai_agent import router as ai_router

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="EventGuard API", version="2.0.0", description="Production-grade shipment tracking system")

# CORS middleware for frontend - SECURITY HARDENED
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000", "http://frontend:3000"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],  # Explicit methods only
    allow_headers=["Content-Type", "Authorization", "X-Request-ID"],  # Explicit headers only
    expose_headers=["X-Request-ID"],  # Only expose necessary headers
    max_age=3600,  # Cache preflight for 1 hour
)

# PART 2: Backend Load-Safe Guardrails
# Middleware order matters - apply in reverse order of execution:
# 1. Request ID (innermost - generates ID first)
# 2. Timeout (enforces processing timeouts)
# 3. Request Limits (check body size, JSON depth)
# 4. Rate Limiting (outermost - first to reject)
app.add_middleware(RequestIDMiddleware)  # PART 1: Minimal observability - request_id per request
app.add_middleware(TimeoutMiddleware)  # PART 2.3: Request processing timeouts
app.add_middleware(RequestLimitsMiddleware)  # PART 2.2: Hard limits on resource-intensive operations
app.add_middleware(RateLimitMiddleware)  # PART 2.1: Rate limiting (defense-in-depth)

app.include_router(ai_router)


@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    """Add security headers to all responses."""
    response = await call_next(request)
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "font-src 'self'; "
        "connect-src 'self' http://localhost:8000 http://localhost:3000;"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response


@app.on_event("startup")
def startup_event():
    """Initialize database on startup"""
    init_db()
    logger.info("EventGuard API started successfully")


@app.exception_handler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    """Handle validation errors with structured error semantics"""
    request_id = get_request_id(request)
    logger.warning(f"[{request_id}] Validation error: {exc.message} (field: {exc.field})")
    
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "error_code": exc.code or "VALIDATION_ERROR",
            "message": exc.message,
            "classification": "non-retryable",
            "field": exc.field,
            "request_id": request_id
        }
    )


@app.exception_handler(StateTransitionError)
async def state_transition_exception_handler(request: Request, exc: StateTransitionError):
    """
    Handle state transition errors with structured error semantics:
    - HTTP 409 CONFLICT: Concurrency/version conflicts (retryable)
    - HTTP 400 BAD REQUEST: Logic violations, invariant failures (non-retryable)
    """
    request_id = get_request_id(request)
    
    # PART 1: Structured error semantics
    if exc.retryable:
        status_code = status.HTTP_409_CONFLICT
        error_code = exc.code or "CONCURRENCY_CONFLICT"
        classification = "retryable"
    else:
        status_code = status.HTTP_400_BAD_REQUEST
        error_code = exc.code or "INVALID_TRANSITION"
        classification = "non-retryable"
    
    logger.warning(f"[{request_id}] State transition error: {error_code} - {exc.message} (classification: {classification})")
    
    return JSONResponse(
        status_code=status_code,
        content={
            "error_code": error_code,
            "message": exc.message,
            "classification": classification,
            "request_id": request_id
        }
    )


# ==================== Shipment Endpoints ====================

@app.post("/shipments", response_model=ShipmentResponse, status_code=201)
def create_shipment(
    shipment: ShipmentCreate,
    request: Request,  # PART 1: Get request for request_id
    actor: Optional[str] = Query(None, description="Who is creating the shipment"),
    db: Session = Depends(get_db)
):
    """
    Create a new shipment with initial state CREATED.
    Automatically detects carrier from tracking number format.
    """
    try:
        service = ShipmentService(db)
        created = service.create_shipment(
            tracking_number=shipment.tracking_number,
            carrier=shipment.carrier,
            notes=shipment.notes,
            actor=actor or "system",
            origin=shipment.origin,
            destination=shipment.destination,
            product_type=shipment.product_type,
            is_fragile=shipment.is_fragile,
            storage_locations=shipment.storage_locations,
            scheduled_date=shipment.scheduled_date,
            estimated_delivery=shipment.estimated_delivery
        )
        
        # Convert to response format
        return ShipmentResponse(
            id=created.public_id,
            tracking_number=created.tracking_number,
            serial_number=created.serial_number,
            carrier=created.carrier,
            current_state=created.current_state.value,
            notes=created.notes,
            version=created.version,
            state_version=created.state_version,
            exception_reason=created.exception_reason,
            origin=created.origin,
            destination=created.destination,
            product_type=created.product_type,
            is_fragile=created.is_fragile,
            storage_locations=created.storage_locations,
            scheduled_date=created.scheduled_date,
            estimated_delivery=created.estimated_delivery,
            created_at=created.created_at,
            updated_at=created.updated_at,
        )
    except ValidationError:
        raise
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error creating shipment: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to create shipment",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.post("/shipments/bulk", response_model=List[ShipmentResponse], status_code=201)
def create_bulk_shipments(
    bulk_data: BulkShipmentCreate,
    actor: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Create multiple shipments in a single request (bulk operation).
    Returns list of created shipments and any errors.
    """
    service = ShipmentService(db)
    created = []
    errors = []
    
    for tracking_number in bulk_data.tracking_numbers:
        try:
            shipment = service.create_shipment(
                tracking_number=tracking_number,
                actor=actor or "system"
            )
            created.append(shipment)
        except ValidationError as e:
            errors.append({"tracking_number": tracking_number, "error": e.message})
        except Exception as e:
            errors.append({"tracking_number": tracking_number, "error": str(e)})
    
    if errors:
        return JSONResponse(
            status_code=207,  # Multi-Status
            content={
                "created": [
                    {
                        "id": s.public_id,
                        "tracking_number": s.tracking_number
                    }
                    for s in created
                ],
                "errors": errors,
                "total_created": len(created),
                "total_errors": len(errors)
            }
        )
    
    # Convert to response format
    return [
        ShipmentResponse(
            id=s.public_id,
            tracking_number=s.tracking_number,
            serial_number=s.serial_number,
            carrier=s.carrier,
            current_state=s.current_state.value,
            notes=s.notes,
            version=s.version,
            state_version=s.state_version,
            exception_reason=s.exception_reason,
            # Inventory fields
            origin=s.origin,
            destination=s.destination,
            product_type=s.product_type,
            is_fragile=s.is_fragile,
            storage_locations=s.storage_locations,
            scheduled_date=s.scheduled_date,
            estimated_delivery=s.estimated_delivery,
            created_at=s.created_at,
            updated_at=s.updated_at,
        )
        for s in created
    ]


@app.post("/shipments/{shipment_id}/transition", response_model=StateTransitionResponse)
def transition_shipment(
    shipment_id: str,
    transition: StateTransitionRequest,
    request: Request,  # PART 1: Get request for request_id
    db: Session = Depends(get_db)
):
    """
    Transition shipment to a new state with full transactional safety and retry logic.
    """
    try:
        state_service = StateService(db)
        
        # Use retry logic for concurrent safety
        transition_obj, updated_shipment = state_service.transition_with_retry(
            shipment_id=shipment_id,
            target_state=transition.target_state,
            actor=transition.actor or "system",
            reason=transition.reason,
            idempotency_key=transition.idempotency_key,
            command_id=transition.command_id,  # TASK 2: Pass command_id for idempotency
            max_retries=3
        )
        
        # Commit the transaction
        db.commit()
        
        return StateTransitionResponse(
            id=transition_obj.id,
            from_state=transition_obj.from_state.value if transition_obj.from_state else None,
            to_state=transition_obj.to_state.value,
            timestamp=transition_obj.timestamp,
            actor=transition_obj.actor,
            reason=transition_obj.reason,
            transition_metadata=transition_obj.transition_metadata,
            transition_version=transition_obj.transition_version,
        )
    except StateTransitionError:
        db.rollback()
        # TASK 3: Let exception handler set correct HTTP status (409 for conflicts, 400 for violations)
        raise  # Re-raise to let exception handler process with correct status code
    except Exception as e:
        db.rollback()
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error transitioning shipment: {str(e)}", exc_info=True)
        # PART 1: Structured error semantics
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to transition shipment",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.post("/shipments/{shipment_id}/recover", response_model=StateTransitionResponse)
def recover_from_exception(
    shipment_id: str,
    recovery: RecoverFromExceptionRequest,
    request: Request,  # PART 1: Get request for request_id
    db: Session = Depends(get_db)
):
    """
    Recover a shipment from EXCEPTION state to a valid state.
    """
    try:
        state_service = StateService(db)
        
        transition_obj, updated_shipment = state_service.recover_from_exception(
            shipment_id=shipment_id,
            target_state=recovery.target_state,
            actor=recovery.actor or "system",
            reason=recovery.reason,
            command_id=recovery.command_id  # TASK 2: Pass command_id for idempotency
        )
        
        # Commit the transaction
        db.commit()
        
        return StateTransitionResponse(
            id=transition_obj.id,
            from_state=transition_obj.from_state.value if transition_obj.from_state else None,
            to_state=transition_obj.to_state.value,
            timestamp=transition_obj.timestamp,
            actor=transition_obj.actor,
            reason=transition_obj.reason,
            transition_metadata=transition_obj.transition_metadata,
            transition_version=transition_obj.transition_version,
        )
    except StateTransitionError:
        db.rollback()
        # TASK 3: Let exception handler set correct HTTP status (409 for conflicts, 400 for violations)
        raise  # Re-raise to let exception handler process with correct status code
    except Exception as e:
        db.rollback()
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error recovering shipment: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to recover shipment",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/shipments", response_model=ShipmentListResponse)
def list_shipments(
    request: Request,  # PART 1: Get request for request_id
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    status: Optional[ShipmentState] = Query(None),
    carrier: Optional[str] = Query(None),
    search: Optional[str] = Query(None, min_length=1, max_length=100),
    sort_by: Optional[str] = Query("updated_at", regex="^(id|tracking_number|current_state|created_at|updated_at)$"),
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$"),
    db: Session = Depends(get_db)
):
    """
    Get paginated list of shipments with optional filters.
    """
    try:
        repo = ShipmentRepository(db)
        shipments, total = repo.list(
            page=page,
            limit=limit,
            status=status,
            carrier=carrier,
            search=search,
            sort_by=sort_by,
            sort_order=sort_order,
            include_deleted=False
        )
        
        # Ensure public_id exists and convert to response format
        shipment_responses = []
        for shipment in shipments:
            if not shipment.public_id:
                import uuid
                shipment.public_id = str(uuid.uuid4())
                db.commit()
            
            shipment_responses.append(ShipmentResponse(
                id=shipment.public_id,
                tracking_number=shipment.tracking_number,
                serial_number=shipment.serial_number,
                carrier=shipment.carrier,
                current_state=shipment.current_state.value,
                notes=shipment.notes,
                version=shipment.version,
                state_version=shipment.state_version,
                exception_reason=shipment.exception_reason,
                # Inventory fields
                origin=shipment.origin,
                destination=shipment.destination,
                product_type=shipment.product_type,
                is_fragile=shipment.is_fragile,
                storage_locations=shipment.storage_locations,
                scheduled_date=shipment.scheduled_date,
                estimated_delivery=shipment.estimated_delivery,
                created_at=shipment.created_at,
                updated_at=shipment.updated_at,
            ))
        
        return ShipmentListResponse(
            shipments=shipment_responses,
            total=total,
            page=page,
            limit=limit
        )
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error listing shipments: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to list shipments",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/shipments/{shipment_id}", response_model=ShipmentDetailResponse)
def get_shipment(shipment_id: str, request: Request, db: Session = Depends(get_db)):
    """
    Get full shipment detail including state history and waypoint visits.
    Security: Validates shipment_id format (UUID), prevents path traversal.
    Excludes soft-deleted shipments.
    """
    # Security: Validate shipment_id is a valid UUID format to prevent path traversal
    import re
    uuid_pattern = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.IGNORECASE)
    if not uuid_pattern.match(shipment_id):
        request_id = get_request_id(request)
        raise HTTPException(
            status_code=400,
            detail={
                "error_code": "INVALID_ID",
                "message": "Invalid shipment ID format",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )
    
    try:
        repo = ShipmentRepository(db)
        transition_repo = TransitionRepository(db)
        waypoint_repo = WaypointRepository(db)
        
        shipment = repo.get_by_public_id(shipment_id)
        if not shipment:
            request_id = get_request_id(request)
            raise HTTPException(
                status_code=404,
                detail={
                    "error_code": "NOT_FOUND",
                    "message": "Shipment not found",
                    "classification": "non-retryable",
                    "request_id": request_id
                }
            )
        
        transitions = transition_repo.get_by_shipment_id(shipment.id)
        waypoint_visits = waypoint_repo.get_by_shipment_id(shipment.id)
        
        # Convert to response format
        return ShipmentDetailResponse(
            id=shipment.public_id,
            tracking_number=shipment.tracking_number,
            serial_number=shipment.serial_number,
            carrier=shipment.carrier,
            current_state=shipment.current_state.value,
            notes=shipment.notes,
            version=shipment.version,
            state_version=shipment.state_version,
            exception_reason=shipment.exception_reason,
            # Inventory fields
            origin=shipment.origin,
            destination=shipment.destination,
            product_type=shipment.product_type,
            is_fragile=shipment.is_fragile,
            storage_locations=shipment.storage_locations,
            scheduled_date=shipment.scheduled_date,
            estimated_delivery=shipment.estimated_delivery,
            created_at=shipment.created_at,
            updated_at=shipment.updated_at,
            transitions=[
                StateTransitionResponse(
                    id=t.id,
                    from_state=t.from_state.value if t.from_state else None,
                    to_state=t.to_state.value,
                    timestamp=t.timestamp,
                    actor=t.actor,
                    reason=t.reason,
                    transition_metadata=t.transition_metadata,
                    transition_version=t.transition_version,
                )
                for t in transitions
            ],
            waypoint_visits=[
                WaypointVisitResponse(
                    id=w.id,
                    waypoint_name=w.waypoint_name,
                    arrived_at=w.arrived_at,
                    departed_at=w.departed_at,
                    notes=w.notes,
                    actor=w.actor,
                    created_at=w.created_at,
                )
                for w in waypoint_visits
            ]
        )
    except HTTPException:
        raise
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error getting shipment: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to get shipment",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/shipments/{shipment_id}/timeline", response_model=List[StateTransitionResponse])
def get_shipment_timeline(shipment_id: str, request: Request, db: Session = Depends(get_db)):
    """
    Get ordered list of state transitions with timestamps and audit information.
    """
    try:
        repo = ShipmentRepository(db)
        transition_repo = TransitionRepository(db)
        
        shipment = repo.get_by_public_id(shipment_id)
        if not shipment:
            request_id = get_request_id(request)
            raise HTTPException(
                status_code=404,
                detail={
                    "error_code": "NOT_FOUND",
                    "message": "Shipment not found",
                    "classification": "non-retryable",
                    "request_id": request_id
                }
            )
        
        transitions = transition_repo.get_by_shipment_id(shipment.id)
        
        return [
            StateTransitionResponse(
                id=t.id,
                from_state=t.from_state.value if t.from_state else None,
                to_state=t.to_state.value,
                timestamp=t.timestamp,
                actor=t.actor,
                reason=t.reason,
                transition_metadata=t.transition_metadata,
                transition_version=t.transition_version,
            )
            for t in transitions
        ]
    except HTTPException:
        raise
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error getting timeline: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": f"Failed to get timeline: {str(e)}",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.post("/shipments/{shipment_id}/replay")
def replay_shipment_events(
    shipment_id: str,
    request: Request,  # PART 1: Get request for request_id
    max_events: Optional[int] = Query(None, ge=1, le=1000, description="Maximum events to replay (debug-only)"),
    db: Session = Depends(get_db)
):
    """
    TASK 1: Replay events with integrity enforcement.
    TASK 4: Replay abuse guardrails - capped at 1000 events.
    
    Replays all events for a shipment and validates invariants at each step.
    Aborts immediately on any violation - no silent recovery, no best-effort reconstruction.
    
    WARNING: This is a debug-only endpoint. Replay must prove both determinism and integrity.
    """
    try:
        from app.services.replay_service import ReplayService, ReplayIntegrityError
        
        replay_service = ReplayService(db)
        
        request_id = get_request_id(request)
        replayed, summary = replay_service.replay_events(shipment_id, max_events)
        
        # PART 1: Include "debug-only" flag in replay response
        return {
            "message": summary.get("message"),
            "events_processed": summary.get("events_processed", 0),
            "replay_valid": summary.get("replay_valid", True),
            "debug_only": True,  # PART 1: Visible "debug-only" flag
            "request_id": request_id,
            "events": [
                {
                    "id": t.id,
                    "from_state": t.from_state.value if t.from_state else None,
                    "to_state": t.to_state.value,
                    "timestamp": t.timestamp.isoformat(),
                    "actor": t.actor,
                    "reason": t.reason
                }
                for t in replayed
            ]
        }
    except ReplayIntegrityError as e:
        request_id = get_request_id(request)
        # PART 1: Structured error semantics
        raise HTTPException(
            status_code=400,
            detail={
                "error_code": "REPLAY_ABORTED",
                "message": e.message,
                "classification": "non-retryable",
                "violation_details": e.violation_details,
                "replay_valid": False,
                "debug_only": True,
                "request_id": request_id
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error replaying events: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to replay events",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.patch("/shipments/{shipment_id}", response_model=ShipmentResponse)
def update_shipment(
    shipment_id: str,
    update: ShipmentUpdate,
    request: Request,  # PART 1: Get request for request_id
    actor: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Update shipment notes. Notes can be updated even in terminal states.
    """
    try:
        service = ShipmentService(db)
        updated = service.update_notes(
            shipment_id=shipment_id,
            notes=update.notes,
            actor=actor or "system"
        )
        
        return ShipmentResponse(
            id=updated.public_id,
            tracking_number=updated.tracking_number,
            serial_number=updated.serial_number,
            carrier=updated.carrier,
            current_state=updated.current_state.value,
            notes=updated.notes,
            version=updated.version,
            state_version=updated.state_version,
            exception_reason=updated.exception_reason,
            # Inventory fields
            origin=updated.origin,
            destination=updated.destination,
            product_type=updated.product_type,
            is_fragile=updated.is_fragile,
            storage_locations=updated.storage_locations,
            scheduled_date=updated.scheduled_date,
            estimated_delivery=updated.estimated_delivery,
            created_at=updated.created_at,
            updated_at=updated.updated_at,
        )
    except ValidationError:
        raise
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error updating shipment: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to update shipment",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.delete("/shipments/{shipment_id}")
def delete_shipment(
    shipment_id: str,
    request: Request,  # PART 1: Get request for request_id
    permanent: bool = Query(False),
    actor: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Soft delete a shipment (or permanent if permanent=true).
    Only allows deletion of shipments in CREATED or CANCELLED states.
    """
    try:
        service = ShipmentService(db)
        service.delete_shipment(
            shipment_id=shipment_id,
            permanent=permanent,
            actor=actor or "system"
        )
        return {"message": f"Shipment {'permanently deleted' if permanent else 'soft deleted'}"}
    except ValidationError:
        raise
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error deleting shipment: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to delete shipment",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


# ==================== Analytics Endpoints ====================

@app.post("/shipments/{shipment_id}/waypoints", response_model=WaypointVisitResponse, status_code=201)
def record_waypoint_visit(
    shipment_id: str,
    waypoint: WaypointVisitCreate,
    request: Request,
    actor: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Record that a shipment has arrived at a waypoint/warehouse.
    Security: Validates shipment exists and sanitizes all inputs.
    """
    try:
        repo = ShipmentRepository(db)
        waypoint_repo = WaypointRepository(db)
        
        shipment = repo.get_by_public_id(shipment_id)
        if not shipment:
            request_id = get_request_id(request)
            raise HTTPException(
                status_code=404,
                detail={
                    "error_code": "NOT_FOUND",
                    "message": "Shipment not found",
                    "classification": "non-retryable",
                    "request_id": request_id
                }
            )
        
        from app.models import WaypointVisit
        from datetime import datetime
        
        visit = WaypointVisit(
            shipment_id=shipment.id,
            waypoint_name=waypoint.waypoint_name,
            notes=waypoint.notes,
            actor=actor or waypoint.actor or "system",
            arrived_at=datetime.utcnow()
        )
        
        waypoint_repo.create(visit)
        db.commit()
        
        return WaypointVisitResponse(
            id=visit.id,
            waypoint_name=visit.waypoint_name,
            arrived_at=visit.arrived_at,
            departed_at=visit.departed_at,
            notes=visit.notes,
            actor=visit.actor,
            created_at=visit.created_at,
        )
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error recording waypoint visit: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to record waypoint visit",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.patch("/shipments/{shipment_id}/waypoints/{waypoint_id}/depart", response_model=WaypointVisitResponse)
def mark_waypoint_departed(
    shipment_id: str,
    waypoint_id: int,
    request: Request,
    actor: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Mark that a shipment has departed from a waypoint.
    Security: Validates shipment and waypoint ownership.
    """
    try:
        repo = ShipmentRepository(db)
        waypoint_repo = WaypointRepository(db)
        
        shipment = repo.get_by_public_id(shipment_id)
        if not shipment:
            request_id = get_request_id(request)
            raise HTTPException(
                status_code=404,
                detail={
                    "error_code": "NOT_FOUND",
                    "message": "Shipment not found",
                    "classification": "non-retryable",
                    "request_id": request_id
                }
            )
        
        visit = waypoint_repo.mark_departed(waypoint_id, actor or "system")
        if not visit:
            request_id = get_request_id(request)
            raise HTTPException(
                status_code=404,
                detail={
                    "error_code": "NOT_FOUND",
                    "message": "Waypoint visit not found or already departed",
                    "classification": "non-retryable",
                    "request_id": request_id
                }
            )
        
        # Verify ownership
        if visit.shipment_id != shipment.id:
            request_id = get_request_id(request)
            raise HTTPException(
                status_code=403,
                detail={
                    "error_code": "FORBIDDEN",
                    "message": "Waypoint visit does not belong to this shipment",
                    "classification": "non-retryable",
                    "request_id": request_id
                }
            )
        
        db.commit()
        
        return WaypointVisitResponse(
            id=visit.id,
            waypoint_name=visit.waypoint_name,
            arrived_at=visit.arrived_at,
            departed_at=visit.departed_at,
            notes=visit.notes,
            actor=visit.actor,
            created_at=visit.created_at,
        )
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error marking waypoint departed: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to mark waypoint departed",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/statistics")
def get_statistics(
    request: Request,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db)
):
    """
    Get shipment statistics for dashboard.
    """
    try:
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        # Total shipments (excluding deleted)
        total_shipments = db.query(Shipment).filter(Shipment.deleted_at.is_(None)).count()
        
        # Shipments by state (excluding deleted)
        state_counts = db.query(
            Shipment.current_state,
            func.count(Shipment.id).label('count')
        ).filter(Shipment.deleted_at.is_(None)).group_by(Shipment.current_state).all()
        
        state_stats = {state.value: count for state, count in state_counts}
        
        # Shipments by carrier (excluding deleted)
        carrier_counts = db.query(
            Shipment.carrier,
            func.count(Shipment.id).label('count')
        ).filter(
            and_(
                Shipment.carrier.isnot(None),
                Shipment.deleted_at.is_(None)
            )
        ).group_by(Shipment.carrier).all()
        
        carrier_stats = {carrier: count for carrier, count in carrier_counts}
        
        # Recent shipments (last N days, excluding deleted)
        recent_shipments = db.query(Shipment).filter(
            and_(
                Shipment.created_at >= cutoff_date,
                Shipment.deleted_at.is_(None)
            )
        ).count()
        
        # Transitions in last N days
        recent_transitions = db.query(StateTransition).filter(
            StateTransition.timestamp >= cutoff_date
        ).count()
        
        # Average time in each state (for delivered shipments)
        delivered_shipments = db.query(Shipment).filter(
            and_(
                Shipment.current_state == ShipmentState.DELIVERED,
                Shipment.deleted_at.is_(None)
            )
        ).all()
        
        avg_delivery_time = None
        if delivered_shipments:
            total_seconds = 0
            for shipment in delivered_shipments:
                if shipment.transitions:
                    created_time = shipment.transitions[0].timestamp
                    delivered_time = next(
                        (t.timestamp for t in reversed(shipment.transitions) if t.to_state == ShipmentState.DELIVERED),
                        None
                    )
                    if delivered_time:
                        total_seconds += (delivered_time - created_time).total_seconds()
            
            if total_seconds > 0:
                avg_delivery_time = int(total_seconds / len(delivered_shipments))
        
        # Exception state count
        exception_count = db.query(Shipment).filter(
            and_(
                Shipment.current_state == ShipmentState.EXCEPTION,
                Shipment.deleted_at.is_(None)
            )
        ).count()
        
        return {
            "total_shipments": total_shipments,
            "state_distribution": state_stats,
            "carrier_distribution": carrier_stats,
            "recent_shipments": recent_shipments,
            "recent_transitions": recent_transitions,
            "average_delivery_time_seconds": avg_delivery_time,
            "exception_shipments": exception_count,
            "period_days": days
        }
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error getting statistics: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to get statistics",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/activity", response_model=List[ActivityEventResponse])
def get_activity(
    request: Request,
    days: int = Query(7, ge=1, le=90),
    limit: int = Query(50, ge=1, le=200),
    shipment_id: Optional[str] = Query(None),
    state: Optional[ShipmentState] = Query(None),
    db: Session = Depends(get_db),
):
    """
    Global activity feed for operators (recent state transitions across shipments).
    """
    try:
        transition_repo = TransitionRepository(db)
        rows = transition_repo.get_recent_activity(
            days=days,
            limit=limit,
            shipment_id=None,  # Will filter by public_id if needed
            state=state
        )
        
        # Filter by public_id if provided
        if shipment_id:
            repo = ShipmentRepository(db)
            shipment = repo.get_by_public_id(shipment_id)
            if shipment:
                rows = [r for r in rows if r[0].shipment_id == shipment.id]
        
        events: List[ActivityEventResponse] = []
        for transition, shipment_obj in rows:
            events.append(
                ActivityEventResponse(
                    id=transition.id,
                    shipment_id=shipment_obj.public_id,
                    tracking_number=shipment_obj.tracking_number,
                    carrier=shipment_obj.carrier,
                    from_state=transition.from_state.value if transition.from_state else None,
                    to_state=transition.to_state.value,
                    timestamp=transition.timestamp,
                    actor=transition.actor,
                    reason=transition.reason,
                )
            )
        
        return events
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error getting activity: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to get activity",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/insights/aging", response_model=AgingInsightsResponse)
def get_aging_insights(
    request: Request,
    stale_threshold_days: int = Query(7, ge=1, le=60),
    limit_stale: int = Query(25, ge=1, le=200),
    db: Session = Depends(get_db),
):
    """
    Operational aging/SLA-style insights: how long active shipments have been open, and which are stale.
    """
    try:
        now = datetime.utcnow()
        active_states = [ShipmentState.CREATED, ShipmentState.READY_FOR_PICKUP, ShipmentState.IN_TRANSIT]
        
        shipments = (
            db.query(Shipment)
            .filter(
                and_(
                    Shipment.deleted_at.is_(None),
                    Shipment.current_state.in_(active_states)
                )
            )
            .all()
        )
        
        def age_days(s: Shipment) -> float:
            return max(0.0, (now - (s.created_at or now)).total_seconds() / 86400.0)
        
        # Buckets tuned for logistics ops (triage)
        bucket_defs = [
            ("0–1 days", 0.0, 1.0),
            ("1–3 days", 1.0, 3.0),
            ("3–7 days", 3.0, 7.0),
            ("7–14 days", 7.0, 14.0),
            ("14+ days", 14.0, None),
        ]
        
        counts = {label: 0 for label, _, _ in bucket_defs}
        stale: List[StaleShipmentResponse] = []
        
        for s in shipments:
            a = age_days(s)
            placed = False
            for label, mn, mx in bucket_defs:
                if mx is None:
                    if a >= mn:
                        counts[label] += 1
                        placed = True
                        break
                else:
                    if mn <= a < mx:
                        counts[label] += 1
                        placed = True
                        break
            if not placed:
                counts[bucket_defs[0][0]] += 1
            
            if a >= float(stale_threshold_days):
                stale.append(
                    StaleShipmentResponse(
                        id=s.public_id,
                        tracking_number=s.tracking_number,
                        carrier=s.carrier,
                        current_state=s.current_state.value,
                        age_days=round(a, 2),
                        updated_at=s.updated_at,
                    )
                )
        
        # Sort stale by age desc, then updated_at asc (older + not recently touched first)
        stale.sort(key=lambda x: (-x.age_days, x.updated_at))
        stale = stale[:limit_stale]
        
        buckets: List[AgingBucket] = []
        for label, mn, mx in bucket_defs:
            buckets.append(AgingBucket(label=label, min_days=mn, max_days=mx, count=counts[label]))
        
        return AgingInsightsResponse(
            generated_at=now,
            active_total=len(shipments),
            stale_threshold_days=stale_threshold_days,
            buckets=buckets,
            stale_shipments=stale,
        )
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error getting aging insights: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to get aging insights",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/shipments/export/csv")
def export_shipments_csv(
    request: Request,
    status: Optional[ShipmentState] = Query(None),
    carrier: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Export shipments to CSV format.
    """
    try:
        repo = ShipmentRepository(db)
        shipments, _ = repo.list(
            page=1,
            limit=10000,  # Large limit for export
            status=status,
            carrier=carrier,
            include_deleted=False
        )
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow([
            'Public ID', 'Tracking Number', 'Carrier', 'Current State',
            'Version', 'State Version', 'Exception Reason',
            'Created At', 'Updated At', 'Notes'
        ])
        
        # Write data
        for shipment in shipments:
            writer.writerow([
                shipment.public_id,
                shipment.tracking_number,
                shipment.carrier or '',
                shipment.current_state.value,
                shipment.version,
                shipment.state_version,
                shipment.exception_reason or '',
                shipment.created_at.isoformat(),
                shipment.updated_at.isoformat(),
                shipment.notes or ''
            ])
        
        output.seek(0)
        
        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename=shipments_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
            }
        )
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error exporting shipments: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to export shipments",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/shipments/exception/list")
def list_exception_shipments(
    request: Request,
    db: Session = Depends(get_db)
):
    """
    List all shipments in EXCEPTION state for recovery operations.
    """
    try:
        repo = ShipmentRepository(db)
        exception_shipments = repo.find_in_exception_state()
        
        return {
            "total": len(exception_shipments),
            "shipments": [
                {
                    "id": s.public_id,
                    "tracking_number": s.tracking_number,
                    "current_state": s.current_state.value,
                    "exception_reason": s.exception_reason,
                    "exception_at": s.exception_at.isoformat() if s.exception_at else None,
                    "created_at": s.created_at.isoformat(),
                    "updated_at": s.updated_at.isoformat(),
                }
                for s in exception_shipments
            ]
        }
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error listing exception shipments: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to list exception shipments",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/tracking/validate")
def validate_tracking_format(tracking_number: str):
    """
    Validate and get information about a tracking number format.
    """
    from app.tracking_validator import get_tracking_info
    info = get_tracking_info(tracking_number)
    return info


# ==================== Demo & Evaluation Endpoints ====================

@app.post("/demo/seed")
def seed_demo_data(
    request: Request,
    count: int = Query(20, ge=1, le=100, description="Number of demo shipments to create"),
    actor: Optional[str] = Query("demo", description="Actor for demo operations"),
    db: Session = Depends(get_db)
):
    """
    Seed demo data for evaluation and demonstration.
    Creates shipments in various states with realistic transitions.
    """
    try:
        from app.services.demo_service import DemoService
        demo_service = DemoService(db)
        result = demo_service.seed_demo_data(count=count, actor=actor or "demo")
        return result
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error seeding demo data: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to seed demo data",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.post("/demo/reset")
def reset_demo_data(
    request: Request,
    keep_count: int = Query(0, ge=0, le=100, description="Number of shipments to keep (oldest)"),
    actor: Optional[str] = Query("demo", description="Actor for demo operations"),
    db: Session = Depends(get_db)
):
    """
    Reset demo data while optionally keeping some shipments.
    Safe operation for evaluation and demonstration.
    """
    try:
        from app.services.demo_service import DemoService
        demo_service = DemoService(db)
        result = demo_service.reset_demo_data(keep_count=keep_count, actor=actor or "demo")
        return result
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error resetting demo data: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to reset demo data",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.post("/demo/scenarios")
def create_demo_scenarios(
    request: Request,
    actor: Optional[str] = Query("demo", description="Actor for demo operations"),
    db: Session = Depends(get_db)
):
    """
    Create predefined success and failure scenarios for evaluation.
    Creates shipments demonstrating: success path, exception recovery, cancellation.
    """
    try:
        from app.services.demo_service import DemoService
        demo_service = DemoService(db)
        result = demo_service.create_demo_scenarios(actor=actor or "demo")
        return result
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error creating demo scenarios: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to create demo scenarios",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/health")
def health_check(db: Session = Depends(get_db)):
    """Health check endpoint with database connectivity test"""
    try:
        from sqlalchemy import text
        db.execute(text("SELECT 1"))
        return {
            "status": "healthy",
            "database": "connected",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "database": "disconnected",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )


@app.get("/health/indicators")
def get_health_indicators_endpoint(db: Session = Depends(get_db)):
    """
    Get health indicators based on predictive observability.
    Returns metrics about system health without modifying state.
    """
    try:
        indicators = get_health_indicators(db)
        return indicators
    except Exception as e:
        logger.error(f"Error getting health indicators: {str(e)}", exc_info=True)
        return {
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }


@app.get("/operations/summary")
def get_operations_summary(request: Request, db: Session = Depends(get_db)):
    """
    Get operational state summary - read-only query.
    Returns count of shipments per state using single GROUP BY query.
    Performs no writes, no caching.
    """
    try:
        # Single GROUP BY query - read-only
        result = db.query(
            Shipment.current_state,
            func.count(Shipment.id).label('count')
        ).filter(
            Shipment.deleted_at.is_(None)  # Exclude soft-deleted
        ).group_by(Shipment.current_state).all()
        
        # Convert to dictionary format
        summary = {state.value: count for state, count in result}
        
        # Ensure all states are represented (even if count is 0)
        for state in ShipmentState:
            if state.value not in summary:
                summary[state.value] = 0
        
        return summary
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error getting operations summary: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to get operations summary",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/operations/blocked-actions")
def get_blocked_actions_metrics(request: Request):
    """
    Get blocked transition metrics - passive observability only.
    Returns counters for failed transition attempts.
    These counters never affect control flow - purely observational.
    """
    try:
        from app.observability.blocked_counter import get_blocked_counter
        counter = get_blocked_counter()
        metrics = counter.get_metrics()
        return metrics
    except Exception as e:
        request_id = get_request_id(request)
        logger.error(f"[{request_id}] Error getting blocked actions metrics: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": "INTERNAL_ERROR",
                "message": "Failed to get blocked actions metrics",
                "classification": "non-retryable",
                "request_id": request_id
            }
        )


@app.get("/ready")
def readiness_check(db: Session = Depends(get_db)):
    """Readiness check for Docker/Kubernetes orchestration"""
    try:
        from sqlalchemy import text, inspect
        
        # Check database connectivity
        db.execute(text("SELECT 1"))
        
        # Check if tables exist
        inspector = inspect(db.bind)
        required_tables = ['shipments', 'state_transitions']
        
        existing_tables = inspector.get_table_names()
        missing_tables = [t for t in required_tables if t not in existing_tables]
        
        if missing_tables:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "not_ready",
                    "reason": f"Missing tables: {missing_tables}",
                    "timestamp": datetime.utcnow().isoformat()
                }
            )
        
        return {
            "status": "ready",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )
