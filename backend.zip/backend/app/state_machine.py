"""
Enhanced State Machine with Versioning and Recovery Support.
Supports multiple versions of state logic running in parallel.
"""
from typing import Optional, Tuple, Dict, Set
from app.models import ShipmentState


class StateMachineVersion:
    """Represents a version of the state machine"""
    
    def __init__(self, version: str, transitions: Dict[ShipmentState, Set[ShipmentState]]):
        self.version = version
        self.transitions = transitions
        self.terminal_states = {ShipmentState.DELIVERED, ShipmentState.CANCELLED}
        self.exception_recovery_states = {
            ShipmentState.CREATED,
            ShipmentState.READY_FOR_PICKUP,
            ShipmentState.IN_TRANSIT
        }
    
    def is_valid_transition(self, from_state: ShipmentState, to_state: ShipmentState) -> Tuple[bool, Optional[str]]:
        """Check if transition is valid for this version"""
        if from_state == to_state:
            return False, f"Cannot transition from {from_state.value} to itself"
        
        # EXCEPTION state can be recovered from
        if from_state == ShipmentState.EXCEPTION:
            if to_state in self.exception_recovery_states:
                return True, None
            return False, f"Cannot recover from EXCEPTION to {to_state.value}"
        
        # Allow transitions TO EXCEPTION from any non-terminal state
        if to_state == ShipmentState.EXCEPTION:
            if from_state not in self.terminal_states:
                return True, None
            return False, f"Cannot transition to EXCEPTION from terminal state {from_state.value}"
        
        # Check normal transitions
        allowed_targets = self.transitions.get(from_state)
        if allowed_targets is None:
            return False, f"Unknown source state: {from_state.value}"
        
        if to_state not in allowed_targets:
            return False, f"Invalid transition from {from_state.value} to {to_state.value}. " \
                         f"Allowed transitions: {[s.value for s in allowed_targets]}"
        
        return True, None
    
    def get_next_possible_states(self, current_state: ShipmentState) -> list[ShipmentState]:
        """Get possible next states from current state"""
        if current_state == ShipmentState.EXCEPTION:
            return list(self.exception_recovery_states)
        return list(self.transitions.get(current_state, set()))


class StateMachine:
    """
    Versioned State Machine - supports multiple versions running in parallel.
    Defaults to version 1.0 for backward compatibility.
    """
    
    def __init__(self):
        self._versions: Dict[str, StateMachineVersion] = {}
        self._default_version = "1.0"
        self._initialize_default_version()
    
    def _initialize_default_version(self):
        """Initialize default state machine version (v1.0)"""
        v1_transitions = {
            ShipmentState.CREATED: {
                ShipmentState.READY_FOR_PICKUP,
                ShipmentState.CANCELLED,
                ShipmentState.EXCEPTION  # Can enter exception from any state
            },
            ShipmentState.READY_FOR_PICKUP: {
                ShipmentState.IN_TRANSIT,
                ShipmentState.CANCELLED,
                ShipmentState.EXCEPTION
            },
            ShipmentState.IN_TRANSIT: {
                ShipmentState.DELIVERED,
                ShipmentState.CANCELLED,
                ShipmentState.EXCEPTION
            },
            ShipmentState.EXCEPTION: {
                # Can recover to previous non-terminal states
                ShipmentState.CREATED,
                ShipmentState.READY_FOR_PICKUP,
                ShipmentState.IN_TRANSIT
            },
            ShipmentState.DELIVERED: set(),  # Terminal state
            ShipmentState.CANCELLED: set(),  # Terminal state
        }
        
        self._versions[self._default_version] = StateMachineVersion(
            self._default_version,
            v1_transitions
        )
    
    def get_version(self, version: str = None) -> StateMachineVersion:
        """Get state machine version (defaults to 1.0)"""
        version = version or self._default_version
        if version not in self._versions:
            # Fallback to default if version not found
            return self._versions[self._default_version]
        return self._versions[version]
    
    def is_valid_transition(
        self,
        from_state: ShipmentState,
        to_state: ShipmentState,
        version: Optional[str] = None
    ) -> Tuple[bool, Optional[str]]:
        """Check if transition is valid for the given version"""
        state_machine_version = self.get_version(version)
        return state_machine_version.is_valid_transition(from_state, to_state)
    
    def get_next_possible_states(
        self,
        current_state: ShipmentState,
        version: Optional[str] = None
    ) -> list[ShipmentState]:
        """Get possible next states for the given version"""
        state_machine_version = self.get_version(version)
        return state_machine_version.get_next_possible_states(current_state)
    
    def can_modify_shipment(
        self,
        current_state: ShipmentState,
        allow_notes_update: bool = False
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if a shipment can be modified (not in terminal state).
        EXCEPTION state allows modifications for recovery.
        """
        terminal_states = {ShipmentState.DELIVERED, ShipmentState.CANCELLED}
        
        if current_state in terminal_states and not allow_notes_update:
            return False, f"Cannot modify shipment in terminal state: {current_state.value}. Notes can be updated."
        
        # EXCEPTION state allows modifications for recovery
        return True, None
    
    def register_version(self, version: str, transitions: Dict[ShipmentState, Set[ShipmentState]]) -> None:
        """Register a new state machine version (for future migrations)"""
        self._versions[version] = StateMachineVersion(version, transitions)


# Global state machine instance
_state_machine = None


def get_state_machine() -> StateMachine:
    """Get the global state machine instance"""
    global _state_machine
    if _state_machine is None:
        _state_machine = StateMachine()
    return _state_machine


# Backward compatibility functions
def is_valid_transition(from_state: ShipmentState, to_state: ShipmentState) -> Tuple[bool, Optional[str]]:
    """Backward compatible function for existing code"""
    return get_state_machine().is_valid_transition(from_state, to_state)


def can_modify_shipment(current_state: ShipmentState, allow_notes_update: bool = False) -> Tuple[bool, Optional[str]]:
    """Backward compatible function for existing code"""
    return get_state_machine().can_modify_shipment(current_state, allow_notes_update)


def get_next_possible_states(current_state: ShipmentState) -> list[ShipmentState]:
    """Backward compatible function for existing code"""
    return get_state_machine().get_next_possible_states(current_state)


# Valid state transitions for backward compatibility
VALID_TRANSITIONS = {
    ShipmentState.CREATED: {
        ShipmentState.READY_FOR_PICKUP,
        ShipmentState.CANCELLED,
        ShipmentState.EXCEPTION
    },
    ShipmentState.READY_FOR_PICKUP: {
        ShipmentState.IN_TRANSIT,
        ShipmentState.CANCELLED,
        ShipmentState.EXCEPTION
    },
    ShipmentState.IN_TRANSIT: {
        ShipmentState.DELIVERED,
        ShipmentState.CANCELLED,
        ShipmentState.EXCEPTION
    },
    ShipmentState.EXCEPTION: {
        ShipmentState.CREATED,
        ShipmentState.READY_FOR_PICKUP,
        ShipmentState.IN_TRANSIT
    },
    ShipmentState.DELIVERED: set(),
    ShipmentState.CANCELLED: set(),
}
