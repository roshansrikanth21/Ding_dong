import whisper
import sys
import json

# Load model ONCE
model = whisper.load_model(
    "base",
    download_root="C:/Users/rosha/.cache/whisper"
)

audio_path = sys.argv[1]

try:
    result = model.transcribe(audio_path, language="en")
    text = result.get("text", "").strip()
    
    # Filter out very short or non-meaningful results
    if len(text) < 3:
        print(json.dumps({"text": ""}))
    else:
        print(json.dumps({"text": text}))
        
except Exception as e:
    print(json.dumps({"text": "", "error": str(e)}), file=sys.stderr)
    sys.exit(1)
