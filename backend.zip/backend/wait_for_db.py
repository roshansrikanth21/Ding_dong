#!/usr/bin/env python3
"""
Wait for PostgreSQL database to be ready before starting the application.
"""
import os
import sys
import time
from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError

def wait_for_database():
    """Wait for database to be ready with retries"""
    db_url = os.getenv("DATABASE_URL", "postgresql://stateguard:stateguard@db:5432/stateguard")
    max_retries = 30
    retry_count = 0
    
    print("Waiting for database to be ready...")
    
    while retry_count < max_retries:
        try:
            engine = create_engine(
                db_url,
                pool_pre_ping=True,
                connect_args={"connect_timeout": 5}
            )
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            print("Database connection successful!")
            return True
        except OperationalError as e:
            retry_count += 1
            if retry_count >= max_retries:
                print(f"Failed to connect to database after {max_retries} attempts")
                print(f"Error: {e}")
                return False
            print(f"Database not ready (attempt {retry_count}/{max_retries}), waiting 2 seconds...")
            time.sleep(2)
    
    return False

if __name__ == "__main__":
    if not wait_for_database():
        sys.exit(1)
