"""
Integration tests for API endpoints.
Tests state transitions, validation, and error handling.
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import get_db
from app.main import app
from app.models import Base, ShipmentState

# Use in-memory SQLite for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="function")
def db_session():
    """Create a fresh database for each test"""
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="function")
def client(db_session):
    """Create test client with database override"""
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    yield TestClient(app)
    app.dependency_overrides.clear()


class TestShipmentCreation:
    """Test shipment creation endpoint"""

    def test_create_shipment(self, client):
        response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        assert response.status_code == 201
        data = response.json()
        assert data["tracking_number"] == "TRACK001"
        assert data["current_state"] == "CREATED"

    def test_create_duplicate_tracking_number(self, client):
        client.post("/shipments", json={"tracking_number": "TRACK001"})
        response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        assert response.status_code == 400


class TestStateTransitions:
    """Test state transition endpoint"""

    def test_valid_transition_created_to_ready(self, client):
        # Create shipment
        create_response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        shipment_id = create_response.json()["id"]

        # Transition
        response = client.post(
            f"/shipments/{shipment_id}/transition",
            json={"target_state": "READY_FOR_PICKUP"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["to_state"] == "READY_FOR_PICKUP"

    def test_invalid_transition_created_to_delivered(self, client):
        # Create shipment
        create_response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        shipment_id = create_response.json()["id"]

        # Try invalid transition
        response = client.post(
            f"/shipments/{shipment_id}/transition",
            json={"target_state": "DELIVERED"}
        )
        assert response.status_code == 400
        assert "Invalid transition" in response.json()["detail"]

    def test_cannot_transition_from_delivered(self, client):
        # Create and transition to delivered
        create_response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        shipment_id = create_response.json()["id"]

        # Transition through states
        client.post(f"/shipments/{shipment_id}/transition", json={"target_state": "READY_FOR_PICKUP"})
        client.post(f"/shipments/{shipment_id}/transition", json={"target_state": "IN_TRANSIT"})
        client.post(f"/shipments/{shipment_id}/transition", json={"target_state": "DELIVERED"})

        # Try to transition from delivered
        response = client.post(
            f"/shipments/{shipment_id}/transition",
            json={"target_state": "CREATED"}
        )
        assert response.status_code == 400

    def test_cannot_transition_from_cancelled(self, client):
        # Create and cancel
        create_response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        shipment_id = create_response.json()["id"]

        client.post(f"/shipments/{shipment_id}/transition", json={"target_state": "CANCELLED"})

        # Try to transition from cancelled
        response = client.post(
            f"/shipments/{shipment_id}/transition",
            json={"target_state": "READY_FOR_PICKUP"}
        )
        assert response.status_code == 400

    def test_complete_workflow(self, client):
        """Test complete valid workflow"""
        # Create
        create_response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        shipment_id = create_response.json()["id"]
        assert create_response.json()["current_state"] == "CREATED"

        # Ready for pickup
        response = client.post(
            f"/shipments/{shipment_id}/transition",
            json={"target_state": "READY_FOR_PICKUP"}
        )
        assert response.status_code == 200

        # In transit
        response = client.post(
            f"/shipments/{shipment_id}/transition",
            json={"target_state": "IN_TRANSIT"}
        )
        assert response.status_code == 200

        # Delivered
        response = client.post(
            f"/shipments/{shipment_id}/transition",
            json={"target_state": "DELIVERED"}
        )
        assert response.status_code == 200

        # Verify final state
        get_response = client.get(f"/shipments/{shipment_id}")
        assert get_response.json()["current_state"] == "DELIVERED"


class TestShipmentListing:
    """Test shipment listing endpoints"""

    def test_list_shipments(self, client):
        # Create some shipments
        client.post("/shipments", json={"tracking_number": "TRACK001"})
        client.post("/shipments", json={"tracking_number": "TRACK002"})

        response = client.get("/shipments")
        assert response.status_code == 200
        data = response.json()
        assert len(data["shipments"]) == 2
        assert data["total"] == 2

    def test_list_shipments_with_pagination(self, client):
        # Create multiple shipments
        for i in range(15):
            client.post("/shipments", json={"tracking_number": f"TRACK{i:03d}"})

        response = client.get("/shipments?page=1&limit=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data["shipments"]) == 10
        assert data["total"] == 15

    def test_list_shipments_with_status_filter(self, client):
        # Create shipments
        create_response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        shipment_id = create_response.json()["id"]
        client.post("/shipments", json={"tracking_number": "TRACK002"})

        # Transition one
        client.post(f"/shipments/{shipment_id}/transition", json={"target_state": "READY_FOR_PICKUP"})

        # Filter by status
        response = client.get("/shipments?status=READY_FOR_PICKUP")
        assert response.status_code == 200
        data = response.json()
        assert len(data["shipments"]) == 1
        assert data["shipments"][0]["current_state"] == "READY_FOR_PICKUP"


class TestTimeline:
    """Test timeline endpoint"""

    def test_get_timeline(self, client):
        # Create and transition
        create_response = client.post("/shipments", json={"tracking_number": "TRACK001"})
        shipment_id = create_response.json()["id"]

        client.post(f"/shipments/{shipment_id}/transition", json={"target_state": "READY_FOR_PICKUP"})
        client.post(f"/shipments/{shipment_id}/transition", json={"target_state": "IN_TRANSIT"})

        # Get timeline
        response = client.get(f"/shipments/{shipment_id}/timeline")
        assert response.status_code == 200
        timeline = response.json()
        assert len(timeline) == 3  # CREATED, READY_FOR_PICKUP, IN_TRANSIT
        assert timeline[0]["to_state"] == "CREATED"
        assert timeline[1]["to_state"] == "READY_FOR_PICKUP"
        assert timeline[2]["to_state"] == "IN_TRANSIT"

