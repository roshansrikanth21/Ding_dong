"""
Unit tests for state machine logic - prevents logic bugs.
Tests all valid and invalid transitions.
"""
import pytest
from app.models import ShipmentState
from app.state_machine import (
    is_valid_transition,
    can_modify_shipment,
    get_next_possible_states,
)


class TestStateTransitions:
    """Test valid state transitions"""

    def test_created_to_ready_for_pickup(self):
        is_valid, error = is_valid_transition(
            ShipmentState.CREATED, ShipmentState.READY_FOR_PICKUP
        )
        assert is_valid is True
        assert error is None

    def test_created_to_cancelled(self):
        is_valid, error = is_valid_transition(
            ShipmentState.CREATED, ShipmentState.CANCELLED
        )
        assert is_valid is True
        assert error is None

    def test_ready_for_pickup_to_in_transit(self):
        is_valid, error = is_valid_transition(
            ShipmentState.READY_FOR_PICKUP, ShipmentState.IN_TRANSIT
        )
        assert is_valid is True
        assert error is None

    def test_ready_for_pickup_to_cancelled(self):
        is_valid, error = is_valid_transition(
            ShipmentState.READY_FOR_PICKUP, ShipmentState.CANCELLED
        )
        assert is_valid is True
        assert error is None

    def test_in_transit_to_delivered(self):
        is_valid, error = is_valid_transition(
            ShipmentState.IN_TRANSIT, ShipmentState.DELIVERED
        )
        assert is_valid is True
        assert error is None


class TestInvalidTransitions:
    """Test invalid state transitions - these should be rejected"""

    def test_created_to_delivered(self):
        """Cannot skip states"""
        is_valid, error = is_valid_transition(
            ShipmentState.CREATED, ShipmentState.DELIVERED
        )
        assert is_valid is False
        assert error is not None

    def test_created_to_in_transit(self):
        """Cannot skip READY_FOR_PICKUP"""
        is_valid, error = is_valid_transition(
            ShipmentState.CREATED, ShipmentState.IN_TRANSIT
        )
        assert is_valid is False
        assert error is not None

    def test_delivered_to_any_state(self):
        """DELIVERED is terminal"""
        is_valid, error = is_valid_transition(
            ShipmentState.DELIVERED, ShipmentState.CREATED
        )
        assert is_valid is False
        assert error is not None

    def test_cancelled_to_any_state(self):
        """CANCELLED is terminal"""
        is_valid, error = is_valid_transition(
            ShipmentState.CANCELLED, ShipmentState.READY_FOR_PICKUP
        )
        assert is_valid is False
        assert error is not None

    def test_in_transit_to_cancelled(self):
        """Cannot cancel once in transit"""
        is_valid, error = is_valid_transition(
            ShipmentState.IN_TRANSIT, ShipmentState.CANCELLED
        )
        assert is_valid is False
        assert error is not None

    def test_same_state_transition(self):
        """Cannot transition to the same state"""
        is_valid, error = is_valid_transition(
            ShipmentState.CREATED, ShipmentState.CREATED
        )
        assert is_valid is False
        assert error is not None


class TestModificationRules:
    """Test if shipments can be modified"""

    def test_can_modify_created(self):
        can_modify, error = can_modify_shipment(ShipmentState.CREATED)
        assert can_modify is True
        assert error is None

    def test_can_modify_ready_for_pickup(self):
        can_modify, error = can_modify_shipment(ShipmentState.READY_FOR_PICKUP)
        assert can_modify is True
        assert error is None

    def test_can_modify_in_transit(self):
        can_modify, error = can_modify_shipment(ShipmentState.IN_TRANSIT)
        assert can_modify is True
        assert error is None

    def test_cannot_modify_delivered(self):
        can_modify, error = can_modify_shipment(ShipmentState.DELIVERED)
        assert can_modify is False
        assert error is not None

    def test_cannot_modify_cancelled(self):
        can_modify, error = can_modify_shipment(ShipmentState.CANCELLED)
        assert can_modify is False
        assert error is not None


class TestNextStates:
    """Test getting next possible states"""

    def test_next_states_from_created(self):
        next_states = get_next_possible_states(ShipmentState.CREATED)
        assert ShipmentState.READY_FOR_PICKUP in next_states
        assert ShipmentState.CANCELLED in next_states
        assert len(next_states) == 2

    def test_next_states_from_ready_for_pickup(self):
        next_states = get_next_possible_states(ShipmentState.READY_FOR_PICKUP)
        assert ShipmentState.IN_TRANSIT in next_states
        assert ShipmentState.CANCELLED in next_states
        assert len(next_states) == 2

    def test_next_states_from_in_transit(self):
        next_states = get_next_possible_states(ShipmentState.IN_TRANSIT)
        assert ShipmentState.DELIVERED in next_states
        assert len(next_states) == 1

    def test_next_states_from_delivered(self):
        next_states = get_next_possible_states(ShipmentState.DELIVERED)
        assert len(next_states) == 0

    def test_next_states_from_cancelled(self):
        next_states = get_next_possible_states(ShipmentState.CANCELLED)
        assert len(next_states) == 0

