"""
Security tests - XSS prevention and input validation
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import get_db
from app.main import app
from app.models import Base

# Use in-memory SQLite for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_security.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="function")
def db_session():
    """Create a fresh database for each test"""
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="function")
def client(db_session):
    """Create test client with database override"""
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    yield TestClient(app)
    app.dependency_overrides.clear()


class TestXSSPrevention:
    """Test XSS attack prevention"""

    def test_script_tag_injection_blocked(self, client):
        """Test that <script> tags are blocked"""
        response = client.post(
            "/shipments",
            json={"tracking_number": "<script>alert('XSS')</script>"}
        )
        assert response.status_code == 422  # Validation error

    def test_javascript_protocol_blocked(self, client):
        """Test that javascript: protocol is blocked"""
        response = client.post(
            "/shipments",
            json={"tracking_number": "javascript:alert('XSS')"}
        )
        assert response.status_code == 422  # Validation error

    def test_event_handler_blocked(self, client):
        """Test that event handlers are blocked"""
        response = client.post(
            "/shipments",
            json={"tracking_number": "TRACK001<img src=x onerror=alert('XSS')>"}
        )
        assert response.status_code == 422  # Validation error

    def test_data_protocol_blocked(self, client):
        """Test that data: protocol is blocked"""
        response = client.post(
            "/shipments",
            json={"tracking_number": "data:text/html,<script>alert('XSS')</script>"}
        )
        assert response.status_code == 422  # Validation error

    def test_html_tags_sanitized(self, client):
        """Test that HTML tags are sanitized from valid input"""
        # Create a shipment with HTML in tracking number
        response = client.post(
            "/shipments",
            json={"tracking_number": "TRACK<script>001</script>"}
        )
        # Should sanitize and create
        if response.status_code == 201:
            data = response.json()
            # Tracking number should not contain script tags
            assert "<script>" not in data["tracking_number"].lower()
            assert "</script>" not in data["tracking_number"].lower()

    def test_valid_tracking_number_accepted(self, client):
        """Test that valid tracking numbers are accepted"""
        response = client.post(
            "/shipments",
            json={"tracking_number": "TRACK-001.ABC"}
        )
        assert response.status_code == 201
        data = response.json()
        assert data["tracking_number"] == "TRACK-001.ABC"


class TestInputValidation:
    """Test input validation rules"""

    def test_empty_tracking_number_rejected(self, client):
        """Test that empty tracking number is rejected"""
        response = client.post(
            "/shipments",
            json={"tracking_number": ""}
        )
        assert response.status_code == 422

    def test_whitespace_only_rejected(self, client):
        """Test that whitespace-only tracking number is rejected"""
        response = client.post(
            "/shipments",
            json={"tracking_number": "   "}
        )
        assert response.status_code == 422

    def test_max_length_enforced(self, client):
        """Test that max length (100 chars) is enforced"""
        long_tracking = "A" * 101
        response = client.post(
            "/shipments",
            json={"tracking_number": long_tracking}
        )
        assert response.status_code == 422

    def test_special_characters_sanitized(self, client):
        """Test that special characters are sanitized"""
        response = client.post(
            "/shipments",
            json={"tracking_number": "TRACK@#$%^&*()001"}
        )
        # Should sanitize to just alphanumeric
        if response.status_code == 201:
            data = response.json()
            # Should only contain safe characters
            assert all(c.isalnum() or c in [' ', '-', '_', '.'] for c in data["tracking_number"])


class TestSecurityHeaders:
    """Test security headers are present"""

    def test_csp_header_present(self, client):
        """Test that Content-Security-Policy header is present"""
        response = client.get("/health")
        assert "Content-Security-Policy" in response.headers

    def test_x_content_type_options_header(self, client):
        """Test that X-Content-Type-Options header is present"""
        response = client.get("/health")
        assert "X-Content-Type-Options" in response.headers
        assert response.headers["X-Content-Type-Options"] == "nosniff"

    def test_x_frame_options_header(self, client):
        """Test that X-Frame-Options header is present"""
        response = client.get("/health")
        assert "X-Frame-Options" in response.headers
        assert response.headers["X-Frame-Options"] == "DENY"

    def test_x_xss_protection_header(self, client):
        """Test that X-XSS-Protection header is present"""
        response = client.get("/health")
        assert "X-XSS-Protection" in response.headers

