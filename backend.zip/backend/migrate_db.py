"""
Standalone database migration script.
Run this if you get column errors: python migrate_db.py
"""
import sys
import os

# Add the app directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import engine, SessionLocal
from sqlalchemy import text, inspect


def migrate_database():
    """Add new columns to existing database if they don't exist"""
    db = SessionLocal()
    try:
        # Check database type
        is_postgres = 'postgresql' in str(engine.url)
        is_sqlite = 'sqlite' in str(engine.url)
        
        print(f"Detected database: {'PostgreSQL' if is_postgres else 'SQLite' if is_sqlite else 'Unknown'}")
        print("Running migrations...\n")
        
        if is_postgres:
            # PostgreSQL migration
            columns_to_add = {
                'carrier': 'VARCHAR',
                'notes': 'VARCHAR',
                'deleted_at': 'TIMESTAMP'
            }
            
            for column_name, column_type in columns_to_add.items():
                try:
                    result = db.execute(text(f"""
                        SELECT column_name 
                        FROM information_schema.columns 
                        WHERE table_name='shipments' AND column_name='{column_name}'
                    """))
                    
                    if result.fetchone() is None:
                        print(f"Adding {column_name} column...")
                        db.execute(text(f"ALTER TABLE shipments ADD COLUMN {column_name} {column_type}"))
                        db.commit()
                        print(f"✓ Added {column_name} column")
                    else:
                        print(f"✓ {column_name} column already exists")
                except Exception as e:
                    print(f"⚠ Error checking/adding {column_name}: {e}")
                    db.rollback()
            
            # Create indexes
            try:
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_carrier ON shipments(carrier)"))
                db.execute(text("CREATE INDEX IF NOT EXISTS ix_shipments_deleted_at ON shipments(deleted_at)"))
                db.commit()
                print("✓ Indexes created/verified")
            except Exception as e:
                print(f"Note: Index creation: {e}")
        
        elif is_sqlite:
            # SQLite doesn't support ALTER TABLE ADD COLUMN easily
            # For SQLite, we'll recreate the table (data loss warning)
            print("⚠ SQLite detected. For SQLite, the easiest solution is to:")
            print("   1. Delete the database file (stateguard.db)")
            print("   2. Restart the application")
            print("   OR run: rm stateguard.db (Linux/Mac) or del stateguard.db (Windows)")
            print("\nIf you want to preserve data, you'll need to manually migrate.")
            return
        
        print("\n✅ Database migration completed successfully!")
        
    except Exception as e:
        print(f"❌ Migration error: {e}")
        import traceback
        traceback.print_exc()
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    migrate_database()

