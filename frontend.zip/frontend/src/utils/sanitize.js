/**
 * Security utilities for sanitizing user input and preventing XSS attacks
 */

/**
 * Escapes HTML special characters to prevent XSS
 * @param {string} str - String to escape
 * @returns {string} - Escaped string safe for HTML rendering
 */
export function escapeHtml(str) {
  if (typeof str !== 'string') {
    return String(str)
  }
  
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
  }
  
  return str.replace(/[&<>"'/]/g, (char) => map[char])
}

/**
 * Validates and sanitizes tracking number input
 * @param {string} input - User input
 * @returns {string} - Sanitized tracking number
 */
export function sanitizeTrackingNumber(input) {
  if (!input || typeof input !== 'string') {
    return ''
  }
  
  // Remove HTML tags and dangerous characters
  let sanitized = input
    .replace(/<[^>]*>/g, '') // Remove HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+\s*=/gi, '') // Remove event handlers
    .replace(/data:/gi, '') // Remove data: protocol
    .trim()
  
  // Only allow alphanumeric, spaces, hyphens, underscores, and dots
  sanitized = sanitized.replace(/[^\w\s\-\.]/g, '')
  
  return sanitized
}

/**
 * Validates tracking number format
 * @param {string} input - User input
 * @returns {boolean} - True if valid
 */
export function isValidTrackingNumber(input) {
  if (!input || typeof input !== 'string') {
    return false
  }
  
  const trimmed = input.trim()
  
  // Check length
  if (trimmed.length === 0 || trimmed.length > 100) {
    return false
  }
  
  // Check for dangerous patterns
  const dangerousPatterns = [
    /<script/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /data:/gi,
    /vbscript:/gi,
  ]
  
  for (const pattern of dangerousPatterns) {
    if (pattern.test(trimmed)) {
      return false
    }
  }
  
  return true
}

