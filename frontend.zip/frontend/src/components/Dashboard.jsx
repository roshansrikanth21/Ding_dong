import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { getStatistics, getOperationsSummary, getBlockedActions } from '../api'

const STATE_COLORS = {
  CREATED: 'bg-slate-100 text-slate-700 border-slate-300',
  READY_FOR_PICKUP: 'bg-amber-100 text-amber-800 border-amber-300',
  IN_TRANSIT: 'bg-blue-100 text-blue-800 border-blue-300',
  DELIVERED: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  CANCELLED: 'bg-rose-100 text-rose-800 border-rose-300',
  EXCEPTION: 'bg-orange-100 text-orange-800 border-orange-300',
}

function Dashboard() {
  const [stats, setStats] = useState(null)
  const [operationsSummary, setOperationsSummary] = useState(null)
  const [blockedActions, setBlockedActions] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    loadStatistics()
    loadOperationsData()
  }, [])

  const loadStatistics = async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await getStatistics(30)
      if (data.error) {
        setError(data.error)
      } else {
        setStats(data)
      }
    } catch (err) {
      console.error('Statistics error:', err)
      setError(err.response?.data?.detail || err.message || 'Failed to load statistics')
    } finally {
      setLoading(false)
    }
  }

  const loadOperationsData = async () => {
    try {
      const [summary, blocked] = await Promise.all([
        getOperationsSummary(),
        getBlockedActions()
      ])
      setOperationsSummary(summary)
      setBlockedActions(blocked)
    } catch (err) {
      console.error('Operations data error:', err)
      // Non-critical, don't show error
    }
  }

  const formatTime = (seconds) => {
    if (!seconds) return 'N/A'
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    if (days > 0) return `${days}d ${hours}h`
    return `${hours}h`
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  if (error && !stats) {
    return (
      <div className="card p-6 bg-rose-50 border-rose-200">
        <div className="flex items-center mb-2">
          <svg className="w-5 h-5 text-rose-600 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
          </svg>
          <span className="text-rose-800 font-medium">{error}</span>
        </div>
        <button
          onClick={loadStatistics}
          className="mt-4 btn-secondary"
        >
          Retry
        </button>
      </div>
    )
  }

  if (!stats) return null

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Shipments</p>
              <p className="text-3xl font-bold text-gray-900">{stats.total_shipments.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
              </svg>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Recent Shipments</p>
              <p className="text-3xl font-bold text-gray-900">{(stats.recent_shipments || 0).toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-1">Last {stats.period_days} days</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">In Transit</p>
              <p className="text-3xl font-bold text-gray-900">
                {((stats.state_distribution && stats.state_distribution.IN_TRANSIT) || 0).toLocaleString()}
              </p>
            </div>
            <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Delivered</p>
              <p className="text-3xl font-bold text-gray-900">
                {((stats.state_distribution && stats.state_distribution.DELIVERED) || 0).toLocaleString()}
              </p>
            </div>
            <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* State Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Status Distribution</h3>
          <div className="space-y-3">
            {Object.keys(stats.state_distribution || {}).length === 0 ? (
              <p className="text-gray-500 text-sm">No shipments yet</p>
            ) : (
              Object.entries(stats.state_distribution || {}).map(([state, count]) => (
              <div key={state} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 text-xs font-semibold rounded-lg border ${STATE_COLORS[state] || 'bg-gray-100 text-gray-700 border-gray-300'}`}>
                    {state.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="flex items-center space-x-4 flex-1 mx-4">
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-indigo-600 h-2 rounded-full"
                      style={{ width: `${(count / stats.total_shipments) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-12 text-right">
                    {count.toLocaleString()}
                  </span>
                </div>
              </div>
              ))
            )}
          </div>
        </div>

        {/* Carrier Distribution */}
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Carrier Distribution</h3>
          {Object.keys(stats.carrier_distribution || {}).length === 0 ? (
            <p className="text-gray-500 text-sm">No carrier data available</p>
          ) : (
            <div className="space-y-3">
              {Object.entries(stats.carrier_distribution || {})
                .sort(([, a], [, b]) => b - a)
                .map(([carrier, count]) => (
                  <div key={carrier} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">{carrier.replace(/_/g, ' ')}</span>
                    <div className="flex items-center space-x-4 flex-1 mx-4">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-purple-600 h-2 rounded-full"
                          style={{ width: `${(count / stats.total_shipments) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium text-gray-900 w-12 text-right">
                        {count.toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>

      {/* Operations Summary - Read-Only State Counts */}
      {operationsSummary && (
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Operational State Summary</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {Object.entries(operationsSummary).map(([state, count]) => (
              <div key={state} className="text-center p-3 bg-gray-50 rounded-lg">
                <p className="text-2xl font-bold text-gray-900">{count}</p>
                <p className="text-xs text-gray-600 mt-1">{state.replace(/_/g, ' ')}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Blocked Actions Metrics */}
      {blockedActions && blockedActions.total_blocked > 0 && (
        <div className="card p-6 bg-amber-50 border-amber-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Blocked Transition Attempts</h3>
          <p className="text-sm text-gray-700 mb-3">
            Total blocked: <span className="font-bold">{blockedActions.total_blocked}</span>
          </p>
          {Object.keys(blockedActions.violations || {}).length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-gray-600 uppercase">Common Violations:</p>
              {Object.entries(blockedActions.violations)
                .sort(([, a], [, b]) => b - a)
                .slice(0, 5)
                .map(([transition, count]) => (
                  <div key={transition} className="flex justify-between text-sm">
                    <span className="text-gray-700">{transition}</span>
                    <span className="font-medium text-gray-900">{count}</span>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* Additional Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6">
          <p className="text-sm text-gray-600 mb-2">Recent Transitions</p>
          <p className="text-2xl font-bold text-gray-900">{(stats.recent_transitions || 0).toLocaleString()}</p>
          <p className="text-xs text-gray-500 mt-1">Last {stats.period_days} days</p>
        </div>
        <div className="card p-6">
          <p className="text-sm text-gray-600 mb-2">Avg Delivery Time</p>
          <p className="text-2xl font-bold text-gray-900">
            {formatTime(stats.average_delivery_time_seconds)}
          </p>
        </div>
        <div className="card p-6">
          <Link to="/shipments" className="btn-primary w-full text-center block">
            View All Shipments
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Dashboard

