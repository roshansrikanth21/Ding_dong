import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { getAgingInsights } from '../api'

function pct(part, total) {
  if (!total) return 0
  return Math.max(0, Math.min(100, (part / total) * 100))
}

export default function Insights() {
  const [staleDays, setStaleDays] = useState(7)
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = async () => {
    try {
      setLoading(true)
      setError(null)
      const res = await getAgingInsights({ staleThresholdDays: staleDays, limitStale: 25 })
      setData(res)
    } catch (e) {
      setError(e.response?.data?.detail || e.message || 'Failed to load insights')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [staleDays])

  const activeTotal = data?.active_total || 0
  const buckets = data?.buckets || []
  const stale = data?.stale_shipments || []

  const maxBucket = useMemo(() => Math.max(1, ...buckets.map((b) => b.count || 0)), [buckets])

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm text-slate-500">Operations</div>
          <h1 className="text-2xl font-semibold tracking-tight">Ops insights</h1>
          <p className="mt-1 text-sm text-slate-600">
            Aging and stale shipments to help teams triage delays and keep throughput healthy.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-sm text-slate-600">Stale threshold</label>
          <select className="input" value={staleDays} onChange={(e) => setStaleDays(Number(e.target.value))}>
            <option value={3}>3 days</option>
            <option value={7}>7 days</option>
            <option value={14}>14 days</option>
          </select>
          <button className="btn btn-secondary" onClick={load}>
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="panel border-rose-200 bg-rose-50 text-rose-800">
          <div className="text-sm font-medium">{error}</div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="panel lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold">Aging distribution</div>
              <div className="text-xs text-slate-500">Active shipments: {activeTotal.toLocaleString()}</div>
            </div>
          </div>

          {loading ? (
            <div className="py-12 text-center text-sm text-slate-500">Loading…</div>
          ) : buckets.length === 0 ? (
            <div className="py-12 text-center text-sm text-slate-500">No active shipments.</div>
          ) : (
            <div className="mt-5 space-y-3">
              {buckets.map((b) => (
                <div key={b.label} className="flex items-center gap-3">
                  <div className="w-20 text-xs text-slate-600">{b.label}</div>
                  <div className="flex-1">
                    <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-2 bg-slate-900"
                        style={{ width: `${pct(b.count, maxBucket)}%` }}
                      />
                    </div>
                  </div>
                  <div className="w-12 text-right text-xs text-slate-700 tabular-nums">{b.count}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="panel">
          <div className="text-sm font-semibold">Stale queue</div>
          <div className="text-xs text-slate-500">Older than {staleDays} days</div>

          {loading ? (
            <div className="py-10 text-center text-sm text-slate-500">Loading…</div>
          ) : stale.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-500">No stale shipments.</div>
          ) : (
            <div className="mt-4 space-y-3">
              {stale.slice(0, 8).map((s) => (
                <Link
                  key={s.id}
                  to={`/shipments/${s.id}`}
                  className="block rounded-xl border border-slate-200 bg-white hover:bg-slate-50 p-3"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-sm font-medium text-slate-900">{s.tracking_number}</div>
                    <div className="text-xs text-slate-600 tabular-nums">{s.age_days}d</div>
                  </div>
                  <div className="mt-1 text-xs text-slate-500">
                    {s.current_state?.replace(/_/g, ' ')} • {s.carrier ? s.carrier.replace(/_/g, ' ') : 'Unknown carrier'}
                  </div>
                </Link>
              ))}
              <Link to="/shipments" className="text-sm font-medium text-slate-900 hover:underline">
                View in Shipments →
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}


