import React, { useState, useRef, useEffect } from 'react'
import axios from 'axios'

// Use environment variable or default to localhost (same as api.js)
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const AIAgent = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState([
    {
      type: "bot",
      text: "👋 Hi! I'm your EventGuard AI assistant! 🚀\n\nI can help you:\n• 📦 Track shipments by serial number\n• 📋 List all your shipments\n• 📊 Get shipment statistics\n• 🔍 Check system status\n\nJust ask me anything! Try saying \"help\" to see all commands.",
      timestamp: new Date()
    }
  ])
  const [inputText, setInputText] = useState('')
  const [isRecording, setIsRecording] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [conversationId, setConversationId] = useState(null)
  const [errorMessage, setErrorMessage] = useState(null)
  const [voiceSupported, setVoiceSupported] = useState(false)
  const [selectedShipments, setSelectedShipments] = useState(null) // For dropdown fallback
  
  const messagesEndRef = useRef(null)
  const recognitionRef = useRef(null)
  
  // Initialize speech recognition on mount and update handler when sendTextMessage changes
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (SpeechRecognition) {
      setVoiceSupported(true)
      if (!recognitionRef.current) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = false
        recognitionRef.current.interimResults = false
        recognitionRef.current.lang = 'en-US'
      }
      
      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript
        if (transcript && transcript.trim()) {
          // Use the SAME pipeline as text input
          sendTextMessage(transcript.trim())
        }
        setIsRecording(false)
      }
      
      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error)
        setIsRecording(false)
        // Silent failure - no chat messages
      }
      
      recognitionRef.current.onend = () => {
        setIsRecording(false)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  
  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])
  
  const API_BASE = `${API_BASE_URL}/ai`
  
  const addMessage = (type, text) => {
    setMessages(prev => [
      ...prev,
      {
        type: type,
        text: text,
        timestamp: new Date()
      }
    ])
  }
  
  // Lightweight text normalization for voice input
  const normalizeText = (text) => {
    if (!text) return text
    // Normalize: lowercase, trim, collapse spaces
    return text.toLowerCase().trim().replace(/\s+/g, ' ')
  }
  
  const sendTextMessage = async (textToSend = null) => {
    let messageToSend = textToSend || inputText.trim()
    // Normalize text (helps with voice recognition quirks)
    messageToSend = normalizeText(messageToSend)
    if (!messageToSend || isProcessing) return
    
    setInputText('')
    setErrorMessage(null) // Clear any previous errors
    addMessage('user', messageToSend)
    setIsProcessing(true)
    
    try {
      const response = await axios.post(`${API_BASE}/chat`, {
        message: messageToSend,
        conversation_id: conversationId
      })
      
      if (!conversationId) {
        setConversationId(response.data.conversation_id)
      }
      
      addMessage('bot', response.data.reply)
      
      // Handle actions
      if (response.data.action === 'show_shipment' && response.data.data) {
        // Could trigger navigation to shipment detail page
        console.log('Shipment data:', response.data.data)
      }
      
      // Handle dropdown for shipment selection
      if (response.data.action === 'show_dropdown' && response.data.data?.shipments) {
        // Store shipments for dropdown display
        setSelectedShipments(response.data.data.shipments)
      } else {
        setSelectedShipments(null)
      }
      
    } catch (error) {
      console.error('Chat error:', error)
      
      let errorMsg = '❌ '
      if (error.code === 'ECONNREFUSED' || error.message.includes('Network Error')) {
        errorMsg += `Cannot connect to server. Please check if the backend is running on ${API_BASE_URL}`
      } else if (error.response?.data?.detail) {
        errorMsg += error.response.data.detail
      } else {
        errorMsg += 'Sorry, something went wrong. Please try again.'
      }
      
      addMessage('bot', errorMsg)
    } finally {
      setIsProcessing(false)
    }
  }
  
  const startRecording = () => {
    if (!recognitionRef.current) {
      // Silent failure - focus text input instead
      document.querySelector('input[type="text"]')?.focus()
      return
    }
    
    try {
      recognitionRef.current.start()
      setIsRecording(true)
      setErrorMessage(null)
    } catch (error) {
      console.error('Speech recognition start error:', error)
      setIsRecording(false)
      // Silent failure - no chat messages
    }
  }
  
  const stopRecording = () => {
    if (recognitionRef.current && isRecording) {
      try {
        recognitionRef.current.stop()
        setIsRecording(false)
      } catch (error) {
        console.error('Error stopping speech recognition:', error)
        setIsRecording(false)
        // Silent failure - no error messages
      }
    }
  }
  
  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 group z-50"
        aria-label="Open AI Assistant"
      >
        {/* Glowing background effect with multiple layers */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full blur-2xl opacity-60 group-hover:opacity-90 transition-opacity animate-pulse"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-400 via-purple-400 to-blue-400 rounded-full blur-xl opacity-40 group-hover:opacity-70 transition-opacity"></div>
        
        {/* Main button container */}
        <div className="relative">
          {/* Animated outer ring */}
          <div className="absolute inset-0 rounded-full border-2 border-white/40 animate-ping"></div>
          <div className="absolute inset-0 rounded-full border border-white/30 animate-pulse"></div>
          
          {/* Main button with gradient */}
          <div className="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-600 text-white rounded-2xl shadow-2xl transition-all duration-300 group-hover:scale-110 group-hover:shadow-blue-500/60 group-active:scale-95 overflow-hidden">
            {/* Shimmer effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 group-hover:animate-shimmer"></div>
            
            {/* Content */}
            <div className="relative px-6 py-4 flex items-center gap-3">
              {/* Icon container */}
              <div className="relative">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center transform group-hover:rotate-12 transition-transform duration-300">
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                </div>
                
                {/* Sparkle effects */}
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-300 rounded-full animate-pulse shadow-lg"></div>
                <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-pink-300 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
                
                {/* Pulse indicator */}
                <div className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-green-400 rounded-full border-2 border-white animate-pulse shadow-lg"></div>
              </div>
              
              {/* Text */}
              <div className="flex flex-col">
                <span className="text-sm font-bold tracking-tight">AI Assistant</span>
                <span className="text-xs text-white/80 font-medium">Ask me anything!</span>
              </div>
              
              {/* Arrow icon */}
              <div className="ml-2 transform group-hover:translate-x-1 transition-transform">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>
          </div>
        </div>
        
        {/* Enhanced tooltip */}
        <div className="absolute bottom-full right-0 mb-3 px-4 py-2 bg-gradient-to-r from-gray-900 to-gray-800 text-white text-sm rounded-xl opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-2xl transform group-hover:translate-y-0 translate-y-2">
          <div className="flex items-center gap-2">
            <span className="text-lg">✨</span>
            <span className="font-semibold">Smart Shipping Assistant</span>
            <span className="text-lg">🚀</span>
          </div>
          <div className="absolute top-full right-6 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      </button>
    )
  }
  
  return (
    <div className="fixed bottom-6 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col z-50 border border-gray-200 animate-slideInRight">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white p-4 rounded-t-lg flex justify-between items-center shadow-lg">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse absolute -top-0.5 -right-0.5"></div>
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
          </div>
          <div>
            <h3 className="font-bold text-lg">EventGuard AI</h3>
            <p className="text-xs text-white/80">Always here to help</p>
          </div>
        </div>
        <button
          onClick={() => setIsOpen(false)}
          className="hover:bg-blue-800 rounded p-1 transition-colors"
          aria-label="Close"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-gray-50 to-white">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] p-4 rounded-2xl transition-all duration-200 ${
                msg.type === 'user'
                  ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-br-md shadow-lg'
                  : 'bg-white text-gray-800 rounded-bl-md shadow-md border border-gray-100'
              }`}
            >
              <div className="text-sm whitespace-pre-wrap leading-relaxed">{msg.text}</div>
              <div className={`text-xs mt-2 ${msg.type === 'user' ? 'text-blue-100' : 'text-gray-400'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        
        {isProcessing && (
          <div className="flex justify-start animate-fadeIn">
            <div className="bg-gradient-to-br from-white to-gray-50 text-gray-800 p-4 rounded-2xl rounded-bl-md shadow-md border border-gray-100">
              <div className="flex items-center space-x-2">
                <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-bounce"></div>
                <div className="w-2.5 h-2.5 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></div>
                <div className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></div>
                <span className="text-xs text-gray-500 ml-2">AI is thinking...</span>
              </div>
            </div>
          </div>
        )}
        
                    <div ref={messagesEndRef} />
                    
                    {/* Shipment Selection Dropdown */}
                    {selectedShipments && selectedShipments.length > 0 && (
                      <div className="mt-4 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl shadow-lg animate-fadeIn">
                        <div className="flex items-center gap-2 mb-3">
                          <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                          </svg>
                          <p className="text-sm font-semibold text-blue-900">Select a shipment to track:</p>
                        </div>
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {selectedShipments.map((shipment, idx) => (
                            <button
                              key={idx}
                              onClick={async () => {
                                setSelectedShipments(null)
                                const trackMsg = shipment.serial_number ? `track serial ${shipment.serial_number}` : `track ${shipment.tracking_number}`
                                await sendTextMessage(trackMsg)
                              }}
                              className="w-full text-left p-3 bg-white border-2 border-blue-200 rounded-lg hover:bg-blue-50 hover:border-blue-400 hover:shadow-md transition-all duration-200 group"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex-1">
                                  <div className="font-bold text-blue-900 group-hover:text-blue-700">
                                    {shipment.serial_number ? `Serial #${shipment.serial_number}` : shipment.tracking_number}
                                  </div>
                                  <div className="text-xs text-gray-600 mt-1 flex items-center gap-2">
                                    <span>{shipment.tracking_number}</span>
                                    <span>•</span>
                                    <span>{shipment.carrier || 'Unknown'}</span>
                                    <span>•</span>
                                    <span className="font-medium">{shipment.state}</span>
                                  </div>
                                </div>
                                <svg className="w-5 h-5 text-blue-400 group-hover:text-blue-600 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                              </div>
                            </button>
                          ))}
                        </div>
                        <button
                          onClick={() => setSelectedShipments(null)}
                          className="mt-3 text-xs text-blue-600 hover:text-blue-800 font-medium transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>
      
      {/* Input */}
      <div className="p-4 border-t border-gray-200 bg-white rounded-b-lg">
        {/* Error Message - Inline, non-blocking */}
        {errorMessage && (
          <div className="mb-3 p-3 bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-xl flex items-start gap-2 animate-fadeIn shadow-sm">
            <svg className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            <div className="flex-1">
              <p className="text-sm text-amber-800 font-medium">{errorMessage}</p>
              <button
                onClick={() => setErrorMessage(null)}
                className="mt-1 text-xs text-amber-700 hover:text-amber-900 font-medium underline transition-colors"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}
        
        <div className="flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => {
              setInputText(e.target.value)
              // Clear inline error when user types, but keep warning flag to prevent duplicate chat messages
              if (errorMessage) {
                setErrorMessage(null)
              }
            }}
            onKeyPress={(e) => e.key === 'Enter' && sendTextMessage()}
            placeholder={isRecording ? "🎙️ Recording..." : "Type your message..."}
            disabled={isProcessing || isRecording}
            className="flex-1 px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 transition-all duration-200"
          />
          
          {voiceSupported && (
            <button
              onClick={(e) => {
                e.preventDefault()
                try {
                  if (isRecording) {
                    stopRecording()
                  } else {
                    startRecording()
                  }
                } catch (error) {
                  console.error('Error with recording button:', error)
                  // Silent failure - focus text input instead
                  document.querySelector('input[type="text"]')?.focus()
                  setIsRecording(false)
                }
              }}
              disabled={isProcessing}
              className={`p-2 rounded-lg transition-colors ${
                isRecording
                  ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse'
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
              aria-label={isRecording ? 'Stop recording' : 'Start recording'}
              title="Click to record audio (optional)"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z" />
                <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
              </svg>
            </button>
          )}
          
          <button
            onClick={() => sendTextMessage()}
            disabled={!inputText.trim() || isProcessing || isRecording}
            className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-md hover:shadow-lg transform hover:scale-105 disabled:hover:scale-100"
            aria-label="Send message"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </button>
        </div>
        
        {isRecording && (
          <div className="mt-2 text-center text-sm text-red-600 font-medium animate-pulse flex items-center justify-center gap-2">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span>🎙️ Recording... Click mic to stop</span>
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
          </div>
        )}
      </div>
    </div>
  )
}

export default AIAgent
