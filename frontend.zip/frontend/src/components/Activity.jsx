import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getActivity } from '../api'

const STATE_BADGE = {
  CREATED: 'badge badge-slate',
  READY_FOR_PICKUP: 'badge badge-amber',
  IN_TRANSIT: 'badge badge-blue',
  DELIVERED: 'badge badge-emerald',
  CANCELLED: 'badge badge-rose',
}

function formatTs(ts) {
  try {
    return new Date(ts).toLocaleString()
  } catch {
    return String(ts)
  }
}

export default function Activity() {
  const [days, setDays] = useState(7)
  const [limit, setLimit] = useState(50)
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const load = async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await getActivity({ days, limit })
      setEvents(data || [])
    } catch (e) {
      setError(e.response?.data?.detail || e.message || 'Failed to load activity')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [days, limit])

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm text-slate-500">Operations</div>
          <h1 className="text-2xl font-semibold tracking-tight">Activity feed</h1>
          <p className="mt-1 text-sm text-slate-600">
            Recent state changes across shipments (audit trail for operators).
          </p>
        </div>
        <div className="flex items-center gap-3">
          <select className="input" value={days} onChange={(e) => setDays(Number(e.target.value))}>
            <option value={1}>Last 24h</option>
            <option value={7}>Last 7 days</option>
            <option value={30}>Last 30 days</option>
          </select>
          <select className="input" value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
            <option value={200}>200</option>
          </select>
          <button className="btn btn-secondary" onClick={load}>
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="panel border-rose-200 bg-rose-50 text-rose-800">
          <div className="text-sm font-medium">{error}</div>
        </div>
      )}

      <div className="panel p-0 overflow-hidden">
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Shipment</th>
                <th>Carrier</th>
                <th>Transition</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={4} className="py-10 text-center text-sm text-slate-500">
                    Loading activity…
                  </td>
                </tr>
              ) : events.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-10 text-center text-sm text-slate-500">
                    No activity found.
                  </td>
                </tr>
              ) : (
                events.map((ev) => (
                  <tr key={ev.id}>
                    <td className="whitespace-nowrap text-sm text-slate-600">{formatTs(ev.timestamp)}</td>
                    <td>
                      <Link to={`/shipments/${ev.shipment_id}`} className="text-sm font-medium text-slate-900 hover:underline">
                        {ev.tracking_number}
                      </Link>
                      <div className="text-xs text-slate-500">#{ev.shipment_id}</div>
                    </td>
                    <td className="text-sm text-slate-700">
                      {ev.carrier ? ev.carrier.replace(/_/g, ' ') : <span className="text-slate-400">—</span>}
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        {ev.from_state ? (
                          <span className={STATE_BADGE[ev.from_state] || 'badge badge-slate'}>
                            {ev.from_state.replace(/_/g, ' ')}
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400">—</span>
                        )}
                        <span className="text-slate-400">→</span>
                        <span className={STATE_BADGE[ev.to_state] || 'badge badge-slate'}>
                          {ev.to_state.replace(/_/g, ' ')}
                        </span>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}


