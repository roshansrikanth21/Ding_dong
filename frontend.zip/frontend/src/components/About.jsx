import { Link } from 'react-router-dom'

function About() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl mb-6 shadow-lg">
          <span className="text-4xl">📦</span>
        </div>
        <h1 className="text-5xl font-bold text-gray-900 mb-4 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          About EventGuard
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Revolutionizing logistics with intelligent shipment tracking, state machine integrity, and AI-powered assistance
        </p>
      </div>

      {/* Mission Section */}
      <div className="card p-8 mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
        <p className="text-lg text-gray-700 leading-relaxed mb-4">
          EventGuard was built to solve critical challenges in modern logistics systems. Traditional shipment tracking platforms suffer from data corruption, race conditions, and lack of transparency. We've engineered a solution that prevents these failures by design.
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          Our mission is to provide logistics teams with a <strong>reliable, auditable, and intelligent</strong> system that enforces correctness at every step, ensuring shipments move through their lifecycle with complete integrity and traceability.
        </p>
      </div>

      {/* What We Do Section */}
      <div className="mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">What We Do</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* State Machine Integrity */}
          <div className="card p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900">State Machine Integrity</h3>
            </div>
            <p className="text-gray-700">
              We enforce strict finite state machine rules that prevent invalid shipment transitions. Your shipments can only move through valid states (CREATED → READY_FOR_PICKUP → IN_TRANSIT → DELIVERED), eliminating data corruption and logical errors.
            </p>
          </div>

          {/* Complete Audit Trail */}
          <div className="card p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900">Complete Audit Trail</h3>
            </div>
            <p className="text-gray-700">
              Every state change is logged with timestamps, actors, and reasons. Our animated timeline visualization shows the complete journey of each shipment, making debugging and compliance effortless.
            </p>
          </div>

          {/* AI-Powered Assistant */}
          <div className="card p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900">AI-Powered Assistant</h3>
            </div>
            <p className="text-gray-700">
              Our intelligent chatbot understands natural language queries. Ask "track serial 1" or "list shipments in transit" using voice or text. The AI processes your intent and provides instant, accurate responses.
            </p>
          </div>

          {/* Inventory Management */}
          <div className="card p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900">Comprehensive Inventory Tracking</h3>
            </div>
            <p className="text-gray-700">
              Track origin, destination, product type, fragility status, storage waypoints, and delivery schedules. Our system captures the complete inventory context for each shipment, enabling better logistics planning.
            </p>
          </div>

          {/* Concurrency Control */}
          <div className="card p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900">Optimistic Locking</h3>
            </div>
            <p className="text-gray-700">
              Our system uses optimistic locking to prevent concurrent update conflicts. Multiple users can work simultaneously without data corruption or lost updates, ensuring consistency under high concurrency.
            </p>
          </div>

          {/* Exception Recovery */}
          <div className="card p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900">Exception Recovery</h3>
            </div>
            <p className="text-gray-700">
              When shipments enter exception states, our system provides clear recovery paths. You can transition back to valid states with full audit logging, ensuring no shipment is permanently stuck.
            </p>
          </div>
        </div>
      </div>

      {/* Technology Stack */}
      <div className="card p-8 mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Built with Modern Technology</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-3xl mb-2">⚛️</div>
            <h4 className="font-semibold text-gray-900">React 18</h4>
            <p className="text-sm text-gray-600">Modern UI Framework</p>
          </div>
          <div className="text-center">
            <div className="text-3xl mb-2">🐍</div>
            <h4 className="font-semibold text-gray-900">FastAPI</h4>
            <p className="text-sm text-gray-600">High-Performance API</p>
          </div>
          <div className="text-center">
            <div className="text-3xl mb-2">🐘</div>
            <h4 className="font-semibold text-gray-900">PostgreSQL</h4>
            <p className="text-sm text-gray-600">Enterprise Database</p>
          </div>
          <div className="text-center">
            <div className="text-3xl mb-2">🤖</div>
            <h4 className="font-semibold text-gray-900">AI Assistant</h4>
            <p className="text-sm text-gray-600">Voice & Text AI</p>
          </div>
        </div>
      </div>

      {/* Key Differentiators */}
      <div className="card p-8 mb-12 bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Why EventGuard Stands Out</h2>
        <div className="space-y-4">
          <div className="flex items-start">
            <div className="flex-shrink-0 w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center mt-1 mr-4">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-1">Prevents Errors by Design</h4>
              <p className="text-gray-700">Our state machine architecture makes invalid operations impossible, not just discouraged.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="flex-shrink-0 w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center mt-1 mr-4">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-1">Complete Transparency</h4>
              <p className="text-gray-700">Every action is logged and visualized. You can see exactly what happened, when, and why.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="flex-shrink-0 w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center mt-1 mr-4">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-1">Intelligent Assistance</h4>
              <p className="text-gray-700">Our AI assistant understands natural language, making shipment queries as easy as having a conversation.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="flex-shrink-0 w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center mt-1 mr-4">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 mb-1">Production-Ready Architecture</h4>
              <p className="text-gray-700">Built with Docker, Nginx rate limiting, connection pooling, and comprehensive error handling for enterprise deployment.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="text-center">
        <div className="card p-8 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Logistics?</h2>
          <p className="text-lg mb-6 text-indigo-100">
            Experience the power of state machine integrity, AI assistance, and complete transparency.
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              to="/shipments"
              className="px-6 py-3 bg-white text-indigo-600 rounded-lg font-semibold hover:bg-indigo-50 transition-colors shadow-lg"
            >
              View Shipments
            </Link>
            <Link
              to="/"
              className="px-6 py-3 bg-indigo-700 text-white rounded-lg font-semibold hover:bg-indigo-800 transition-colors border-2 border-white/20"
            >
              Go to Dashboard
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About
