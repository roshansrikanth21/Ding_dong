import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { getShipment, getShipmentTimeline } from '../api'
import { escapeHtml } from '../utils/sanitize'

const STATE_COLORS = {
  CREATED: 'bg-slate-100 text-slate-700 border-slate-300',
  READY_FOR_PICKUP: 'bg-amber-100 text-amber-800 border-amber-300',
  IN_TRANSIT: 'bg-blue-100 text-blue-800 border-blue-300',
  DELIVERED: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  CANCELLED: 'bg-rose-100 text-rose-800 border-rose-300',
  EXCEPTION: 'bg-orange-100 text-orange-800 border-orange-300',
}

function DebugView() {
  const { id } = useParams()
  const [shipment, setShipment] = useState(null)
  const [timeline, setTimeline] = useState([])
  const [loading, setLoading] = useState(true)
  const [validationErrors, setValidationErrors] = useState([])

  useEffect(() => {
    if (id) {
      loadData()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  const loadData = async () => {
    try {
      setLoading(true)
      const [shipmentData, timelineData] = await Promise.all([
        getShipment(id),
        getShipmentTimeline(id),
      ])
      setShipment(shipmentData)
      setTimeline(timelineData)
      validateStateSequence(shipmentData, timelineData)
    } catch (err) {
      console.error('Failed to load debug data:', err)
    } finally {
      setLoading(false)
    }
  }

  const validateStateSequence = (shipmentData, transitions) => {
    const errors = []
    
    if (transitions.length === 0) {
      setValidationErrors(['No transitions found'])
      return
    }

    // Check for duplicate consecutive transitions (same state twice in a row)
    for (let i = 1; i < transitions.length; i++) {
      if (transitions[i].to_state === transitions[i - 1].to_state) {
        errors.push(`Duplicate consecutive state: ${transitions[i].to_state} at transition #${transitions[i].id}`)
      }
    }

    // Check for valid transitions
    for (let i = 1; i < transitions.length; i++) {
      const prev = transitions[i - 1].to_state
      const curr = transitions[i].to_state
      
      // Validate transition
      const validTransitions = {
        CREATED: ['READY_FOR_PICKUP', 'CANCELLED'],
        READY_FOR_PICKUP: ['IN_TRANSIT', 'CANCELLED'],
        IN_TRANSIT: ['DELIVERED'],
        DELIVERED: [],
        CANCELLED: [],
      }
      
      if (!validTransitions[prev]?.includes(curr)) {
        errors.push(`Invalid transition at #${transitions[i].id}: ${prev} → ${curr}`)
      }
    }

    // Check if current state matches last transition
    if (shipmentData && transitions.length > 0) {
      const lastTransition = transitions[transitions.length - 1]
      if (shipmentData.current_state !== lastTransition.to_state) {
        errors.push(`State mismatch: Current state (${shipmentData.current_state}) doesn't match last transition (${lastTransition.to_state})`)
      }
    }

    setValidationErrors(errors)
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString()
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  if (!shipment) {
    return (
      <div className="card p-6 bg-rose-50 border-rose-200">
        <span className="text-rose-800 font-medium">Shipment not found</span>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="card p-6 bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200">
        <div className="flex items-center mb-4">
          <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center mr-3">
            <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Debug View</h2>
            <p className="text-sm text-gray-600 mt-1">
              All transitions, validation status, and system state
            </p>
          </div>
        </div>
        
        <div className="card p-4 mb-4">
          <h3 className="font-semibold text-gray-900 mb-3">Shipment Info</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-500 block mb-1">ID</span>
              <span className="font-mono font-medium text-gray-900">#{shipment.id}</span>
            </div>
            <div>
              <span className="text-gray-500 block mb-1">Tracking</span>
              <span className="font-mono font-medium text-gray-900">{escapeHtml(shipment.tracking_number)}</span>
            </div>
            <div>
              <span className="text-gray-500 block mb-1">Current State</span>
              <span className={`inline-block px-2 py-1 rounded-lg text-xs font-semibold border ${STATE_COLORS[shipment.current_state] || 'bg-gray-100 text-gray-700 border-gray-300'}`}>
                {shipment.current_state.replace(/_/g, ' ')}
              </span>
            </div>
            <div>
              <span className="text-gray-500 block mb-1">Created</span>
              <span className="text-gray-900">{formatDate(shipment.created_at)}</span>
            </div>
          </div>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold text-gray-900 mb-3">Status Validity</h3>
          {validationErrors.length === 0 ? (
            <div className="flex items-center text-emerald-700 font-medium">
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              All validations passed
            </div>
          ) : (
            <div>
              <div className="flex items-center text-rose-700 font-semibold mb-3">
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                Validation Errors
              </div>
              <ul className="list-disc list-inside text-rose-600 space-y-1">
                {validationErrors.map((error, idx) => (
                  <li key={idx}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <div className="card p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">All Transitions</h2>
        <div className="space-y-6">
          {timeline.map((transition, index) => (
            <div key={transition.id} className="flex items-start group">
              <div className="flex-shrink-0 mr-4">
                <div className="relative">
                  <div className={`w-4 h-4 rounded-full border-2 ${STATE_COLORS[transition.to_state]?.split(' ')[0] || 'bg-gray-100'} border-current`} />
                  {index < timeline.length - 1 && (
                    <div className="absolute top-4 left-1/2 w-0.5 h-12 bg-gray-200 transform -translate-x-1/2" />
                  )}
                </div>
              </div>
              <div className="flex-1 pb-6 border-b border-gray-100 last:border-0 last:pb-0">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-xs text-gray-500 font-mono">#{transition.id}</span>
                  {transition.from_state ? (
                    <span className="text-sm text-gray-600 flex items-center">
                      {transition.from_state.replace(/_/g, ' ')}
                      <svg className="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                      </svg>
                    </span>
                  ) : (
                    <span className="text-xs text-gray-500">(initial)</span>
                  )}
                  <span className={`px-3 py-1 text-xs font-semibold rounded-lg border ${STATE_COLORS[transition.to_state] || 'bg-gray-100 text-gray-700 border-gray-300'}`}>
                    {transition.to_state.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="text-sm text-gray-600 space-y-1">
                  <div>Timestamp: {formatDate(transition.timestamp)}</div>
                  <div className="text-xs text-gray-500">Shipment ID: {transition.shipment_id || 'N/A'}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-6 bg-gray-50">
        <h3 className="font-semibold text-gray-900 mb-4">Debug Information</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-500 block mb-1">Total Transitions</span>
            <span className="font-medium text-gray-900">{timeline.length}</span>
          </div>
          <div>
            <span className="text-gray-500 block mb-1">Current State</span>
            <span className="font-medium text-gray-900">{shipment.current_state.replace(/_/g, ' ')}</span>
          </div>
          <div>
            <span className="text-gray-500 block mb-1">Last Updated</span>
            <span className="font-medium text-gray-900">{formatDate(shipment.updated_at)}</span>
          </div>
          <div>
            <span className="text-gray-500 block mb-1">Is Terminal</span>
            <span className="font-medium text-gray-900">
              {shipment.current_state === 'DELIVERED' || shipment.current_state === 'CANCELLED' ? 'Yes' : 'No'}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DebugView

