import { useState, useEffect } from 'react'
import { getShipments } from '../api'

function ConnectionStatus({ compact = false }) {
  const [status, setStatus] = useState('checking')
  const [error, setError] = useState(null)

  useEffect(() => {
    const checkConnection = async () => {
      try {
        await getShipments(1, 1)
        setStatus('connected')
        setError(null)
      } catch (err) {
        setStatus('disconnected')
        setError(err.message || 'Cannot connect to backend API')
      }
    }

    checkConnection()
    const interval = setInterval(checkConnection, 5000) // Check every 5 seconds
    return () => clearInterval(interval)
  }, [])

  if (compact) {
    if (status === 'checking') {
      return (
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
          <span>Checking…</span>
        </div>
      )
    }

    if (status === 'disconnected') {
      return (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-rose-700">
            <span className="h-2 w-2 rounded-full bg-rose-500" />
            <span>Disconnected</span>
          </div>
          <div className="text-xs text-rose-600 break-words">{error}</div>
        </div>
      )
    }

    return (
      <div className="flex items-center gap-2 text-xs text-emerald-700">
        <span className="h-2 w-2 rounded-full bg-emerald-500" />
        <span>Connected</span>
      </div>
    )
  }

  if (status === 'checking') {
    return (
      <div className="card p-4 mb-6 bg-amber-50 border-amber-200">
        <div className="flex items-center">
          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-amber-600 mr-3"></div>
          <span className="text-amber-800 font-medium">Checking backend connection...</span>
        </div>
      </div>
    )
  }

  if (status === 'disconnected') {
    return (
      <div className="card p-4 mb-6 bg-rose-50 border-rose-200">
        <div className="flex items-start">
          <svg className="w-5 h-5 text-rose-600 mr-3 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
          </svg>
          <div className="flex-1">
            <div className="font-semibold text-rose-900 mb-1">Backend Connection Failed</div>
            <div className="text-sm text-rose-700 mb-2">{error}</div>
            <div className="text-sm text-rose-700">
              <strong>Please ensure:</strong>
              <ul className="list-disc list-inside mt-1 space-y-1">
                <li>Backend service is running on http://localhost:8000</li>
                <li>Run <code className="bg-rose-100 px-1.5 py-0.5 rounded text-xs">docker-compose up</code> if using Docker</li>
                <li>Check backend logs for errors</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return null // Connected - no message needed
}

export default ConnectionStatus

