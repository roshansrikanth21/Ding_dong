import { useState, useEffect } from 'react'
import { Link, useSearchParams, useNavigate } from 'react-router-dom'
import { searchShipments, createShipment, createBulkShipments, exportShipments, validateTrackingNumber } from '../api'
import ConnectionStatus from './ConnectionStatus'
import { escapeHtml } from '../utils/sanitize'

const STATE_COLORS = {
  CREATED: 'bg-slate-100 text-slate-700 border-slate-300',
  READY_FOR_PICKUP: 'bg-amber-100 text-amber-800 border-amber-300',
  IN_TRANSIT: 'bg-blue-100 text-blue-800 border-blue-300',
  DELIVERED: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  CANCELLED: 'bg-rose-100 text-rose-800 border-rose-300',
  EXCEPTION: 'bg-orange-100 text-orange-800 border-orange-300',
}

function ShipmentList() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const [shipments, setShipments] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const [limit] = useState(20)
  
  // Filters
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [carrierFilter, setCarrierFilter] = useState('')
  const [sortBy, setSortBy] = useState('updated_at')
  const [sortOrder, setSortOrder] = useState('desc')
  
  // Create form
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [trackingNumber, setTrackingNumber] = useState('')
  const [trackingValidation, setTrackingValidation] = useState(null)
  const [creating, setCreating] = useState(false)
  // Inventory fields
  const [origin, setOrigin] = useState('')
  const [destination, setDestination] = useState('')
  const [productType, setProductType] = useState('')
  const [isFragile, setIsFragile] = useState('NON_FRAGILE')
  const [storageLocations, setStorageLocations] = useState('')
  const [scheduledDate, setScheduledDate] = useState('')
  const [estimatedDelivery, setEstimatedDelivery] = useState('')
  
  // Bulk operations
  const [showBulkForm, setShowBulkForm] = useState(false)
  const [bulkTrackingNumbers, setBulkTrackingNumbers] = useState('')
  const [bulkCreating, setBulkCreating] = useState(false)

  useEffect(() => {
    const urlSearch = searchParams.get('search') || ''
    const urlNew = searchParams.get('new')

    // Keep URL -> UI in sync
    if (urlSearch !== searchQuery) {
      setSearchQuery(urlSearch)
      setPage(1)
    }
    if (urlNew === '1') {
      setShowCreateForm(true)
      setShowBulkForm(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams])

  useEffect(() => {
    loadShipments()
  }, [page, statusFilter, carrierFilter, sortBy, sortOrder, searchQuery])

  const loadShipments = async () => {
    try {
      setLoading(true)
      setError(null)
      const filters = {}
      if (statusFilter) filters.status = statusFilter
      if (carrierFilter) filters.carrier = carrierFilter
      if (sortBy) filters.sort_by = sortBy
      if (sortOrder) filters.sort_order = sortOrder
      
      const data = await searchShipments(searchQuery || null, page, limit, filters)
      setShipments(data.shipments)
      setTotal(data.total)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load shipments')
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e) => {
    e.preventDefault()
    setPage(1)
    const trimmed = (searchQuery || '').trim()
    if (trimmed) {
      navigate(`/shipments?search=${encodeURIComponent(trimmed)}`)
    } else {
      navigate('/shipments')
    }
    loadShipments()
  }

  const handleCreate = async (e) => {
    e.preventDefault()
    const trimmed = trackingNumber.trim().toUpperCase()
    
    if (!trimmed) {
      setError('Tracking number cannot be empty')
      return
    }

    try {
      setCreating(true)
      setError(null)
      
      // Prepare inventory data
      const inventoryData = {}
      if (origin.trim()) inventoryData.origin = origin.trim()
      if (destination.trim()) inventoryData.destination = destination.trim()
      if (productType.trim()) inventoryData.product_type = productType.trim()
      if (isFragile) inventoryData.is_fragile = isFragile
      if (storageLocations.trim()) {
        // Convert comma-separated to JSON array
        const locations = storageLocations.split(',').map(l => l.trim()).filter(l => l)
        if (locations.length > 0) {
          inventoryData.storage_locations = JSON.stringify(locations)
        }
      }
      if (scheduledDate) inventoryData.scheduled_date = new Date(scheduledDate).toISOString()
      if (estimatedDelivery) inventoryData.estimated_delivery = new Date(estimatedDelivery).toISOString()
      
      const created = await createShipment(trimmed, inventoryData)
      
      // Reset form
      setTrackingNumber('')
      setOrigin('')
      setDestination('')
      setProductType('')
      setIsFragile('NON_FRAGILE')
      setStorageLocations('')
      setScheduledDate('')
      setEstimatedDelivery('')
      setTrackingValidation(null)
      setShowCreateForm(false)
      
      // Navigate to the created/restored shipment using public_id
      if (created && created.id) {
        navigate(`/shipments/${created.id}`)
      } else {
        loadShipments()
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to create shipment')
    } finally {
      setCreating(false)
    }
  }

  const handleBulkCreate = async (e) => {
    e.preventDefault()
    const numbers = bulkTrackingNumbers
      .split('\n')
      .map(n => n.trim().toUpperCase())
      .filter(n => n.length > 0)
    
    if (numbers.length === 0) {
      setError('Please enter at least one tracking number')
      return
    }

    if (numbers.length > 100) {
      setError('Maximum 100 tracking numbers per batch')
      return
    }

    try {
      setBulkCreating(true)
      setError(null)
      const result = await createBulkShipments(numbers)
      setBulkTrackingNumbers('')
      setShowBulkForm(false)
      loadShipments()
      
      if (result.errors && result.errors.length > 0) {
        setError(`Created ${result.total_created} shipments. ${result.total_errors} errors.`)
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to create shipments')
    } finally {
      setBulkCreating(false)
    }
  }

  const handleExport = async () => {
    try {
      const filters = {}
      if (statusFilter) filters.status = statusFilter
      if (carrierFilter) filters.carrier = carrierFilter
      
      const blob = await exportShipments(filters)
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `shipments_${new Date().toISOString().split('T')[0]}.csv`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (err) {
      setError('Failed to export shipments')
    }
  }

  const validateTracking = async (value) => {
    if (!value || value.trim().length < 6) {
      setTrackingValidation(null)
      return
    }
    
    try {
      const info = await validateTrackingNumber(value.trim())
      setTrackingValidation(info)
    } catch (err) {
      setTrackingValidation({ valid: false, error: 'Validation failed' })
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className="max-w-7xl mx-auto">
      <ConnectionStatus />
      
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Shipment Management</h1>
          <p className="text-gray-600">Track, manage, and monitor your shipments</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={handleExport}
            className="btn-secondary"
            disabled={total === 0}
          >
            <svg className="w-5 h-5 mr-2 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Export CSV
          </button>
          <button
            onClick={() => {
              setShowBulkForm(!showBulkForm)
              setShowCreateForm(false)
            }}
            className="btn-secondary"
          >
            Bulk Import
          </button>
          <button
            onClick={() => {
              setShowCreateForm(!showCreateForm)
              setShowBulkForm(false)
            }}
            className="btn-primary"
          >
            {showCreateForm ? (
              <span className="flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
                Cancel
              </span>
            ) : (
              <span className="flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                New Shipment
              </span>
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="card p-4 mb-6 bg-rose-50 border-rose-200">
          <div className="flex items-center">
            <svg className="w-5 h-5 text-rose-600 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
            <span className="text-rose-800 font-medium">{error}</span>
          </div>
        </div>
      )}

      {/* Create Form */}
      {showCreateForm && (
        <div className="card p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Create New Shipment</h2>
          <form onSubmit={handleCreate}>
            <div className="space-y-4">
              {/* Tracking Number */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tracking Number *</label>
                <input
                  type="text"
                  value={trackingNumber}
                  onChange={(e) => {
                    setTrackingNumber(e.target.value)
                    validateTracking(e.target.value)
                  }}
                  placeholder="Enter tracking number (e.g., EE123456789IN, 1Z999AA10123456784)"
                  className="input-field"
                  disabled={creating}
                  maxLength={50}
                  required
                />
                {trackingValidation && (
                  <div className={`mt-2 text-sm ${trackingValidation.valid ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {trackingValidation.valid ? (
                      <span className="flex items-center">
                        <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                        {trackingValidation.format || 'Valid tracking number'}
                      </span>
                    ) : (
                      <span>{trackingValidation.error || 'Invalid format'}</span>
                    )}
                  </div>
                )}
              </div>

              {/* Inventory Fields Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Origin</label>
                  <input
                    type="text"
                    value={origin}
                    onChange={(e) => setOrigin(e.target.value)}
                    placeholder="Where shipment comes from"
                    className="input-field"
                    disabled={creating}
                    maxLength={200}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Destination</label>
                  <input
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="Where shipment is going"
                    className="input-field"
                    disabled={creating}
                    maxLength={200}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Product Type</label>
                  <input
                    type="text"
                    value={productType}
                    onChange={(e) => setProductType(e.target.value)}
                    placeholder="e.g., Electronics, Clothing, Food"
                    className="input-field"
                    disabled={creating}
                    maxLength={100}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Fragility</label>
                  <select
                    value={isFragile}
                    onChange={(e) => setIsFragile(e.target.value)}
                    className="input-field"
                    disabled={creating}
                  >
                    <option value="NON_FRAGILE">Non-Fragile</option>
                    <option value="FRAGILE">Fragile</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Storage Locations</label>
                  <input
                    type="text"
                    value={storageLocations}
                    onChange={(e) => setStorageLocations(e.target.value)}
                    placeholder="Comma-separated waypoints (e.g., Warehouse A, Distribution Center B)"
                    className="input-field"
                    disabled={creating}
                    maxLength={500}
                  />
                  <p className="text-xs text-gray-500 mt-1">Enter storage waypoints separated by commas</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Scheduled Date</label>
                  <input
                    type="datetime-local"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="input-field"
                    disabled={creating}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Estimated Delivery</label>
                  <input
                    type="datetime-local"
                    value={estimatedDelivery}
                    onChange={(e) => setEstimatedDelivery(e.target.value)}
                    className="input-field"
                    disabled={creating}
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  disabled={creating || !trackingNumber.trim()}
                  className="btn-primary"
                >
                  {creating ? 'Creating...' : 'Create Shipment'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateForm(false)
                    setTrackingNumber('')
                    setOrigin('')
                    setDestination('')
                    setProductType('')
                    setIsFragile('NON_FRAGILE')
                    setStorageLocations('')
                    setScheduledDate('')
                    setEstimatedDelivery('')
                    setTrackingValidation(null)
                  }}
                  className="btn-secondary"
                  disabled={creating}
                >
                  Cancel
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Bulk Import Form */}
      {showBulkForm && (
        <div className="card p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Bulk Import Shipments</h2>
          <form onSubmit={handleBulkCreate}>
            <div className="space-y-4">
              <div>
                <textarea
                  value={bulkTrackingNumbers}
                  onChange={(e) => setBulkTrackingNumbers(e.target.value)}
                  placeholder="Enter tracking numbers, one per line (max 100)"
                  className="input-field"
                  rows={6}
                  disabled={bulkCreating}
                />
                <p className="text-sm text-gray-500 mt-2">
                  Enter one tracking number per line. Maximum 100 shipments per batch.
                </p>
              </div>
              <button
                type="submit"
                disabled={bulkCreating || !bulkTrackingNumbers.trim()}
                className="btn-primary"
              >
                {bulkCreating ? 'Importing...' : 'Import Shipments'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search and Filters */}
      <div className="card p-6 mb-6">
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by tracking number..."
                  className="input-field pl-10"
                />
                <svg className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value)
                setPage(1)
              }}
              className="input-field"
            >
              <option value="">All Statuses</option>
              <option value="CREATED">Created</option>
              <option value="READY_FOR_PICKUP">Ready for Pickup</option>
              <option value="IN_TRANSIT">In Transit</option>
              <option value="DELIVERED">Delivered</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
            <select
              value={carrierFilter}
              onChange={(e) => {
                setCarrierFilter(e.target.value)
                setPage(1)
              }}
              className="input-field"
            >
              <option value="">All Carriers</option>
              <option value="INDIA_POST">India Post</option>
              <option value="BLUE_DART">Blue Dart</option>
              <option value="DHL_EXPRESS">DHL Express</option>
              <option value="DHL_ECOMMERCE">DHL eCommerce</option>
              <option value="DELHIVERY">Delhivery</option>
              <option value="UPS">UPS</option>
              <option value="FEDEX">FedEx</option>
              <option value="USPS">USPS</option>
              <option value="CONTAINER">Container</option>
            </select>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="input-field w-48"
              >
                <option value="updated_at">Sort by: Last Updated</option>
                <option value="created_at">Sort by: Created Date</option>
                <option value="tracking_number">Sort by: Tracking Number</option>
                <option value="current_state">Sort by: Status</option>
              </select>
              <button
                type="button"
                onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                className="btn-secondary"
              >
                {sortOrder === 'asc' ? (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                )}
              </button>
            </div>
            <div className="text-sm text-gray-600">
              {total.toLocaleString()} total shipments
            </div>
          </div>
        </form>
      </div>

      {/* Shipments List */}
      {loading ? (
        <div className="flex justify-center items-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      ) : shipments.length === 0 ? (
        <div className="card p-12 text-center">
          <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
          </svg>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No shipments found</h3>
          <p className="text-gray-600">Create your first shipment to get started</p>
        </div>
      ) : (
        <>
          <div className="grid gap-4 mb-6">
            {shipments.map((shipment) => (
              <Link
                key={shipment.id}
                to={`/shipments/${shipment.id}`}
                className="card p-6 hover:shadow-lg transition-all duration-200 group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 flex-1 min-w-0">
                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-2xl">📦</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-3 mb-1">
                        <h3 className="text-lg font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors truncate">
                          {escapeHtml(shipment.tracking_number)}
                        </h3>
                        {shipment.carrier && (
                          <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                            {shipment.carrier.replace(/_/g, ' ')}
                          </span>
                        )}
                        <span className="text-sm text-gray-500">#{shipment.id}</span>
                      </div>
                      <p className="text-sm text-gray-600">Updated {formatDate(shipment.updated_at)}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border ${
                        STATE_COLORS[shipment.current_state] || 'bg-gray-100 text-gray-700 border-gray-300'
                      }`}
                    >
                      {shipment.current_state.replace(/_/g, ' ')}
                    </span>
                    <svg className="w-5 h-5 text-gray-400 group-hover:text-indigo-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              Showing <span className="font-medium text-gray-900">{(page - 1) * limit + 1}</span> to{' '}
              <span className="font-medium text-gray-900">{Math.min(page * limit, total)}</span> of{' '}
              <span className="font-medium text-gray-900">{total.toLocaleString()}</span> shipments
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setPage(page - 1)}
                disabled={page === 1}
                className="btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <button
                onClick={() => setPage(page + 1)}
                disabled={page * limit >= total}
                className="btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export default ShipmentList
