import { NavLink, Outlet, useNavigate, useSearchParams } from 'react-router-dom'
import { useMemo, useState } from 'react'
import ConnectionStatus from '../ConnectionStatus'

const NAV = [
  { to: '/', label: 'Overview', icon: 'grid' },
  { to: '/shipments', label: 'Shipments', icon: 'box' },
  { to: '/activity', label: 'Activity', icon: 'pulse' },
  { to: '/insights', label: 'Ops Insights', icon: 'chart' },
  { to: '/about', label: 'About', icon: 'info' },
]

function Icon({ name }) {
  if (name === 'grid') {
    return (
      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z" />
      </svg>
    )
  }
  if (name === 'box') {
    return (
      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M21 8l-9-5-9 5 9 5 9-5z" />
        <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M3 8v8l9 5 9-5V8" />
        <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M12 13v8" />
      </svg>
    )
  }
  if (name === 'pulse') {
    return (
      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M3 12h4l2-6 4 12 2-6h6" />
      </svg>
    )
  }
  if (name === 'info') {
    return (
      <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    )
  }
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M4 19V5m0 14h16M8 17V9m4 8V7m4 10v-6" />
    </svg>
  )
}

export default function AppShell() {
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const initial = params.get('search') || ''
  const [q, setQ] = useState(initial)

  const placeholder = useMemo(() => 'Search tracking number…', [])

  const onSubmit = (e) => {
    e.preventDefault()
    const trimmed = (q || '').trim()
    navigate(trimmed ? `/shipments?search=${encodeURIComponent(trimmed)}` : '/shipments')
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="flex">
        {/* Sidebar */}
        <aside className="hidden lg:flex lg:w-72 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-200 bg-white">
          <div className="px-6 py-5 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-semibold">
                SG
              </div>
              <div>
                <div className="text-sm font-semibold leading-4">EventGuard</div>
                <div className="text-xs text-slate-500">Ops Console</div>
              </div>
            </div>
          </div>

          <nav className="px-3 py-4 space-y-1">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition ${
                    isActive
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                  }`
                }
              >
                <Icon name={item.icon} />
                <span>{item.label}</span>
              </NavLink>
            ))}
          </nav>

          <div className="mt-auto px-6 py-4 border-t border-slate-200">
            <div className="text-xs text-slate-500">Connection</div>
            <div className="mt-2">
              <ConnectionStatus compact />
            </div>
          </div>
        </aside>

        {/* Main */}
        <div className="flex-1 lg:pl-72">
          {/* Top bar */}
          <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-slate-200">
            <div className="px-4 sm:px-6 py-3 flex items-center gap-3">
              <form onSubmit={onSubmit} className="flex-1">
                <div className="relative">
                  <input
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder={placeholder}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-10 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-slate-900/10"
                  />
                  <svg className="h-5 w-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
              </form>

              <button
                onClick={() => navigate('/shipments?new=1')}
                className="btn btn-primary hidden sm:inline-flex"
              >
                New shipment
              </button>
            </div>
          </header>

          <main className="px-4 sm:px-6 py-6">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  )
}


