import axios from 'axios'

// Use environment variable or default to localhost
// In Docker, this will be set via environment variable
// For local dev, it defaults to localhost:8000
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 second timeout
})

// Add request interceptor for debugging
api.interceptors.request.use(
  (config) => {
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`)
    return config
  },
  (error) => {
    console.error('API Request Error:', error)
    return Promise.reject(error)
  }
)

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.code === 'ECONNREFUSED' || error.message.includes('Network Error')) {
      console.error('Cannot connect to backend API. Is the backend running on', API_BASE_URL, '?')
      error.message = `Cannot connect to backend API at ${API_BASE_URL}. Please ensure the backend service is running.`
    }
    return Promise.reject(error)
  }
)

export const createShipment = async (trackingNumber, inventoryData = {}) => {
  const payload = {
    tracking_number: trackingNumber,
    ...inventoryData
  }
  const response = await api.post('/shipments', payload)
  return response.data
}

export const getShipments = async (page = 1, limit = 10, status = null) => {
  const params = { page, limit }
  if (status) params.status = status
  const response = await api.get('/shipments', { params })
  return response.data
}

export const getShipment = async (id) => {
  const response = await api.get(`/shipments/${id}`)
  return response.data
}

export const getShipmentTimeline = async (id) => {
  const response = await api.get(`/shipments/${id}/timeline`)
  return response.data
}

export const transitionShipment = async (id, targetState, actor = null, reason = null, idempotencyKey = null) => {
  const response = await api.post(`/shipments/${id}/transition`, {
    target_state: targetState,
    actor,
    reason,
    idempotency_key: idempotencyKey,
  })
  return response.data
}

export const recoverFromException = async (id, targetState, reason, actor = null) => {
  const response = await api.post(`/shipments/${id}/recover`, {
    target_state: targetState,
    reason,
    actor,
  })
  return response.data
}

export const getStatistics = async (days = 30) => {
  const response = await api.get('/statistics', { params: { days } })
  return response.data
}

export const getActivity = async ({ days = 7, limit = 50, shipmentId = null, state = null } = {}) => {
  const params = { days, limit }
  if (shipmentId) params.shipment_id = shipmentId
  if (state) params.state = state
  const response = await api.get('/activity', { params })
  return response.data
}

export const getAgingInsights = async ({ staleThresholdDays = 7, limitStale = 25 } = {}) => {
  const params = { stale_threshold_days: staleThresholdDays, limit_stale: limitStale }
  const response = await api.get('/insights/aging', { params })
  return response.data
}

export const searchShipments = async (search, page = 1, limit = 20, filters = {}) => {
  const params = { page, limit, search, ...filters }
  const response = await api.get('/shipments', { params })
  return response.data
}

export const createBulkShipments = async (trackingNumbers) => {
  const response = await api.post('/shipments/bulk', {
    tracking_numbers: trackingNumbers,
  })
  return response.data
}

export const updateShipment = async (id, notes) => {
  const response = await api.patch(`/shipments/${id}`, { notes })
  return response.data
}

export const validateTrackingNumber = async (trackingNumber) => {
  const response = await api.get('/tracking/validate', {
    params: { tracking_number: trackingNumber },
  })
  return response.data
}

export const exportShipments = async (filters = {}) => {
  const params = new URLSearchParams(filters)
  const response = await api.get('/shipments/export/csv', {
    params,
    responseType: 'blob',
  })
  return response.data
}

export const deleteShipment = async (id, permanent = false) => {
  const response = await api.delete(`/shipments/${id}`, {
    params: { permanent }
  })
  return response.data
}

export const getOperationsSummary = async () => {
  const response = await api.get('/operations/summary')
  return response.data
}

export const getBlockedActions = async () => {
  const response = await api.get('/operations/blocked-actions')
  return response.data
}

export const recordWaypointVisit = async (shipmentId, waypointName, notes = null, actor = null) => {
  const response = await api.post(`/shipments/${shipmentId}/waypoints`, {
    waypoint_name: waypointName,
    notes,
    actor,
  })
  return response.data
}

export const markWaypointDeparted = async (shipmentId, waypointId, actor = null) => {
  const response = await api.patch(`/shipments/${shipmentId}/waypoints/${waypointId}/depart`, null, {
    params: { actor }
  })
  return response.data
}
