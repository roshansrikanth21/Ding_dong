import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Dashboard from './components/Dashboard'
import ShipmentList from './components/ShipmentList'
import ShipmentDetail from './components/ShipmentDetail'
import DebugView from './components/DebugView'
import AppShell from './components/layout/AppShell'
import Activity from './components/Activity'
import Insights from './components/Insights'
import AIAgent from './components/AIAgent'
import About from './components/About'

function App() {
  return (
    <Router>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/shipments" element={<ShipmentList />} />
          <Route path="/activity" element={<Activity />} />
          <Route path="/insights" element={<Insights />} />
          <Route path="/about" element={<About />} />
          <Route path="/shipments/:id" element={<ShipmentDetail />} />
          <Route path="/shipments/:id/debug" element={<DebugView />} />
        </Route>
      </Routes>
      <AIAgent />
    </Router>
  )
}

export default App

